#!/usr/bin/env python3
"""只读检查 AI4399大全 的同级技能文件；不安装、不推理、不上传。"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys


SKILL_DIR = Path(__file__).resolve().parent.parent


def local_path(root, relative):
    part = Path(relative)
    if part.is_absolute() or ".." in part.parts:
        raise ValueError("清单路径必须相对技能目录且不能包含 ..")
    return root / part


def read_file(path):
    if not path.is_file():
        raise ValueError("文件不存在或不是普通文件")
    data = path.read_bytes()
    if not data:
        raise ValueError("文件为空")
    return data


def check_frontmatter(data, expected_name):
    """检查必需字段；完整 YAML 语法由技能加载器验证。"""
    content = data.decode("utf-8-sig")
    match = re.match(r"\A---\r?\n(.*?)\r?\n---(?:\r?\n|$)", content, re.S)
    if not match:
        return ["SKILL.md 缺少有效的 frontmatter 边界"]
    fields = {}
    for key in ("name", "description"):
        scalar = re.search(r"^" + key + r":[ \t]*(.+)$", match[1], re.M)
        if scalar:
            fields[key] = scalar[1].strip().strip("\"'")
    errors = []
    if fields.get("name") != expected_name:
        errors.append("frontmatter.name 与模块标识不一致或缺失")
    description = fields.get("description", "")
    if not description:
        errors.append("frontmatter.description 缺失或为空")
    elif description in ("|", ">", "|-", ">-", "|+", ">+"):
        block = re.search(r"^description:[^\n]*\n((?:[ \t]+[^\n]*\n?)+)", match[1], re.M)
        if not block or not block[1].strip():
            errors.append("frontmatter.description 多行值为空")
    return errors


def inspect_modules(manifest, skills_root):
    modules = manifest.get("modules")
    if not isinstance(modules, list) or not modules:
        raise ValueError("清单没有非空 modules 列表")
    identifiers = [item.get("id") for item in modules if isinstance(item, dict)]
    if len(identifiers) != len(modules) or any(not isinstance(i, str) or not i for i in identifiers):
        raise ValueError("模块必须具有非空字符串 id")
    if len(set(identifiers)) != len(identifiers):
        raise ValueError("模块 id 重复")
    reports = {}
    for module in modules:
        module_id = module["id"]
        entry = local_path(skills_root, module["entry"])
        report = {
            "id": module_id, "entry": str(entry), "ready": True,
            "source_changed": False, "files_checked": 0,
            "errors": [], "warnings": [],
        }
        try:
            data = read_file(entry)
            report["files_checked"] += 1
            report["errors"].extend(check_frontmatter(data, module_id))
            actual_hash = hashlib.sha256(data).hexdigest()
            report["sha256"] = actual_hash
            original_hash = module.get("sha256_at_integration")
            if original_hash and original_hash != actual_hash:
                report["source_changed"] = True
                report["warnings"].append("原技能入口已更新；采用前须阅读最新原文，不以旧摘要代替")
        except (OSError, UnicodeError, ValueError) as exc:
            report["errors"].append("{}: {}".format(entry, exc))
        for required in module.get("required", []):
            path = local_path(entry.parent, required)
            try:
                read_file(path)
                report["files_checked"] += 1
            except (OSError, ValueError) as exc:
                report["errors"].append("{}: {}".format(path, exc))
        report["ready"] = not report["errors"]
        reports[module_id] = report

    delegate_map = {m["id"]: m.get("delegates_to") for m in modules}
    resolved = set()

    def resolve(module_id, trail):
        if module_id in resolved:
            return reports[module_id]["ready"]
        if module_id in trail:
            raise ValueError("兼容入口存在循环: " + " → ".join(trail + [module_id]))
        target = delegate_map[module_id]
        report = reports[module_id]
        if target:
            if target not in reports:
                report["errors"].append("委托目标未注册: " + str(target))
                report["ready"] = False
            elif not resolve(target, trail + [module_id]):
                report["errors"].append("委托目标不可用: " + target)
                report["ready"] = False
        resolved.add(module_id)
        return report["ready"]

    for module_id in identifiers:
        resolve(module_id, [])
    return [reports[module_id] for module_id in identifiers]


def inspect_media():
    results = []
    for name in ("ffmpeg", "ffprobe"):
        executable = shutil.which(name)
        fallback = Path.home() / ".local" / "bin" / name
        if not executable and fallback.is_file() and os.access(fallback, os.X_OK):
            executable = str(fallback)
        report = {"name": name, "path": executable, "ready": False}
        if executable:
            try:
                process = subprocess.run(
                    [executable, "-version"], stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE, text=True, timeout=8, check=False,
                )
                output = (process.stdout or process.stderr).splitlines()
                report["version"] = output[0] if output else ""
                report["ready"] = process.returncode == 0
                if not report["ready"]:
                    report["error"] = "版本查询退出码: {}".format(process.returncode)
            except (OSError, subprocess.TimeoutExpired) as exc:
                report["error"] = str(exc)
        else:
            report["error"] = "PATH 和 ~/.local/bin 内未找到可执行文件"
        results.append(report)
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true", help="输出可解析的 JSON")
    parser.add_argument("--skills-root", type=Path, default=SKILL_DIR.parent,
                        help="技能集合根目录，默认本技能的父目录")
    parser.add_argument("--media", action="store_true", help="同时检查 ffmpeg/ffprobe，不运行模型")
    args = parser.parse_args()
    try:
        manifest = json.loads((SKILL_DIR / "references" / "modules.json").read_text(encoding="utf-8"))
        modules = inspect_modules(manifest, args.skills_root.expanduser().resolve())
        media = inspect_media() if args.media else []
        ready_count = sum(item["ready"] for item in modules)
        result = {
            "skill": manifest["skill_name"], "check_scope": "files_and_optional_media_tools",
            "skills_root": str(args.skills_root.expanduser().resolve()),
            "ready": ready_count == len(modules) and all(item["ready"] for item in media),
            "total": len(modules), "ready_count": ready_count,
            "changed_count": sum(item["source_changed"] for item in modules),
            "modules": modules, "media": media,
        }
    except (OSError, ValueError, KeyError, TypeError) as exc:
        result = {"skill": "AI4399大全", "ready": False, "error": str(exc)}
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif "error" in result:
        print("依赖检查失败: " + result["error"])
    else:
        print("AI4399大全：{}/{} 个模块文件就绪".format(result["ready_count"], result["total"]))
        for item in result["modules"]:
            label = "就绪" if item["ready"] else "不可用"
            print("- {}：{}".format(item["id"], label))
            for note in item["errors"] + item["warnings"]:
                print("  " + note)
        for item in result["media"]:
            print("- {}：{}".format(item["name"], item.get("version") or item.get("error", "不可用")))
        print("仅检查文件与所选工具；未运行拆帧、深度推理、上传或生成。")
    return 0 if result["ready"] else 1


if __name__ == "__main__":
    sys.exit(main())
