---
name: cineflow-cli
description: Use when 用户操作七猫AI影视创作平台或 CineFlow，包括项目、剧本与资产基础增删改查、模型体验中心图片/音频/视频生成、单集或多集视频制作、补齐或继续制作、分镜增删复制、分镜素材、提示词或配置修改、整集重做、历史失败诊断、选用记录、预审或下载生成产出。
---

# CineFlow CLI

在操作七猫AI影视创作平台时，可以通过 `cineflow` 执行确定性平台操作。提示词理解和改写由当前 Agent 完成；不要把 Tiptap JSON 交给用户或自行拼装 mention JSON。保存已有资产富文本时，可原样保留服务端快照及引用对象的稳定身份，只改用户指定字段；普通文本修改使用 prompt update。另外,在与用户交流时,项目等名称放前面,ID放后面,略微弱化id的存在感,用户的操作面板中不太能看到id。

## 开始前

1. 先运行 `cineflow -h`，再读取即将使用的子命令帮助。
2. 运行 `cineflow doctor`，读取响应 `meta.cli_release` 中的兼容事实和公告。
3. 除非用户要求切换账号，否则复用现有登录。只有未登录时运行 `cineflow auth login`；无本地浏览器时加 `--headless`。
4. 登录命令在 stderr 输出授权地址和 `user code` 后，无论浏览器是否自动打开，都要立即把两者告知用户，并将 `user code` 明确称为“授权码”。说明授权页也会显示该授权码，请用户核对两处完全一致后再点击“授权”。不要等登录命令结束后才告知；命令会在用户完成网页操作期间持续等待。
5. `user code` 是供用户核对、可以展示的授权码；`device code` 是内部凭据，不得混淆。Device Flow 成功、拒绝、过期或失败后，主动把结果告知用户。不要输出 access token、refresh token 或 `device code`。
6. 未选团队时先运行 `cineflow team list`，让用户确认后执行 `cineflow team use TEAM_ID`。

CLI 的 stdout 是单个 JSON；进度在 stderr。异步业务是否成功必须读取 JSON 中的状态和 ID，不能只看进程退出码。

## 项目资产基础操作

维护项目资产、资产状态/视角、图片、库导入、独立参考、音色替换、草稿/CAS、提示词、记录查询、导出、角色音色绑定、状态出镜集数或项目画风时，读取 [项目资产原子操作](references/asset-authoring-workflow.md)。只按用户指定对象执行后端直接读写；此参考不编排资产生成或提取。

先读取当前对象并核对稳定 ID；更新只提交用户要求改变的字段，写后重新读取确认结果。删除、批量删除、覆盖当前选用图片、覆盖项目自定义画风或清空已有选择/关联时，展示准确目标和影响，并取得相应授权。

## 模型体验中心图片生成

1. 先确认 `cineflow doctor` 响应的 `data.capabilities.features` 包含 `model_experience_image_generation`；缺失时停止并提示服务端尚未上线该能力。
2. 运行 `cineflow image model list`，只使用响应中当前可用的图片模型、参数允许值、默认值和参考图限制。不要在 Agent 中保存或猜测模型清单。
3. 用 `cineflow image generate` 准备提示词、可选的本地 `--reference` / 已登记 `--reference-id` 及模型参数。`--reference-id` 必须使用参考图登记返回的附件 ID，不能使用上传确认返回的文件 ID；本地参考图的上传、确认和登记由 CLI 自动完成。第一次调用不得带 `--confirm-credits`；此时只做服务端校验和报价，不上传本地参考图、不扣费、不创建任务。
4. 向用户展示服务端返回的模型、完整 `effective_settings`、参考图数量、`display_credits`、实际 `payable_credits` 和 `available_credits`。免费促销模型也要同时说明展示原价与实际应扣积分。
5. 默认等待用户明确确认提示词、最终参数、参考图和实际应扣积分，确认前不得提交生成。若用户已明确表示本次请求或指定范围内的图片生成无需逐次确认，则视为用户已预先授权：仍须完成报价和第 4 步的信息展示，但无需暂停等待，可直接提交。不得从“继续”“快点”等笼统表述推断用户免除了确认，也不得把一次授权扩展到其未明确涵盖的后续任务。
6. 获得本次明确确认或适用的预先授权后，保持第一次调用的模型、提示词、参考图和参数完全不变，只增加 `--confirm-credits PAYABLE_CREDITS` 与一个稳定 `--idempotency-key` 再次运行 `cineflow image generate`。`--confirm-credits 0` 是有效的免费生成确认。
7. 批量图片任务必须为每条生成准备独立 `--idempotency-key`；同一个 Codex 对话窗口里，所有模型体验中心生成命令都必须带同一个稳定 `--session-key`。服务端会按模型类型与模型 ID 隔离模型体验中心对话窗口：同一模型复用同一个对话窗口，不同模型各自进入不同对话窗口。提交生图网络失败或响应不确定时，保留原幂等键、原 session key、模型、提示词和参数；先保留此前已有附件 ID 的顺序，再按错误 `message` 中列出的顺序追加本次已上传附件 ID，将全部本地 `--reference` 改为 `--reference-id` 后重试。缺少必要附件 ID 或无法还原原顺序时，停止自动重试并说明缺失信息，不猜测 ID。不得重新上传同一本地图、换键或因为等待超时重新提交；重新上传会产生新对象，可能触发 `IDEMPOTENCY_CONFLICT`。
8. 用 `cineflow image task get` 或 `cineflow image task wait` 查询任务。等待超时返回 `pending`，不是失败。任务失败时展示服务端错误与退款状态，不自动再次生成。
9. 成功后从任务输出读取 `output_id`，使用 `cineflow image output download OUTPUT_ID` 下载。默认不得覆盖已有文件；只有用户明确要求时才能传 `--overwrite`。

确认生成时，本地参考图由 CLI 通过阿里云官方 OSS SDK 直传：每批最多 5 张，批次串行、批内最多 3 个文件并行，成功后批量确认和登记附件。5 张是 CLI 自动分批大小，参考图总数上限以当前模型能力为准；超过 5 张由 CLI 自动继续下一批，Agent 不要因此拆成多次生成。恢复只覆盖当前命令进程，不承诺退出后自动续传。后端与 CLI 必须配套升级，旧 multipart 返回 415，不回退旧协议。

参考图实际顺序固定为“所有 `--reference-id`，再所有本地 `--reference`”，各组内保持输入顺序；交错书写两类参数不能交错排序。部分上传失败后，只能在保持完整参考集合及原顺序时，复用成功附件 ID 并重传失败图片。例如原 A、B、C 中 A 失败、B/C 已登记，混用 B/C 的 ID 与本地 A 会变为 B、C、A；此时停止自动重试并说明当前 CLI 的顺序限制，不擅自改顺序、遗漏图片或额外生成。

按失败阶段恢复：

- 上传、文件确认或附件登记未全部完成：本次未提交生图、未扣生成积分；读取错误中的逐项阶段和结果，保留成功附件，不能只根据顶层 `retryable` 重跑全部本地图。`uploaded_file_id` 不能替代尚未取得的附件 ID。
- 文件确认成功：只表示文件已按用途验收并登记；CLI 仍需取得业务附件 ID。不能据此判断任务已创建、所有模型均支持或图片已完整解码。
- 生图提交结果未知：任务可能已创建，按第 7 步恢复；已有任务 ID 时优先查询任务。明确被拒绝时按服务端错误处理，需要改变模型或参数则重新报价，不能把原请求当作已经成功。

模型、已有参数的可选值、默认值、上限和价格由服务端动态同步。大文件上传或下载超时时，可提高全局 `--timeout`，使用时长格式，例如 `--timeout 10m`。它控制请求超时，不是整个上传命令的总时限；上传控制请求仍有最低超时，文件传输仍有独立预算，`--timeout 0` 不会取消所有预算。提交结果未知时仍须遵守第 7 步的附件和幂等键复用规则。

## 模型体验中心音频与视频生成

1. 音频生成前先确认 `cineflow doctor` 响应的 `data.capabilities.features` 包含 `model_experience_audio_generation`；视频生成前先确认包含 `model_experience_video_generation`。缺失时停止并提示服务端尚未上线对应能力。
2. 运行将要使用的命令帮助：`cineflow audio generate -h` 或 `cineflow video generate -h`。随后运行 `cineflow audio model list` 或 `cineflow video model list`，只使用响应中当前可用的模型、参数允许值、默认值和参考文件限制。不要在 Agent 中保存或猜测音频/视频模型清单；H3、Sd2、Sd2.5 等视频模型也必须以服务端返回为准。
3. 严格区分“模型能力字段”和“请求 settings 字段”。`model list` 里的 `generation_modes`、`content_types`、`reference_*` 是能力说明，不代表都能写成 `--setting key=value`。当前音频 `--setting` 只允许：`format`、`sample_rate`、`speech_rate`、`loudness_rate`、`pitch_rate`；不要传 `generation_mode` 或 `content_type`，音频模式由参考文件类型/服务端校验推断，内容类型由服务端根据提示词分类。当前视频 `--setting` 只允许：`generation_mode`、`aspect_ratio`、`resolution`、`duration_seconds`、`seed`、`watermark`、`return_last_frame`。
4. 用 `cineflow audio generate` 或 `cineflow video generate` 准备提示词、可选的本地 `--reference` / 已登记 `--reference-id` 及合法模型参数。模型参数使用可重复的 `--setting key=value` 传入，value 可为 JSON 标量或对象。第一次调用不得带 `--confirm-credits`；此时只做服务端校验和报价。图片与音频仍按原本约定不在报价阶段上传本地参考文件；视频的报价阶段会先上传本地参考文件，以便拿到和后续提交一致的权威报价，但同样不会扣费或创建任务。

**视频参考素材提交：**项目资产图片如果 CLI 已暴露可用附件 ID，就用 `--reference-id ATTACHMENT_ID`；平台团队素材使用 `cineflow video generate --team-asset-id TEAM_ASSET_ID`；本地或 Codex 上传图片使用 `cineflow video generate --reference /path/to/image.png`。本地图片、音频等参考文件直接随生成命令提交，CLI 会上传并登记为模型体验中心视频参考附件，不表示上传为团队素材或写入项目/团队资产库。确认提交视频任务后由后端负责真人校验，按生成任务状态读取结果和失败原因。

**视频参考素材 ID 快速定位：**当用户说“用这个项目/这个分镜/团队内资产作为视频参考图”时，先用 `project list`、`episode list`、`shot get`、`shot reference list` 明确范围和分镜引用；必要时再用 `episode asset list` 辅助理解本集资产。必须按 ID 形态区分语义：`character:UUID`、`prop:UUID`、`scene:UUID` 是项目资产视角引用，不能当成 `--team-asset-id`；纯数字团队素材 ID 才能用于 `video generate --team-asset-id TEAM_ASSET_ID`；模型体验中心附件 ID 才能用于 `video generate --reference-id ATTACHMENT_ID`。如果 CLI 只返回项目资产视角 UUID，没有返回可用于模型体验中心的附件 ID 或团队素材数字 ID，不要猜测或把 UUID 硬塞给团队素材参数；改用 CLI 可获得的本地参考文件/附件流程，或明确告诉用户当前 CLI 没暴露该 ID，需要平台侧补充查询能力或提供素材 ID。`video generate --team-asset-id` 报价成功表示服务端已把团队素材登记为模型体验中心视频参考附件；确认生成返回 `reference_compliance_reuse: "reused"` 表示已复用团队素材真人合规结果。

**分镜内容转模型体验中心视频的强制规则：**当用户要求“用某个分镜/分镜提示词到模型体验中心生成视频”、或要求“只替换本次提交视频里的角色音色/本地音色，平台资产不用管”时，不得直接把 `shot.prompt_text` 原样传给 `cineflow video generate`。必须先运行 `shot get`、`shot reference list`，必要时运行 `episode asset list`，把当前分镜 `references` 里实际出现的图片资产解析为模型体验中心参考文件；资产没有可直接用的 `reference-id` 时，下载其 `image_url` 到本地临时文件并作为 `--reference` 传入。提示词中所有 `@mention` / `@voice` / 资产视图后缀必须转换成模型体验中心可理解的普通文本，例如“参考图‘沈清禾求生期（狗）’中的白色奶狗”“使用本地参考音频音色”。如果用户说“提示词不要变”，仍允许且必须做这种技术性去 mention 化，但不得改镜头内容、叙事含义或台词。用户提供本地音频替换某角色音色时，本地音频必须作为 `--reference` 传入，并在对应台词说明使用该本地参考音频；不得留下旧角色音色 mention 让模型误用。报价和确认生成必须使用同一组去 mention 后提示词、全部分镜资产参考文件、本地音频参考文件和 settings；若发现首次报价漏传资产或音频，旧报价作废，必须重新报价，不得基于旧报价提交。
5. 报价前做最后检查：音频参考图生成角色音色时，只传参考图片和音频合法 settings；不要为了表达“参考图模式”额外传 `generation_mode=reference_image`。若返回 `INVALID_AUDIO_SETTING` / `INVALID_VIDEO_SETTING` 且 message 含 `unexpected keyword argument`，说明 settings 键错了；删除该键，重新读取本章节和命令帮助后重新报价，不得进入确认生成。
6. 向用户展示服务端返回的模型、完整 `effective_settings`、参考文件数量、`display_credits`、实际 `payable_credits` 和 `available_credits`。免费促销模型也要同时说明展示原价与实际应扣积分。
7. 默认等待用户明确确认提示词、最终参数、参考文件和实际应扣积分，确认前不得提交生成。若用户已明确表示本次请求或指定范围内的音频/视频生成无需逐次确认，则视为用户已预先授权：仍须完成报价和第 6 步的信息展示，但无需暂停等待，可直接提交。
8. 获得本次明确确认或适用的预先授权后，保持第一次成功报价的模型、提示词、参考文件和参数完全不变，只增加 `--confirm-credits PAYABLE_CREDITS` 与一个稳定 `--idempotency-key` 再次运行同一 `generate` 命令。只能基于成功报价确认；失败报价、被修正过参数的旧报价都不能用于确认。`--confirm-credits 0` 是有效的免费生成确认。
9. 批量任务必须为每条生成准备独立 `--idempotency-key`；同一个 Codex 对话窗口里，所有模型体验中心生成命令都必须带同一个稳定 `--session-key`。服务端会按模型类型与模型 ID 隔离模型体验中心对话窗口：同一音频/视频模型复用同一个对话窗口，不同模型各自进入不同对话窗口。网络失败或响应不确定时只能用对应任务的原幂等键、原 session key 和原参数重试。不得换键；不得因为等待超时重新提交。
   批量任务执行后，必须确保每条任务的生成结果按模型回填到模型体验中心的对应对话窗口/session 中，结果清单包括目标名称、模型、任务 ID、会话 ID、状态、实际扣费、`output_id`、播放链接或本地下载路径、失败原因或退款状态；不得把同一模型的同一批次结果散落到多个模型体验中心对话、子任务或仅靠平台历史。最终回复用户时，也要按模型汇总对应模型体验中心对话里的批次结果。
10. 用 `cineflow audio task get|wait` 或 `cineflow video task get|wait` 查询任务。等待超时返回 `pending`，不是失败。任务失败时展示服务端错误与退款状态，不自动再次生成。
11. 成功后从任务输出读取 `output_id`，使用 `cineflow audio output download OUTPUT_ID` 或 `cineflow video output download OUTPUT_ID` 下载。默认不得覆盖已有文件；只有用户明确要求时才能传 `--overwrite`。

音频和视频生成由业务 Skill 基于模型列表返回的任务类型与 `--setting` 组合流程；CLI 只提供原子化报价、生成、查询和下载能力。

## macOS/Windows 媒体工具依赖

- 当用户在 macOS 或 Windows 上要求安装、配置或排查 `ffmpeg`、`ffprobe`、`ffplay`、`sox`、本地音频转写或视频抽帧能力，或预审流程发现缺少这些能力时，必须先读取 [macOS 和 Windows 媒体工具安装流程](references/media-tools-installation.md)。如果需要安装 Python 版 `openai-whisper`，先安装 `openai-whisper`，再运行 Skill 自带的 `scripts/install-whisper-tiny-model.py`：该脚本优先从七猫 CDN 下载 Hugging Face 格式 `openai/whisper-tiny` 权重，转换为 `whisper` 命令可直接加载的本地 `tiny.pt`；CDN 下载失败时，才允许从 Hugging Face 或 `HF_ENDPOINT=https://hf-mirror.com` 下载同一批权重并转换。
- 安装完成后必须验证 `ffmpeg -version`、`ffprobe -version`、`ffplay -version`、`sox --version`，以及本地转写命令可用性。若当前 PowerShell 会话找不到 `sox`，先按该流程补充当前会话 PATH，不要重复安装。
- macOS 优先用 Homebrew 安装 FFmpeg 和 SoX；Windows 不要优先用 winget 安装 FFmpeg，winget 的 FFmpeg 安装器可能长时间卡住。Windows 优先使用该流程中的 Gyan.dev 便携包安装 FFmpeg，并使用 winget 的 `ChrisBagwell.SoX` 安装 SoX。

## 素材问题诊断与修复

- 用户要求识别素材或生成视频问题、定位问题时间点、修复不过审、人物穿模、吞台词、音画不同步或故事版不一致等问题时，必须先读取 [素材问题诊断与提示词修复流程](references/material-remediation-workflow.md)。
- 需要判定具体问题类别或选择改写策略时，再读取 [素材问题目录](references/material-issue-catalog.md)。
- 用户一次要求处理多个分镜、多个集数或一个集数范围时，必须再读取 [多分镜与多集任务处理流程](references/multi-shot-remediation-workflow.md)，先拆成有序的单分镜任务再调用 CLI。
- 用户要求预审、审核、审片、质检、验收，或要求“预审规则”“预审结果格式”“审核结果模板”“PRD 输出格式”的项目、单集、多集或指定分镜时，先读取 [预审可启动性判断流程](references/review-readiness-workflow.md) 和 [成片预审执行流程](references/pre-review-workflow.md)。若预审意图不明确，先向用户介绍预审目标（明显穿帮、站位混乱、复制人、违规镜头、画风偏移、人物错乱、资产错漏、剧情缺漏；目标来源参考 https://x0sgcptncj.feishu.cn/wiki/MCFOwdo3jisIxVknJOCcsVKQnhK#share-LAqxdAp6voC9SdxCNkDc36Mdn9d），并等待用户确认是否开始预审。若未明确预审哪个项目，必须先用 `project list` 汇报当前团队下所有项目，并对每个项目用 `episode list` 汇报当前进度和集数，邀请用户明确项目、集或分镜范围。范围明确后，再调用 `cineflow review readiness` 进行可审性判断；多集或多分镜场景必须对每个目标分别调用 readiness，再汇总整体是否可预审。readiness 结果未允许预审时，不得执行内容预审；必须先向用户同步 blocker、可审目标和不可审目标，只有用户知情后明确确认继续预审可审部分或强制预审不完全 ready 目标，才可进入内容预审。预审时 CineFlow Skill 直接基于视频、抽帧、剧本、提示词、资产和转写结果完成视频画面、AI 成片质量与合规风险分析，并按 PRD 约定输出：先整体结论，再项目/集/分镜明细；多项目时先汇总表，再给项目明细；明细表必须使用 Codex 可渲染的 Markdown 表格，不得用全角竖线纯文本表或把表格放入代码块；存在 blocker 时必须单列“部分目标不可预审/未预审”；`pre-review` 只输出可执行结论、问题类型和建议，不输出内部推理。

## 预审结果格式

当用户在意“预审结果格式”“审核结果模板”或 PRD 要求的输出样式时，必须按 [成片预审执行流程](references/pre-review-workflow.md) 的结果模板输出，尤其要保证先整体结论、再 Markdown 明细表、再 blocker 说明。Markdown 表格不得放进代码块，单元格内容如含半角 `|` 必须转义为 `\|`。
- 未获得用户对台词修改的明确授权时，必须逐字保留原台词。敏感词、侮辱性内容、错读、生僻字或过审风险只能标记，不能以优化、弱化或方便生成为理由改写台词。
- 本文件中的平台操作、安全、引用、revision、报价、确认和幂等规则优先于 references。新增、删除或替换资产引用必须使用 `shot asset` 原子命令，不能用提示词更新冒充；字幕、故事版、首帧和独立发音字段仍不在当前 CLI 的修改范围内。

## 制作集意图校验

用户要求制作、补齐、继续或重做一个或多个分集时，必须先读取 [制作集意图校验与路由](references/episode-production-intent-workflow.md)。该流程负责项目与分集范围校验、逐集制作进度观察、全新集判断、已有进度的意图推测、人工确认队列和确认后路由。

制作前对每个目标集分别运行 `cineflow review readiness`，只读取其中与当前集相关的 `TASK_RUNNING` 原因、任务类型、任务 ID 和范围，不使用 `can_start` 判断能否制作。意图推测不能授权平台写入、报价、覆盖或扣除积分；必须先向用户展示当前状态、推测意图、依据和影响，等待明确确认。

## 项目与本集文件创作

用户要求从本地剧本新建项目、完整替换某一集剧本，或将本地图片作为本集资产上传时，只使用以下文件输入命令。剧本文件必须是本地有效 UTF-8 文件；不要凭空添加内联剧本参数、项目模式参数或项目/团队资产 ID。创建通用模式项目时运行：

```bash
cineflow project create --name "项目名称" --script-file /path/to/script.txt
```

该命令只接受名称和 `--script-file`；不得臆造 `--mode general`。创建后从响应中取得项目 ID，再运行 `cineflow project list --search "项目名称"`、`cineflow episode list --project-id PROJECT_ID` 和 `cineflow episode script get --project-id PROJECT_ID --episode 1`，确认目标项目、首集和实际保存的剧本正文。

替换既有剧本前，先用 `cineflow project list`、`cineflow episode list --project-id PROJECT_ID` 和 `cineflow episode script get --project-id PROJECT_ID --episode N` 确认目标。使用本地完整正文文件运行：

```bash
cineflow episode script update --project-id PROJECT_ID --episode N --file /path/to/replacement.txt
```

`update` 会完整替换本集剧本正文，不是局部 patch；必须先向用户说明覆盖影响，未经明确授权不得提交。成功后立即再次运行 `cineflow episode script get --project-id PROJECT_ID --episode N`，读取并确认服务端保存的完整正文；不要使用不存在的 `cineflow episode script replace`。

本地 JPEG/PNG 图片上传是本集级资产操作。上传前先运行 `cineflow episode asset list --project-id PROJECT_ID --episode N` 确认目标集和当前本集资产，再将同一类型的文件放在同一批中：

```bash
cineflow episode asset upload --project-id PROJECT_ID --episode N --type scene --file /path/to/first.png --file /path/to/second.png
```

每批必须显式选择一个 `--type character|scene|prop`，同一批只能上传同类型文件；不同类型拆成独立批次。上传后立即运行 `cineflow episode asset list --project-id PROJECT_ID --episode N`，确认每个本地文件已作为正确类型的本集资产出现。本集上传不得关联项目资产库或团队资产库，也不得传入项目资产 ID、团队资产 ID 或视图 ID。不得把本集上传替换成 `cineflow shot asset upload`：后者仅用于向单个分镜上传并绑定素材，需遵循分镜 revision 流程，不能替代本集级批量上传。

## 全新一集制作

制作集意图校验已经确认目标为全新集后，必须读取 [全新单集制作流程](references/new-episode-production-workflow.md)。本节保留必须立即执行的全局门禁；详细核验、写入、生成、恢复、汇报和边界规则以该流程为准。

用户要求“制作/生成某项目第 N 集视频”时，先运行 `cineflow project list`、`cineflow project asset list --project-id PROJECT_ID`、`cineflow episode list`、`cineflow episode script get`、`cineflow episode asset list`和 `cineflow shot list`，读取完整分页结果；再运行 `cineflow review readiness --project-id PROJECT_ID --episode N`，只用其中的 `TASK_RUNNING` 原因盘点运行中任务，不把 `can_start` 当作可以开始制作或生成的结论。`shot list` 为空表示全新一集制作；非空时退出本流程，根据用户意图进入已有分镜修改或整集重做流程。

集内制作校验必须读取 [集内制作校验流程](references/episode-production-validation-workflow.md)。项目资产盘点使用 `cineflow project asset list --project-id PROJECT_ID` 返回的角色、场景、道具、素材、状态、视角、图片和角色音色；判断角色是否绑定音色时，只看该命令返回的 `asset_type=character` 的条目，并用其 `voice` 字段判断角色是否绑定音色。本集绑定事实只使用 `cineflow episode asset list`。不得从名称、摘要或缺失字段猜测状态。缺少任何必须核验的明确字段或查询能力时，按能力 blocker 停止；无台词次要角色缺音色和全局画风预设为空仍按 PRD 作为非阻塞例外。

进入全新一集制作后，先向用户汇报已读取的状态，顺序固定为：项目名称和弱化展示的 ID；单集标题、集号、剧本来源、更新时间和内容摘要；本集资产的名称、类型、状态和弱化展示的 ID；已有分镜数量（此时应为 0）；运行中任务的 `task_kind`、任务 ID 和范围，`TASK_RUNNING` 统一表述为“进行中”，没有时明确写“无”。项目或集数不唯一、剧本缺失或为空、查询未完成、剧本需要的关键资产缺失或未就绪、存在会改变本集剧本/资产/分镜的运行中任务时，核验不通过：只汇报 blocker 并停止，不得假定稍后会自动就绪。

核验通过后，在分镜思路前先执行**前置取参**，读取后续 skill 需要的全局预设画幅、默认视频模型、默认视频分辨率和全局画风预设。运行 `cineflow episode video defaults get --project-id PROJECT_ID --episode N` 读取画幅、默认视频模型和默认视频分辨率；运行 `cineflow episode art-style get --project-id PROJECT_ID --episode N` 读取全局画风预设的实际提示词内容。默认不读取故事板配置或是否使用故事板参考；只有用户明确要求处理故事板时，才按额外步骤读取和使用相关信息。画幅、模型参数和全局画风预设只使用 CLI 明确返回值；全局画风预设没有提示词内容时写“无”，不得使用 ID、展示名或硬编码默认画风；缺少明确字段时停止并说明能力缺口。

只在本地基于已读取的剧本、资产和前置参数制作方案，并按以下顺序推进；每个“人工确认断点”都必须等待用户明确确认或修改，未经对应断点确认不得进入下一阶段，不得一次性展示全部内容后只请求一次确认：

0. **前置取参**：运行 `cineflow episode video defaults get --project-id PROJECT_ID --episode N` 读取全局预设画幅、默认视频模型和默认视频分辨率；运行 `cineflow episode art-style get --project-id PROJECT_ID --episode N` 读取全局画风预设的实际提示词内容。默认不读取故事板配置或是否使用故事板参考；只有用户明确要求处理故事板时，才作为额外步骤处理。没有提示词内容时写“无”，缺少其他明确字段时停止，不使用 ID、展示名或硬编码默认画风。
1. **分镜思路**：说明叙事节奏、场景衔接、角色与资产使用思路；人工确认断点：确认分镜思路、时长分布和总时长预估。
2. **生成文字分镜与全集连续性约束**：逐镜描述时长、景别、运镜、事件或景象、原台词和剧情目的，并补充全集连续性约束；此阶段只是未落库策划稿，不是平台 `prompt_text`。人工确认断点：确认参考对象、对白和音效。如用户要求根据文字分镜与全集连续性约束生成单集故事板（捡重点的生分镜画面），为其生成，且单集故事板中对应画面作为对应片段的分镜约束。
3. **划分分镜片段**：逐镜列出计划使用的本集参考对象、对白和音效；人工确认断点：用户确认或修改引用、台词和音效后，才能划分片段。用户要求某片段增加额外生视频参考文件时，网页端归档到本集素材后再引用；用户要求每个分镜片段故事板时可作为额外步骤。
4. **生成分镜片段**：把已确认的文字分镜聚合成片段，输出段落个数（任务数）、段落内容（可含多个文字分镜）、预计积分消耗和视频模型参数。视频模型参数默认沿用当前默认值，除非用户明确要求额外修改。

先展示分镜思路并等待用户确认或修改；确认后再生成文字分镜与全集连续性约束。分镜思路阶段必须确认时长分布和总时长预估；文字分镜阶段必须确认参考对象、对白和音效；用户修改其中一项时，只更新受影响内容并重新展示确认，不重写已经确认且不受影响的内容。

展示完整方案后，明确请求用户确认或提出修改。策划确认、最终提示词/配置确认和积分确认是三个独立授权范围；用户只能明确免除指定目标和阶段的逐次确认，不能从“继续”“帮我生成”等笼统表述推断，也不得扩展到积分或其他集。初始生成请求不等于方案确认。用户确认方案前，不得运行 `cineflow shot insert` 或 `cineflow shot duplicate|delete`，不得运行 `cineflow shot asset import|upload|remove`，不得运行 `cineflow shot prompt update`，不得运行 `cineflow shot video quote|generate`；不得上传本地素材或生成幂等键，不得创建任何视频任务或扣除积分。

用户确认方案后，重新读取并比较项目、剧本、本集资产、空分镜状态和运行中任务；其他快照变化时先评估是否影响待制作视频：有影响则停止，先展示差异、受影响分镜和已完成进度，等待用户决定更新或取消；用户选择更新后才修订方案并再次确认。有证据证明无影响则继续，并在完成汇报中记录变化和判断依据。用户已明确给出“剧本发生变化，但经对照确认不影响目标分镜；继续完成当前集”一类前置结论时，若目标分镜 revision 未变化、运行中任务和资产快照未阻塞，继续制作或提交当前目标，不得仅因剧本版本变化暂停；最终汇报必须注明制作期间发生剧本变更，并给出“不影响当前分镜”的具体依据，例如变更段落不在目标分镜覆盖范围、目标分镜台词和动作未被改动、引用资产和生成配置无需调整。目标分镜 revision 变化始终停止，不能自动合并或沿用旧 revision。完成快照复核后，方案确认只授权创建已确认的空分镜和加入已确认的本集资产，不授权写入平台 `prompt_text` 或创建视频任务。完成结构和资产写入后，重新读取每镜最新 `edit_revision`，查询可用模型，在本地把已确认的策划稿准备为候选 `prompt_text` 和生成配置；按“修改并生成”流程先展示完整 diff、台词逐字一致性、引用与配置变化和报价，等待用户针对最终提示词和配置明确确认，之后才能运行 `cineflow shot prompt update`。保存后重新报价。方案确认不等于积分确认；仍须展示逐镜权威报价、总积分和余额，取得单独的明确付费确认后才能创建视频任务。多个分镜提交视频任务必须连续发起：为每个分镜准备独立稳定幂等键，按目标清单连续发起多个单目标 `cineflow shot video generate` 提交请求；连续发起只表示 Agent 在获得确认后快速依次调用多个单目标命令，每次 CLI 调用仍只能包含一个 `--episode` 和一个 `--shot`，不得把多个集号或镜号合并为列表、范围、JSON 数组或空格分隔参数；不得等待某个视频任务生成完成后才提交下一个。全部提交请求发起后，再统一等待或查询任务结果。只有提交结果不确定的单个分镜，才复用该分镜原载荷和原幂等键单独查询或重试。

新制作一集生成阶段的失败任务，可以在分析错误原因并只修改失败片段必要载荷后，跳过用户对修复提示词、生成配置和积分的二次确认，自动重新报价并提交；自动修复重提最多 3 次，不含首次生成失败。该例外只适用于全新单集制作首次生成批次里的失败重抽，不适用于正常重抽、补素材、已有分镜质量修复或用户指定的单镜重抽；正常重抽和补素材仍必须展示 diff、报价并等待用户确认。

## 分镜编排、配置与整集重做

1. 用 `cineflow shot list` 是否返回分镜判断单集制作状态：返回至少一条分镜表示已进入分镜制作，空列表表示尚无分镜。单集制作状态仍以 `shot list` 为准。
2. 每次写操作先运行 `cineflow episode script get`、`cineflow episode asset list`、`cineflow shot list`，并对目标镜头运行 `cineflow shot get`。保存剧本正文/更新时间、本集资产 ID 与状态、分镜顺序、目标分镜 `edit_revision` 和生成配置；真正提交每次写操作前再次读取并比较剧本、本集资产和目标分镜快照，以检测 Web 或其他会话的变化。快照变化时先评估是否影响待制作视频：有影响则停止，先展示差异、受影响分镜和已完成进度，等待用户决定更新或取消；用户选择更新后才重新复核。有证据证明无影响则继续，并在完成汇报中记录变化和判断依据。剧本发生变化，但经对照确认不影响目标分镜时，可以继续制作或提交当前目标；完成汇报必须注明剧本变更并给出“不影响当前分镜”的具体依据。目标分镜 revision 变化始终停止，不能自动合并或沿用旧 revision。
3. 分镜结构使用独立原子命令：`cineflow shot insert` 在开头或 `--after-shot` 后插入空分镜，`cineflow shot duplicate` 复制创作输入但不复制生成历史，`cineflow shot delete` 删除分镜及关联记录。当前没有分镜重排能力，不得用删除后重建模拟排序。
4. 给分镜加本集已有素材时，从 `cineflow episode asset list` 读取精确 `asset_id`；多个条目共享 `asset_id` 时必须带 `--view-id` 选择对应视角，然后运行 `cineflow shot asset import --asset-id ... [--view-id ...] --revision ...`。只有用户提供本地文件时运行 `cineflow shot asset upload --file ... --revision ...`；本地上传默认保存为本集 `material` 素材，再加入分镜。上传后若绑定遇到 revision 冲突，素材仍保留在本集，重新读取快照后用 `shot asset import` 继续。移除时用 `cineflow shot asset remove --asset-id ... [--view-id ...] --revision ...`；同一资产已有多个视角引用时必须指定 `--view-id`。`shot asset import|upload|remove` 只修改当前分镜参考素材，不修改 `prompt_text`；写入 `prompt_text` 前，所有画面中实际需要被模型参考的角色、场景、道具或本地素材必须已经通过 `cineflow shot asset import|upload` 加入当前分镜。需要在文字分镜/生视频提示词中新增、删除或移动 `@名称` 时，必须重新读取 `shot get` 或 `shot reference list` 后使用 `shot prompt update`。不要删除本集资产本身。
5. 修改提示词、时长、模型或分辨率前先运行 `cineflow shot model list`，只选 `compatible=true` 的模型或根据 `incompatibility_reasons` 调整当前配置和素材。`prompt_text` 同时表示文字分镜和生视频提示词；用 `cineflow shot prompt update` 的 `--file`、`--duration-seconds`、`--model-id`、`--resolution` 组合一次提交显式变更，并始终携带最新 `--revision`。未提交的配置字段保持不变。
6. 诊断连续失败时读取最近一次失败和最近最多 5 条 `cineflow shot record list` 历史，比较 `configuration_snapshot` 中的提示词、文字分镜、时长、模型、分辨率、画风和参考素材，再结合状态、任务 ID、失败信息和时间确认唯一证据假设。真人素材或合规相关失败进入人工确认；其他有明确修复方向的失败只修改必要字段。用户明确授权指定目标的自动重试且同时给出积分上限时，该重试授权覆盖有失败证据证明必要的提示词或生成配置变更；自动执行仅限已授权目标和预授权积分上限内，超出任一范围时停止并请求确认。失败修复改变载荷时，必须重新进入“修改并生成”流程：展示必要变更，重新检查模型兼容性，使用最新 revision 保存，重新取得权威报价并校验未超过预授权积分上限，为该次付费尝试使用新的稳定幂等键；只有该次尝试响应不确定时才复用其载荷和幂等键。失败计数累计包括初始失败，累计失败最多 3 次（包括初始失败）；没有证据、没有适用授权或达到上限时停止，不得进行第四次付费尝试。
7. 用户要求“整集分镜不要了，重新做”“整集重做、之前的视频不要了”或明确放弃本集已有分镜时，先说明这是破坏性结构操作：会删除当前集已有分镜及其关联生成记录，已生成媒体对象不保证物理删除。获得明确确认后，重新读取 `cineflow shot list`，按当前分镜列表逐个运行 `cineflow shot delete`，串行删除所有的分镜；不得并发删除。每删一个分镜后重新读取 `cineflow shot list`，用最新列表继续删除剩余分镜，避免镜号变化或并发写入导致删错。全部删除完成且 `shot list` 为空后，再进入全新一集制作流程，再根据剧本重新生成：重新读取项目、剧本、本集资产、运行中任务和 readiness，重新展示分镜思路、生成文字分镜与全集连续性约束、划分分镜片段、生成分镜片段，并按对应人工确认断点等待确认。

## 修改并生成

1. 用 `project list`、`episode list` 和 `shot list` 消除名称或编号歧义，写操作最终使用稳定 `project_id`。CLI 会把集号、镜头号解析为稳定 ID，和用户交流时可以把id稍微弱化一些,用户的操作面板中不太能看到id。
2. 按上一节读取并比较剧本、本集资产和目标分镜快照；需要修改资产时先完成 `shot asset import|upload|remove`，这些命令只维护分镜 `reference_files`，不会也不应顺手改 `prompt_text`；随后重新读取目标分镜和最新 `edit_revision`，确认 `shot reference list` 已返回可用引用后，再改提示词或生成配置。
3. 改写 `prompt_text` 时可以新增、删除、移动或重复当前分镜可用的 `@名称`；所有新增 mention 必须来自最新 `shot reference list` / `shot get.references` 返回的当前分镜参考素材，不能猜测引用 ID，也不能用 `shot asset` 命令冒充提示词修改。提示词正文必须使用这些当前分镜引用返回的 `@mention`，不得只在纯文字里写资产名称、角色名或场景名来替代分镜资产导入；发现提示词需要引用尚未加入当前分镜的资产时，先停止提示词写入，完成 `cineflow shot asset import|upload` 并重新读取 revision 与引用。遇到未知或歧义引用就停下并向用户说明。`available=false` 只表示该 mention 当前失效，不得把它当作提示词保存 blocker；保存前列出失效 mention 并向用户说明：提示词可以保存，但视频生成前必须通过 `shot asset import|upload|remove` 处理失效引用。未经授权不得改变原台词。
4. 在每个分镜独立的临时 UTF-8 文件中准备新正文，向用户展示完整 diff、台词逐字一致性，以及模型、时长、分辨率和引用变化。
5. 运行 `shot video quote` 和 `credits balance`，展示预计积分与当前余额。
6. 默认分别等待用户明确确认提示词/配置与积分。适用的明确免确认只跳过对应目标和阶段的等待，不跳过展示，也不扩展到积分确认或其他阶段；执行 `shot prompt update` 和 `shot video generate` 前，分别检查该操作所需的明确确认或适用免确认。
7. 用读取时的 `edit_revision` 执行 `shot prompt update`。Revision 冲突时不要自动合并；重新读取分镜并重新展示 diff。
8. 保存后重新报价。若总积分或 `pricing_version` 变化，不提交生成；保留已保存提示词并重新请求付费确认。
9. 生成一个稳定幂等键并运行 `shot video generate --confirm-credits ... --pricing-version ... --idempotency-key ...`。网络失败或响应不确定时只能用同一个幂等键重试，禁止换键。
10. 使用 `--wait` 或 `task wait` 有限等待。超时返回 `pending`，不是失败，也不得因此重新提交生成。

## 多分镜与多集任务

- `--episode` 和 `--shot` 每次只接受一个整数。不得把逗号列表、范围或多个编号直接传给单次 CLI 命令。
- 先展示目标清单和执行顺序，再按 [多分镜与多集任务处理流程](references/multi-shot-remediation-workflow.md) 处理。每个分镜都必须独立读取详情、引用和最新 `edit_revision`，独立生成 diff，并独立更新。
- 用户可以一次确认已经完整展示的批次；确认范围之外、新增或重新计算的修改必须重新确认。不得从“全部处理”“继续”等表述推断用户确认了尚未展示的 diff、报价或积分。
- 一个分镜失败时记录其状态，不得把它的 revision、临时文件、引用、报价、幂等键或结果复用于其他分镜。鉴权、团队、协议或服务整体故障时停止整个批次。
- 批量修改提示词不等于批量生成视频。只有用户另行要求生成并确认每个分镜的最终配置和权威报价后，才能提交生成；多个分镜提交视频任务必须连续发起：按目标清单连续发起多个单目标提交请求；连续发起只表示 Agent 在获得确认后快速依次调用多个单目标命令，每次 CLI 调用仍只能包含一个 `--episode` 和一个 `--shot`，不得把多个集号或镜号合并为列表、范围、JSON 数组或空格分隔参数；不得等待某个视频任务生成完成后才提交下一个；全部提交请求发起后，再统一等待或查询任务结果。
- 用户一次给出多个集或多个分镜时，必须分别调用 `cineflow review readiness`，不能把多个目标塞进一次 readiness 命令里，也不能只凭单个目标的结果推断整体可审性；最终要把每个目标的 blocker 和整体结论一起告诉用户。
- 批量处理完成或部分完成后，必须使用同一个稳定 `--session-key`，并把生成结果按模型回填到模型体验中心各自的对话窗口/session 中：同一模型的结果进入同一个对话窗口，不同模型各自进入不同对话窗口。结果清单包括每个分镜/集数的模型、更新状态、生成任务状态、记录选用状态、结果 URL/下载路径、实际扣费和失败原因。即使平台历史可见，也不能把同一模型的同一批次结果散落到多个模型体验中心对话；最终回复用户时要按模型汇总对应对话窗口里的结果。

## 选用与下载

- 分镜此前没有选用记录时，首次成功生成会自动选用；根据 `auto_selected` 和最新分镜状态确认结果。
- 已有选用记录时，新视频只新增记录。先把 `result_url` 提供给用户检查，获得用户明确满意确认后才能运行 `shot record select`。
- CLI 不下载文件。选用完成后，使用当前 Agent 自身的终端或文件工具访问 `result_url` 下载到用户指定位置。
- URL 失效时重新运行 `shot record list` 获取新 URL，不要重新生成视频。

## 错误恢复

- `PROMPT_REVISION_CONFLICT`：重新读取，不自动覆盖。
- `MENTION_UNKNOWN` / `MENTION_AMBIGUOUS` / `MENTION_SET_CHANGED`：不保存部分结果，保持引用集合原样。
- `CREDIT_QUOTE_CHANGED`：重新展示报价并请求确认。
- `INSUFFICIENT_CREDITS`：不提交任务。
- `IDEMPOTENCY_CONFLICT`：原键已用于其他载荷，停止并检查调用历史。
- `MODEL_UNAVAILABLE` / `INVALID_IMAGE_SETTING` / `INVALID_AUDIO_SETTING` / `INVALID_VIDEO_SETTING` / `REFERENCE_*`：重新读取对应 `model list`，按服务端当前能力修正请求后重新报价。
- `GENERATION_SUBMISSION_FAILED` 且 `retryable=true`：只用原幂等键查询或重试。
- `TASK_FAILED`：读取最近失败和最多 5 条历史；按全新单集制作流程的证据、合规、授权与累计失败最多 3 次（包括初始失败）上限处理。
- CLI 版本即将停止支持时，可完成仍兼容的操作并告知用户；已不支持时重新读取平台 `/cli` 文档，安装匹配版本的 CLI 和 Skill 后再继续。

## 版本更新

当用户要求更新，或 `cineflow doctor` 提示当前版本即将停止支持、已经不受支持时，先读取最新版 [CineFlow CLI 安装指南](https://cdn-front.qimao.com/qmniu/cineflow/cli/cineflow-cli-installation-guide.md)，再严格按照其中与当前操作系统及 Agent 运行环境匹配的命令执行更新。安装命令和安装位置以该指南为准，不要凭记忆复用旧命令。

- 若 `cineflow doctor` 发现新版本但当前版本仍受支持，向用户说明当前版本、最新版本及相关公告，询问是否更新；获得用户明确同意后再执行更新。用户暂不更新时，可以继续执行兼容操作。
- 必须同时更新 CLI 与完整的同版本 `cineflow-cli` Skill；不要只替换 CLI 二进制、单个 `SKILL.md` 或部分 references。
- 将 Skill 安装到当前 Agent 实际使用的 Skill 目录。安装完成后运行 `cineflow version` 和 `cineflow doctor`，确认版本及兼容状态。
- 更新会替换当前 Skill。验证成功后，重新读取已安装的 `cineflow-cli/SKILL.md`，按新版本规则继续操作，并向用户报告 CLI 版本、CLI 与 Skill 的安装位置及验证结果。
