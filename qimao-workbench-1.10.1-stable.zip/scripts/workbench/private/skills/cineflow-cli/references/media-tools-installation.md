# macOS 和 Windows 媒体工具安装流程

本流程用于帮助 macOS 或 Windows 用户安装 CineFlow 常用的本地音视频处理工具：`ffmpeg`、`ffprobe`、`ffplay`、`sox`，以及预审剧情缺漏所需的本地音频转写能力。目标是尽量一次成功，并避免已知容易卡住或下载到 HTML 的安装方式。

## macOS 安装流程

macOS 上优先使用 Homebrew。安装前先检查：

```bash
command -v ffmpeg ffprobe ffplay sox
ffmpeg -version | head -n 1
ffprobe -version | head -n 1
ffplay -version | head -n 1
sox --version
command -v whisper whisper-cpp whisper-cli || true
```

缺少工具时安装：

```bash
if ! command -v brew >/dev/null 2>&1; then
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
fi

brew install ffmpeg sox
```

Apple Silicon 如安装后当前 shell 找不到 `brew` 或工具，先补充 Homebrew PATH：

```bash
if [ -x /opt/homebrew/bin/brew ]; then
  eval "$(/opt/homebrew/bin/brew shellenv)"
elif [ -x /usr/local/bin/brew ]; then
  eval "$(/usr/local/bin/brew shellenv)"
fi
```

安装完成后必须验证：

```bash
ffmpeg -version | head -n 1
ffprobe -version | head -n 1
ffplay -version | head -n 1
sox --version
command -v ffmpeg ffprobe ffplay sox
```

本地没有音频转写命令时，优先安装 `whisper-cpp`：

```bash
brew install whisper-cpp
command -v whisper-cpp whisper-cli whisper || true
```

如果 Homebrew 安装的转写命令名称随版本变化，使用 `brew info whisper-cpp` 和 `brew list whisper-cpp` 查找实际可执行文件；验证时必须能对一个短音频文件完成转写。若当前环境另有系统级转写能力，也可以复用，但必须先跑一个短样本确认可用。

如果当前环境需要安装 Python 版 `openai-whisper`，优先使用清华 PyPI 镜像安装 Python 包本身：

```bash
export PIP_INDEX_URL=https://pypi.tuna.tsinghua.edu.cn/simple
python -m pip install --upgrade openai-whisper
```

`openai-whisper` 的 `whisper` 命令不能直接读取 Hugging Face 格式模型目录，也不会读取 `WHISPER_MODEL_URL`。当前七猫 CDN 发布的是 Hugging Face 格式 `openai/whisper-tiny` 权重，地址为 `https://cineflow-prod.oss-cn-beijing.aliyuncs.com/qmniu/cineflow/cli/models/whisper/openai/whisper-tiny/`，因此必须使用 Skill 自带转换脚本先把 CDN 权重转换为 `whisper` 命令可加载的本地 `tiny.pt`。转换脚本默认优先从七猫 CDN 下载；CDN 下载失败时，才允许从 Hugging Face 下载同一批权重。国内网络需要 Hugging Face 镜像时，先设置 `HF_ENDPOINT=https://hf-mirror.com`。

```bash
CODEX_HOME="${CODEX_HOME:-$HOME/.codex}"
export HF_ENDPOINT=https://hf-mirror.com
python "$CODEX_HOME/skills/cineflow-cli/scripts/install-whisper-tiny-model.py"
```

脚本输出的第一行是转换后的 `tiny.pt` 路径。转写时必须把该路径作为 `--model` 值传给 `whisper`，不要写成 `--model tiny --model_dir PATH`；`--model tiny` 会触发 `openai-whisper` 官方 checksum 校验，无法复用由 CDN Hugging Face 权重转换出的本地文件。

```bash
CODEX_HOME="${CODEX_HOME:-$HOME/.codex}"
WHISPER_TINY_PT="$(python "$CODEX_HOME/skills/cineflow-cli/scripts/install-whisper-tiny-model.py" | sed -n '1p')"
whisper input.wav --model "$WHISPER_TINY_PT" --language zh --output_format txt
```

## Windows 工具选择

- FFmpeg：使用 Gyan.dev 的 `ffmpeg-release-essentials.zip` 便携包，安装到 `%LOCALAPPDATA%\CodexTools\bin`。该包同时提供 `ffmpeg.exe`、`ffprobe.exe`、`ffplay.exe`。
- SoX：使用 winget 源中的 `ChrisBagwell.SoX`。不要用 `Invoke-WebRequest` 直接下载 SourceForge `/download` 链接；它可能返回 HTML 页面而不是 zip。
- 音频转写：优先复用当前 Agent 或系统已有的转写能力；没有时使用用户级 Python 虚拟环境安装 `openai-whisper`，并先确认 `ffmpeg` 已可用。安装 Whisper 模型时运行 Skill 自带的 `scripts/install-whisper-tiny-model.py`，优先从七猫 CDN 下载 Hugging Face 格式权重并转换为 `whisper` 命令可加载的本地 `tiny.pt`；CDN 下载失败时，才允许从 Hugging Face 或 `HF_ENDPOINT=https://hf-mirror.com` 下载同一批权重并转换。
- PATH：把 `%LOCALAPPDATA%\CodexTools\bin` 写入用户 PATH；SoX 安装后 winget 会写入自己的包路径，当前会话仍需手动补充 PATH。

## 安装前检查

先运行：

```powershell
Get-Command ffmpeg,ffprobe,ffplay,sox,whisper -ErrorAction SilentlyContinue | Select-Object Name,Source,Version
```

已经可用的工具不需要重复安装。若四个命令都存在，直接进入“验证”。

## 推荐一键安装命令

需要联网下载和写入用户 PATH。运行前向用户说明将安装到用户本地目录，不写入系统级目录。

```powershell
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$installRoot = Join-Path $env:LOCALAPPDATA 'CodexTools'
$downloads = Join-Path $installRoot 'downloads'
$ffmpegRoot = Join-Path $installRoot 'ffmpeg'
$binDir = Join-Path $installRoot 'bin'
New-Item -ItemType Directory -Force -Path $downloads, $ffmpegRoot, $binDir | Out-Null

function Add-UserPathEntry {
  param([Parameter(Mandatory = $true)][string]$PathEntry)
  $current = [Environment]::GetEnvironmentVariable('Path', 'User')
  $parts = @($current -split ';' | Where-Object { $_ })
  if ($parts -notcontains $PathEntry) {
    $next = if ($current) { "$PathEntry;$current" } else { $PathEntry }
    [Environment]::SetEnvironmentVariable('Path', $next, 'User')
  }
  if (($env:Path -split ';') -notcontains $PathEntry) {
    $env:Path = "$PathEntry;$env:Path"
  }
}

$needFfmpeg = -not (Get-Command ffmpeg -ErrorAction SilentlyContinue) -or -not (Get-Command ffprobe -ErrorAction SilentlyContinue) -or -not (Get-Command ffplay -ErrorAction SilentlyContinue)
if ($needFfmpeg) {
  $ffmpegZip = Join-Path $downloads 'ffmpeg-release-essentials.zip'
  if (-not (Test-Path $ffmpegZip)) {
    Invoke-WebRequest -Uri 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip' -OutFile $ffmpegZip
  }
  tar -tf $ffmpegZip | Select-Object -First 1 | Out-Null
  Expand-Archive -Path $ffmpegZip -DestinationPath $ffmpegRoot -Force
  $ffmpegExe = Get-ChildItem -Path $ffmpegRoot -Recurse -Filter ffmpeg.exe | Select-Object -First 1 -ExpandProperty FullName
  if (-not $ffmpegExe) { throw 'ffmpeg.exe not found after extraction' }
  $ffmpegBin = Split-Path $ffmpegExe -Parent
  Copy-Item -LiteralPath (Join-Path $ffmpegBin 'ffmpeg.exe') -Destination (Join-Path $binDir 'ffmpeg.exe') -Force
  Copy-Item -LiteralPath (Join-Path $ffmpegBin 'ffprobe.exe') -Destination (Join-Path $binDir 'ffprobe.exe') -Force
  Copy-Item -LiteralPath (Join-Path $ffmpegBin 'ffplay.exe') -Destination (Join-Path $binDir 'ffplay.exe') -Force
}
Add-UserPathEntry -PathEntry $binDir

if (-not (Get-Command sox -ErrorAction SilentlyContinue)) {
  winget install --id ChrisBagwell.SoX --exact --source winget --accept-source-agreements --accept-package-agreements --silent
}

$soxExe = Get-Command sox -ErrorAction SilentlyContinue
if (-not $soxExe) {
  $soxExePath = Get-ChildItem -Path (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages') -Recurse -Filter sox.exe -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
  if ($soxExePath) {
    Add-UserPathEntry -PathEntry (Split-Path $soxExePath -Parent)
  }
}

ffmpeg -version | Select-Object -First 1
ffprobe -version | Select-Object -First 1
ffplay -version | Select-Object -First 1
sox --version
```

如果没有可用的音频转写命令，继续安装用户级 Whisper 环境：

```powershell
$ErrorActionPreference = 'Stop'
$whisperRoot = Join-Path $env:LOCALAPPDATA 'CodexTools\whisper-venv'
if (-not (Test-Path $whisperRoot)) {
  py -3 -m venv $whisperRoot
}
& (Join-Path $whisperRoot 'Scripts\python.exe') -m pip install --upgrade pip
$env:PIP_INDEX_URL = 'https://pypi.tuna.tsinghua.edu.cn/simple'
$env:HF_ENDPOINT = 'https://hf-mirror.com'
& (Join-Path $whisperRoot 'Scripts\python.exe') -m pip install --upgrade openai-whisper
$whisperCmd = Join-Path $whisperRoot 'Scripts\whisper.exe'
if (-not (Test-Path $whisperCmd)) { throw 'whisper.exe not found after installation' }
& $whisperCmd --help | Select-Object -First 5
Add-UserPathEntry -PathEntry (Split-Path $whisperCmd -Parent)
$CodexHome = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $HOME '.codex' }
$modelInstaller = Join-Path $CodexHome 'skills\cineflow-cli\scripts\install-whisper-tiny-model.py'
$modelInstallOutput = & (Join-Path $whisperRoot 'Scripts\python.exe') $modelInstaller
$whisperTinyPt = $modelInstallOutput | Select-Object -First 1
if (-not (Test-Path $whisperTinyPt)) { throw "converted whisper model not found: $whisperTinyPt" }
Write-Output "WHISPER_TINY_PT=$whisperTinyPt"
```

## 验证

安装完成后必须运行：

```powershell
ffmpeg -version | Select-Object -First 1
ffprobe -version | Select-Object -First 1
ffplay -version | Select-Object -First 1
sox --version
Get-Command ffmpeg,ffprobe,ffplay,sox | Select-Object Name,Source
Get-Command whisper -ErrorAction SilentlyContinue | Select-Object Name,Source
```

预期结果：

- `ffmpeg`、`ffprobe`、`ffplay` 来自 `%LOCALAPPDATA%\CodexTools\bin`。
- `sox` 来自 winget 的 `ChrisBagwell.SoX` 包目录，或当前会话 PATH 已包含该目录。
- `whisper` 来自当前系统已有命令，或 `%LOCALAPPDATA%\CodexTools\whisper-venv\Scripts\whisper.exe`，且当前会话 PATH 已包含该目录。使用 Python 版 `openai-whisper` 时，必须已经通过 `scripts/install-whisper-tiny-model.py` 得到本地 `tiny.pt`，后续转写用 `whisper input.wav --model PATH_TO_TINY_PT`；如果脚本输出 `source=` 是七猫 CDN 地址，说明模型来源是七猫 CDN，如果 CDN 失败则会回退到 Hugging Face 或 `HF_ENDPOINT` 指向的镜像。

预审前还必须验证抽帧和转写能力：

```bash
# macOS / Linux shell 示例
ffmpeg -v error -i input.mp4 -vf fps=2 frame_%06d.jpg
ffmpeg -v error -i input.mp4 -vn -ac 1 -ar 16000 audio.wav
```

```powershell
# Windows PowerShell 示例
ffmpeg -v error -i input.mp4 -vf fps=2 frame_%06d.jpg
ffmpeg -v error -i input.mp4 -vn -ac 1 -ar 16000 audio.wav
```

抽帧能力验证必须使用 `fps=2` 或 `fps=3`，与预审流程保持一致。转写能力验证必须对短音频样本实际运行一次；只看到 `--help` 不足以证明模型、依赖和运行环境可用。

## 已知问题与恢复

- winget 安装 FFmpeg 在部分 Windows 环境中可能长时间卡住；不要把它作为首选路径。若已经有卡住的 winget 进程，先向用户说明情况，再结束该 winget 进程并改用本流程的 FFmpeg 便携包。
- SourceForge `/download` 链接用 `Invoke-WebRequest` 可能得到 HTML，文件头通常是 `3C 21 64 6F...`。不要解压这种文件，也不要把它当 SoX zip 使用。
- PowerShell 旧会话不会自动加载新写入的用户 PATH。安装后若 `sox` 找不到，先查找 `%LOCALAPPDATA%\Microsoft\WinGet\Packages` 下的 `sox.exe`，把其所在目录加入当前 `$env:Path` 后再验证。
- `Expand-Archive` 报 “End of Central Directory record could not be found” 时，先用 `tar -tf ZIP_PATH` 验证压缩包。若 `tar` 也失败，删除该下载文件并重新下载；不要继续使用坏包。
