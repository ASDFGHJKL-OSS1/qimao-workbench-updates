# 项目资产原子操作

## 适用范围

本文只说明后端直接读写：资产、状态、视角、图片、库导入、独立参考、草稿、提示词、记录查询、导出、项目音色和绑定、出镜集数及画风。资产生成、提取和制作编排不在本文范围内。

## 定位对象

先用 `cineflow project list` 定位项目，再用 `cineflow project asset list --project-id PROJECT_ID`、`cineflow project asset get --project-id PROJECT_ID --asset-id ASSET_ID` 读取现状，并用 `cineflow episode list --project-id PROJECT_ID` 解析分集。列表返回分页时读取全部相关分页；只对用户指定的对象和字段操作。

定位命令与关键 flags：

```text
cineflow project list --search SEARCH [--page PAGE] [--limit LIMIT]
cineflow project asset list --project-id PROJECT_ID [--asset-type TYPE] [--name NAME] [--page PAGE] [--limit LIMIT]
cineflow project asset get --project-id PROJECT_ID --asset-id ASSET_ID
cineflow episode list --project-id PROJECT_ID
```

## 项目画风

画风命令树和关键 flags：

```text
cineflow project art-style list --project-id PROJECT_ID
cineflow project art-style save-custom --project-id PROJECT_ID --label LABEL --prompt PROMPT [--image-url URL]
cineflow project art-style delete-custom --project-id PROJECT_ID
cineflow project art-style select --project-id PROJECT_ID [--art-style-id ID]
```

`art-style list` 返回的来源包括 `builtin`、`team` 和 `project`。同一项目最多一个项目自定义画风；保存自定义画风、覆盖已有自定义画风、删除自定义画风或清空项目画风前，必须说明影响并取得用户确认。`select` 的 `art-style-id` 必须来自当前项目可用列表；不传 `--art-style-id` 表示清空，写后重新读取列表确认选择结果。

## 资产、状态与视角

资产命令树和关键 flags：

```text
cineflow project asset get --project-id PROJECT_ID --asset-id ASSET_ID
cineflow project asset create --project-id PROJECT_ID --asset-type TYPE --name NAME [--summary SUMMARY]
cineflow project asset update --project-id PROJECT_ID --asset-id ASSET_ID [--name NAME] [--summary SUMMARY] [--clear-summary]
cineflow project asset delete --project-id PROJECT_ID --asset-id ASSET_ID
cineflow project asset batch-delete --project-id PROJECT_ID --asset-id ASSET_ID [--asset-id ASSET_ID ...]
cineflow project asset state create --project-id PROJECT_ID --asset-id ASSET_ID --name NAME [--description DESCRIPTION]
cineflow project asset state update --project-id PROJECT_ID --asset-id ASSET_ID --state-id STATE_ID [--name NAME] [--description DESCRIPTION] [--age AGE] [--gender GENDER] [--time TIME] [--light LIGHT]
cineflow project asset state delete --project-id PROJECT_ID --asset-id ASSET_ID --state-id STATE_ID
cineflow project asset view create --project-id PROJECT_ID --asset-id ASSET_ID --state-id STATE_ID [--name NAME]
cineflow project asset view update --project-id PROJECT_ID --asset-id ASSET_ID --state-id STATE_ID --view-id VIEW_ID --name NAME
cineflow project asset view delete --project-id PROJECT_ID --asset-id ASSET_ID --state-id STATE_ID --view-id VIEW_ID
```

`PROJECT_ID`、`ASSET_ID`、`STATE_ID`、`VIEW_ID` 是对应操作的必填定位 ID；资产创建需要 `ASSET-TYPE` 和 `NAME`，视角创建的 `NAME` 可选。更新只提交用户明确要求改变的字段，未要求的字段不得用空值覆盖。删除和批量删除必须先展示目标及影响并确认；批量删除使用可重复的 `--asset-id` 并逐项核对。删除后重新读取资产列表及受影响对象。

## 本地图片上传与历史选用

上传使用已有本地图片，按网页本地上传资产视角图片的语义写入，并在同一事务内自动选中新图片；`image select` 只用于切换到已有历史图片，上传成功后不得再重复调用。每次写入后重新读取图片列表和资产详情，确认新图片的 `image_source=import_reference` 且 `is_selected=true`。

图片命令树和关键 flags：

```text
cineflow project asset image list --project-id PROJECT_ID --asset-id ASSET_ID --state-id STATE_ID --view-id VIEW_ID [--page PAGE] [--limit LIMIT]
cineflow project asset image upload --project-id PROJECT_ID --asset-id ASSET_ID --state-id STATE_ID --view-id VIEW_ID --file FILE
cineflow project asset image delete --project-id PROJECT_ID --asset-id ASSET_ID --state-id STATE_ID --view-id VIEW_ID --image-id IMAGE_ID
cineflow project asset image select --project-id PROJECT_ID --asset-id ASSET_ID --state-id STATE_ID --view-id VIEW_ID --image-id IMAGE_ID
```

上传并自动覆盖当前选用图片前，展示当前 `image_id` 和目标本地图片并确认；使用 `image select` 切换历史图片前，展示当前/目标 `image_id` 并确认。删除图片前也要展示目标及影响。`image_id` 必须取自当前视角的图片列表；无法唯一确认时停止并请求补充信息。

## 项目音色与角色绑定

导入使用已有本地音频文件或个人库音色创建项目音色。`update` 只改元信息；`replace` 替换已有项目音色的音频本体，保留音色 ID。创建或更新后按用户要求绑定角色；解绑或删除绑定前确认影响范围。

音色与绑定命令树和关键 flags：

```text
cineflow project voice list --project-id PROJECT_ID [--page PAGE] [--limit LIMIT]
cineflow project voice import --project-id PROJECT_ID --file FILE --name NAME [--gender male|female] [--description DESCRIPTION]
cineflow project voice library list --scope personal [--name NAME] [--page PAGE] [--page-size SIZE]
cineflow project voice import-personal --project-id PROJECT_ID --personal-voice-id ID [--personal-voice-id ID ...]
cineflow project voice replace --project-id PROJECT_ID --voice-id VOICE_ID (--file FILE | --uploaded-file-id ID)
cineflow project voice batch-upload --project-id PROJECT_ID (--file ZIP | --uploaded-file-id ID) [--overwrite]
cineflow project voice batch-create --project-id PROJECT_ID --config-file FILE
cineflow project voice update --project-id PROJECT_ID --voice-id VOICE_ID [--name NAME] [--gender GENDER] [--description DESCRIPTION]
cineflow project voice delete --project-id PROJECT_ID --voice-id VOICE_ID
cineflow project asset voice bind --project-id PROJECT_ID --asset-id ASSET_ID --voice-id VOICE_ID
cineflow project asset voice unbind --project-id PROJECT_ID --asset-id ASSET_ID
```

`project voice import` 上传不超过 20 MiB 的本地 MP3/WAV 干声并直接创建项目音色，不产生模型体验 `output_id`；`project voice update` 只更新名称、性别和描述，不更新音频本体。创建、更新元信息、删除音色以及绑定、解绑角色均须确认；写后重新读取音色列表和角色资产详情，核对绑定关系。

`replace` 的本地文件也只支持 MP3/WAV、20 MiB。`batch-upload` 的 ZIP 保持压缩直传，由服务端按角色名匹配；最多 100 个音频文件、展开总量 500 MiB，每段音频最多 20 MiB，`--overwrite` 会覆盖已有角色绑定。失败后保留上传 ID，以 `--uploaded-file-id` 恢复，读取逐项创建、失败和跳过结果；不得删除旧音色代替替换。

## 库导入、参考与导出

```text
cineflow project asset progress --project-id PROJECT_ID [--images]
cineflow project asset library list --scope team|personal --asset-type TYPE [--name NAME]
cineflow project asset library get --scope team|personal --library-asset-id ID
cineflow project asset import-team --project-id PROJECT_ID --asset-type TYPE --team-asset-id ID
cineflow project asset import-personal --project-id PROJECT_ID --personal-asset-id ID
cineflow project asset reference upload --project-id PROJECT_ID --file FILE [--file FILE ...]
cineflow project asset images export --project-id PROJECT_ID
cineflow project asset images export-team --project-id PROJECT_ID --asset-id ASSET_ID --state-id STATE_ID --view-id VIEW_ID --config-file FILE
```

库 ID 从当前可见列表读取，不用项目资产 ID 代替。独立 `reference upload` 只返回标准 `data.items` 参考对象，不创建资产图片或改变选用；完整保留对象的 `id`、`source`、`uploaded_file_id` 等身份字段，用于草稿的 `reference_objects`。不要用 `image upload` 代替独立参考登记。导出设定图返回异步任务，使用 `task get|wait` 查询；`export-team` 每次只覆盖一个明确视角，配置仅用该视角图片列表中的 `project_asset_image_id`，最多 100 项。

## 草稿、提示词与记录查询

以下命令均需 `--project-id --asset-id --state-id --view-id`（记为定位 flags）：

```text
cineflow project asset draft get 定位flags [--record-id RECORD_ID]
cineflow project asset draft save 定位flags [--record-id RECORD_ID] --config-file FILE
cineflow project asset prompt get 定位flags [--record-id RECORD_ID]
cineflow project asset prompt update 定位flags [--record-id RECORD_ID] --prompt-file FILE
cineflow project asset prompt update 定位flags --config-file FILE
cineflow project asset generation-record list --project-id PROJECT_ID [--asset-id ID] [--state-id ID] [--view-id ID] [--page PAGE] [--page-size SIZE]
cineflow project asset image options --type image
```

先 `draft get` 取得服务端快照。当前视角 `draft save` 是部分更新，JSON 可以包含字符串 `model_id`、`aspect_ratio`、`resolution`，整数 `num_images`、`art_style_id`，以及 `prompt`、`prompt_rich_text`、`reference_objects`、`reference_images` 和布尔 `aspect_ratio_user_selected`；省略字段保留，显式 `null`/空数组按该字段协议清空。只保存草稿不调用生成，也不自动选用。模型和参数允许值读取 `image options`。

记录草稿保存是完整替换，JSON 为 `{"snapshot": {...}, "expected_latest_draft_signature": "读取的签名"}`；必须保留全部非目标字段、富文本与参考对象，首次不存在最新版时显式传 `null` 签名。快照取 `latest_draft`，无最新版取 `original_snapshot`。CAS 冲突时展示冲突并重新读取供用户核对，不自动覆盖他人修改。服务端快照中的大整数须无损保留。

普通文本改写使用 `prompt update --prompt-file`，CLI 负责纯文本富文本转换；记录模式自动读取快照并带签名保存。当前视角的 `--config-file` 只接受 `prompt` 和 `prompt_rich_text`，支持显式清空，与 `--record-id`/文本 flags 互斥。修改模型、比例但保留已有富文本时，直接保留返回的 `prompt_rich_text`，不让用户编辑 Tiptap JSON，不手工构造 mention；mention 的 `id` 和参考对象稳定身份必须对应。

## 状态出镜集数

先用 `cineflow episode list --project-id PROJECT_ID` 解析并展示 `episode_id`，再写状态出镜集数。命令执行整体替换：

```text
cineflow project asset state episode set --project-id PROJECT_ID --asset-id ASSET_ID --state-id STATE_ID [--episode-id EPISODE_ID ...]
```

写前展示旧集合与新集合并确认；`--episode-id` 可重复，不传 `--episode-id` 表示清空。写后使用 `cineflow project asset get` 复核，确认集合与用户确认内容一致。

## 禁止替代与错误恢复

项目资产写入必须使用本流程的项目命令。不能用 `cineflow episode asset upload`、不能用 `cineflow shot asset import`、不能用 `cineflow shot record select`，本地下载也不能替代项目资产写入。发生失败时保留已成功步骤，汇报成功对象、失败命令和可重试步骤；不要假设未确认的写入已经完成。任何项目、资产、状态、视角、图片、音色或分集 ID 不明确时停止操作并请求确认。
