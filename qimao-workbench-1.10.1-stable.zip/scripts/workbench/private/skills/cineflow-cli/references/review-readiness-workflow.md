# Readiness 状态与预审可启动性流程

`cineflow review readiness` 是项目、集或分镜范围的可启动性状态与 blocker 汇总入口，可供制作集意图校验和成片预审共同读取。readiness 只汇总可启动性状态和 blocker，不负责权限判断、范围歧义消解、制作意图推测或实际预审内容分析。

制作集意图校验只消费目标范围内的运行任务信息。预审消费方负责解释完整 readiness 结果；目标可预审后，CineFlow Skill 再下载或组织所选用视频/帧图，自行执行视频画面、AI 成片质量和合规风险分析，用户确认处理思路后再调用补素材流程。

## 使用前提

1. 用户的权限问题已由别的命令处理。
2. 目标范围已经由 Skill 明确到项目、集或分镜。未明确范围时不得猜测最近项目或相似项目；必须先用 `cineflow project list` 和 `cineflow episode list --project-id PROJECT_ID` 消除歧义。
3. 每次调用只汇总当前明确范围的状态和 blocker，并返回具体原因。

## 基本原则

1. CLI readiness 只复用现有原子查询，不新增制作或预审业务逻辑。
2. 多集或多分镜场景不能合并成一次粗糙判断，必须对每个目标分别调用 readiness，再由消费流程汇总。
3. 结果必须同时适合机器解析和用户展示。

## 消费方分工

1. 制作消费方只读取 `TASK_RUNNING` 及其 `task_kind`、`task_id` 和 `scope`，判断是否存在会改变本集资产、分镜、提示词或视频的任务；不使用 `can_start`，也不把缺少选用视频当作不能开始制作。
2. 预审消费方读取 `can_start` 和完整 reasons。只要存在一个预审 blocker，就不得直接执行内容预审；必须先向用户同步 blocker、可审目标和不可审目标，等待用户明确确认后才可继续预审可审部分或强制预审不完全 ready 目标。
3. 两类消费方都不能从 readiness 推断用户权限、制作意图、画面质量、剧情、资产正确性或合规结论。

## 与内容预审的分工

1. readiness 不输出画面质量、剧情、资产或合规结论。
2. 只有目标可预审，或用户在看到 readiness blocker 后明确确认强制预审不完全 ready 的目标时，才可使用 CineFlow CLI 读取分镜、选用记录、视频 URL、提示词、模型参数、资产上下文，并下载视频或抽帧执行内容预审。
3. CineFlow Skill 自行执行视频画面、AI 成片质量和合规风险分析，按 `pre-review-workflow.md` 的八个维度输出内容分析结论、项目/集/分镜明细和处理建议。
4. 若分析结果需要重抽或补素材，回到 CineFlow 补素材流程；默认仍遵守积分确认、提示词 diff、revision 与幂等规则。

## 调用方式

对每个目标分别调用：

```bash
cineflow review readiness --project-id PROJECT_ID [--episode N] [--shot M]
```

单个命令只检查一个项目下的一个目标范围。

## 判断规则

1. `selected_record_id` 为空，记录 `SHOT_VIDEO_MISSING`。
2. 分镜生成记录里没有 `selected=true && status=succeeded`，记录 `NO_READY_RECORD`。
3. 存在 `pending` / `running` 任务时，记录 `TASK_RUNNING`，并带上具体 `task_kind`。
4. 集内存在任一分镜缺视频时，记录 `EPISODE_HAS_MISSING_SHOT`。

## 任务细分

`TASK_RUNNING` 必须说明是哪一类任务阻塞了预审：

- `ASSET_GENERATION`
- `ASSET_UPLOAD`
- `ASSET_BINDING`
- `SHOT_STRUCTURE_GENERATING`
- `SHOT_PROMPT_GENERATING`
- `SHOT_ASSET_RELINKING`
- `SHOT_VIDEO_GENERATING`

如果无法归类，使用 `UNKNOWN`，不要猜。

## 多目标场景

用户如果一次给出多个集或多个分镜，Skill 必须：

1. 逐个目标调用 readiness。
2. 分别保存每个目标的原因。
3. 汇总整体结论。
4. 明确告诉用户哪些目标可预审，哪些目标被什么原因挡住。

整体结论规则：

- 所有目标都无 blocker，整体可预审。
- 任一目标有 blocker，整体不可完整预审；同步信息并等待用户确认前，不得预审任何目标，包括已 ready 的部分目标。

## 输出建议

- “可以开始预审”
- “不能开始预审”
- “部分目标可以预审，但存在 blocker。请确认是否只预审可审目标，或是否强制预审不完全 ready 目标。”
- “第 3 集第 2 镜缺少可预审视频”
- “第 3 集仍有分镜视频生成任务在进行”
- “第 4 集存在正在绑定资产的任务”

## 不做的事

1. 不判断用户权限。
2. 不判断范围是否表达清楚。
3. 不执行真正的预审。
4. 不做补素材写入。
