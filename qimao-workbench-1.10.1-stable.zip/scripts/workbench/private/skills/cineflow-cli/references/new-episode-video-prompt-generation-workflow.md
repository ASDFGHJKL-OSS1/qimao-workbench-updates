# 生成分镜提示词流程

## 适用范围

本流程用于【划分分镜片段】经用户确认后，执行【生成分镜提示词 *N】。虽然环节名称强调“提示词”，但实际输出是每个视频生成任务的完整入参草案：参考对象、文本提示词、视频模型参数、时长、声音边界、画面禁用项和写入报价前检查。

目标输出形态参考 `examples/第一集_生视频提示词完整入参_v3.md`：每个 T 任务都有“参考对象 / 文本提示词 / 视频模型参数”，且文本提示词能直接作为后续平台 `prompt_text` 草案。最终写入平台、报价和付费生成仍必须按主流程确认。

## 参数取数命令

| 参数 | 来源命令 | 使用字段/规则 |
|---|---|---|
| `{文字分镜}` | 已确认的 `new-episode-text-storyboard-workflow.md` 输出 | 读取镜号、时长、景别/运镜、镜头内容、台词、音效、出镜角色、场景、时间段。不得新增剧情或擅改台词。 |
| `{全集连续性约束}` | 已确认的 `new-episode-text-storyboard-workflow.md` 输出 | 把资产、画面、空间、动作、时间和叙事限制化进每个任务的自足提示词，不写“同上”。 |
| `{分镜片段划分}` | 已确认的 `new-episode-segment-generation-workflow.md` 输出 | 读取任务号、来源镜头、任务时长、片段内容、参考角色资产、参考场景资产、图片数、音频数、限制校验、片段衔接要求。 |
| `{生视频模型}` | 分镜思路前先运行 `cineflow episode video defaults get --project-id PROJECT_ID --episode N`；分镜创建后再运行 `cineflow shot model list --project-id PROJECT_ID --episode N --shot SHOT_NUMBER` 复核。 | 前置取参使用 `video_model`；写入前只选择 `compatible=true` 的分镜级模型，并遵守该模型的时长、分辨率、参考图片和音频限制。 |
| `{画面比例}` | `cineflow episode video defaults get --project-id PROJECT_ID --episode N` | 使用 `default_aspect_ratio_value`；缺少明确字段时停止，不得猜测。 |
| `{分辨率}` | `cineflow episode video defaults get --project-id PROJECT_ID --episode N`；写入前用 `cineflow shot model list --project-id PROJECT_ID --episode N --shot SHOT_NUMBER` 复核。 | 前置草案使用 `video_resolution`；写入前复核兼容分辨率。 |
| `{全局画风预设}` | `cineflow episode art-style get --project-id PROJECT_ID --episode N` | 使用后端实际返回的全局画风预设提示词内容。只有内容非空时才追加到每段提示词正文末尾；没有内容时写“无”，不使用 ID、展示名或硬编码默认画风。 |
| `{参考资产}` | `cineflow episode asset list --project-id PROJECT_ID --episode N` | 角色、场景、道具、素材和音色只取本集资产明确字段；名称必须保持原样。 |
| `{可用 mention}` | 分镜创建并绑定资产后运行 `cineflow shot reference list --project-id PROJECT_ID --episode N --shot SHOT_NUMBER` 或 `cineflow shot get --project-id PROJECT_ID --episode N --shot SHOT_NUMBER` | 写入平台前，提示词里的 `@名称` 必须来自当前分镜可用引用；尚未创建分镜时可用资产正式名称写草案，但必须在写入前替换和复核。 |
| `{REVISION}` | `cineflow shot get --project-id PROJECT_ID --episode N --shot SHOT_NUMBER` | 写入前必须读取最新 `edit_revision`；冲突时停止，不自动合并。 |
| `{prompt_text}` / `{DURATION}` / `{MODEL_ID}` / `{RESOLUTION}` | 本流程生成并经用户确认，模型/分辨率由 `shot model list` 复核。 | 写入使用 `cineflow shot prompt update --project-id PROJECT_ID --episode N --shot SHOT_NUMBER --file /path/to/prompt.txt --duration-seconds DURATION --model-id MODEL_ID --resolution RESOLUTION --revision REVISION`。 |
| `{报价}` | `cineflow shot video quote --project-id PROJECT_ID --episode N --shot SHOT_NUMBER` | 保存提示词/配置后重新报价；提交付费任务前必须展示报价并取得确认，除非用户明确授权可跳过。 |

## 完整流程

1. 确认前置阶段已完成：分镜思路、文字分镜与全集连续性约束、分镜片段划分均已由用户确认。
2. 读取或复核当前默认生视频模型、画面比例、分辨率和全局画风预设；缺少明确字段时停止。全局画风预设只使用后端实际返回的提示词内容，没有内容时写“无”。
3. 按分镜片段划分表逐个处理 T01…TN：每个任务只覆盖自己的来源镜头、参考对象、任务时长和片段衔接要求。
4. 根据 `{生视频模型}` 的当前约束写文本提示词：包括参考图片、音频、镜头顺序、台词/OS/犬吠、动作音效、环境声和禁用项；仅当全局画风预设包含后端返回的提示词内容时，才把该内容作为最后一句或最后一段追加到每段提示词正文末尾；没有内容时不追加固定默认画风。
5. 把全集连续性约束化进每个任务：用当前任务可见的具体事实描述站位、运动方向、动作起止、时间天气、道具位置和角色状态，不依赖“上一段”。
6. 输出完整“生成分镜提示词 × N”草案，交给用户确认参考对象、文本提示词和视频模型参数。
7. 用户确认后，按主流程创建/复用分镜、绑定参考素材、读取最新 mention 和 revision。
8. 写入前再次展示 diff、台词逐字一致性、引用变化和配置变化；确认后执行 `shot prompt update`。
9. 保存后执行 `shot video quote`，展示逐镜权威报价、总积分和余额；付费确认后才可提交生成。

## 输出格式

```Markdown
## 第二步：生成分镜提示词 × N（完整视频任务入参）

> 音频引用名称按角色资产名加“音频”标注。实际提交时应绑定该角色已关联的真实音频文件，而不是把标注文字当作文件路径。

### T01｜{片段标题}

**参考对象**

- 角色图片：`@角色资产名`
- 场景图片：`@场景资产名`
- 道具/素材图片：`@道具或素材名`（如无则写“无”）
- 音频：`@角色音频名`（如无则写“无”）

**文本提示词**

在 `@场景资产名` 中生成{任务时长}秒、{画面比例}的{剧集类型/风格}多镜头片段。严格沿用 `@角色资产名` 的既定外形、服装、年龄感、材质和声线。按镜头顺序写清：镜头1，{时长}秒，{景别/运镜}，{动作和表演}；镜头2，...。明确写入本片段需要自足理解的连续性约束，如站位、运动方向、动作起止、时间天气、道具位置。只生成动作音效、环境音及剧本要求的角色声音，不生成任何 BGM；禁止字幕、字卡、身份报幕、水印、Logo、UI、乱码文字和额外人物。{仅当全局画风预设包含后端返回的提示词内容时，将该内容作为本段提示词正文末尾的画风约束追加；没有内容时不追加任何画风后缀。}

**视频模型参数**

- 生视频模型：`{生视频模型}`
- 画面比例：`{画面比例}`
- 分辨率：`{分辨率}`
- 时长：`{任务时长}秒`
- 全局画风预设：`{全局画风预设；无内容写“无”}`
```

## 生成提示词时使用的元提示词

生成分镜提示词前，必须先读取 `prompt-生成分镜提示词.md`。该文件包含单分镜 `prompt_text` 元提示词、可复制元提示词、输入材料、目标输出结构和提示词正文构成；本 workflow 只保留取参、流程、写入、报价和检查顺序。

## 写入与报价前准备

1. 用户确认完整视频任务入参后，按主流程创建或复用分镜结构，并按片段清单绑定参考素材。
2. 每个分镜绑定完成后，读取 `cineflow shot reference list --project-id PROJECT_ID --episode N --shot SHOT_NUMBER` 或 `cineflow shot get --project-id PROJECT_ID --episode N --shot SHOT_NUMBER`，确认 `@mention` 可用。
3. 在每个分镜独立的临时 UTF-8 文件中准备 `prompt_text`，展示完整 diff、台词逐字一致性、引用变化和模型/时长/分辨率变化。
4. 运行 `cineflow shot prompt update --project-id PROJECT_ID --episode N --shot SHOT_NUMBER --file /path/to/prompt.txt --duration-seconds DURATION --model-id MODEL_ID --resolution RESOLUTION --revision REVISION` 保存提示词和配置。
5. 保存后运行 `cineflow shot video quote --project-id PROJECT_ID --episode N --shot SHOT_NUMBER`，展示权威报价；提交付费任务前取得确认，除非用户明确授权可跳过。

## 简短检查清单

提交给用户确认前，逐任务检查：

1. 是否列出参考图片、参考音频、完整文本提示词和视频模型参数。
2. 是否覆盖片段内所有来源镜头，没有漏台词、漏动作、漏音效或漏关键反应。
3. 是否没有“同上”“上一段”“延续前文”“继续刚才画面”等跨任务依赖。
4. 是否把连续性约束写成当前任务内可理解的具体描述。
5. 是否只使用已确认资产名称和当前分镜可用 mention。
6. 是否明确区分 OS、画外音、真实对白和犬吠。
7. 是否明确禁止字幕、字卡、身份报幕、水印、Logo、UI、乱码文字、额外人物和 BGM。
8. 是否仅在全局画风预设包含后端返回的提示词内容时把画风约束追加在每段提示词正文末尾；没有内容时是否没有固定默认画风。
9. 是否逐任务重复列出视频模型参数，且时长、画幅、分辨率、模型与片段划分一致。

## 维护用完整示例

完整示例见 `examples/第一集_生视频提示词完整入参_v3.md`。维护本流程时，优先对照该文件的每任务参考对象、完整文本提示词和视频模型参数格式；片段划分表只维护在 `examples/第一集_分镜片段与生视频提示词_v3.md`。
