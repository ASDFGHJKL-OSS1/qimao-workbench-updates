#!/usr/bin/env python3
"""Install CineFlow Whisper tiny weights for the openai-whisper CLI.

The CineFlow CDN publishes Hugging Face-format `openai/whisper-tiny` files.
The `whisper` command from `openai-whisper` expects an OpenAI checkpoint when
`--model` is a local file, so this script downloads the HF files and converts
them to a local `tiny.pt` checkpoint.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

import torch


CDN_BASE = "https://cineflow-prod.oss-cn-beijing.aliyuncs.com/qmniu/cineflow/cli/models/whisper/openai/whisper-tiny/"
MODEL_FILES = [
    "config.json",
    "generation_config.json",
    "preprocessor_config.json",
    "tokenizer_config.json",
    "special_tokens_map.json",
    "vocab.json",
    "merges.txt",
    "tokenizer.json",
    "normalizer.json",
    "added_tokens.json",
    "pytorch_model.bin",
    "README.md",
]


def default_cache_dir() -> Path:
    if os.name == "nt":
        root = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(root) / "CodexTools" / "whisper-models" / "openai-whisper"
    return Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache")) / "cineflow" / "whisper" / "openai-whisper"


def download_file(url: str, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    with urlopen(url, timeout=60) as response:
        if response.status >= 400:
            raise URLError(f"HTTP {response.status}")
        tmp = dest.with_suffix(dest.suffix + ".part")
        with tmp.open("wb") as fh:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                fh.write(chunk)
        tmp.replace(dest)


def download_model_files(model_dir: Path, source: str) -> str:
    bases = [CDN_BASE]
    if source in {"auto", "huggingface"}:
        endpoint = os.environ.get("HF_ENDPOINT", "https://huggingface.co").rstrip("/")
        bases.append(f"{endpoint}/openai/whisper-tiny/resolve/main/")
    if source == "huggingface":
        bases = bases[1:]

    last_error: Exception | None = None
    for base in bases:
        try:
            for file_name in MODEL_FILES:
                dest = model_dir / file_name
                if not dest.exists() or dest.stat().st_size == 0:
                    download_file(base + file_name, dest)
            return base
        except Exception as exc:  # noqa: BLE001 - report and try next source.
            last_error = exc

    raise RuntimeError(f"failed to download Whisper tiny model files: {last_error}")


def convert_hf_to_openai(hf_dir: Path, output_path: Path) -> None:
    config = json.loads((hf_dir / "config.json").read_text(encoding="utf-8"))
    hf = torch.load(hf_dir / "pytorch_model.bin", map_location="cpu")
    converted: dict[str, torch.Tensor] = {}

    def put(src: str, dst: str) -> None:
        converted[dst] = hf[src]

    put("model.encoder.conv1.weight", "encoder.conv1.weight")
    put("model.encoder.conv1.bias", "encoder.conv1.bias")
    put("model.encoder.conv2.weight", "encoder.conv2.weight")
    put("model.encoder.conv2.bias", "encoder.conv2.bias")
    put("model.encoder.embed_positions.weight", "encoder.positional_embedding")
    put("model.encoder.layer_norm.weight", "encoder.ln_post.weight")
    put("model.encoder.layer_norm.bias", "encoder.ln_post.bias")
    put("model.decoder.embed_tokens.weight", "decoder.token_embedding.weight")
    put("model.decoder.embed_positions.weight", "decoder.positional_embedding")
    put("model.decoder.layer_norm.weight", "decoder.ln.weight")
    put("model.decoder.layer_norm.bias", "decoder.ln.bias")

    for side, layer_count in (
        ("encoder", config["encoder_layers"]),
        ("decoder", config["decoder_layers"]),
    ):
        src_prefix = f"model.{side}.layers"
        dst_prefix = f"{side}.blocks"
        for i in range(layer_count):
            attn_pairs = [("self_attn", "attn")]
            norm_pairs = [("self_attn_layer_norm", "attn_ln"), ("final_layer_norm", "mlp_ln")]
            if side == "decoder":
                attn_pairs.append(("encoder_attn", "cross_attn"))
                norm_pairs.insert(1, ("encoder_attn_layer_norm", "cross_attn_ln"))

            for src_attn, dst_attn in attn_pairs:
                for src_proj, dst_proj in (
                    ("q_proj", "query"),
                    ("k_proj", "key"),
                    ("v_proj", "value"),
                    ("out_proj", "out"),
                ):
                    put(f"{src_prefix}.{i}.{src_attn}.{src_proj}.weight", f"{dst_prefix}.{i}.{dst_attn}.{dst_proj}.weight")
                    bias_key = f"{src_prefix}.{i}.{src_attn}.{src_proj}.bias"
                    if bias_key in hf:
                        converted[f"{dst_prefix}.{i}.{dst_attn}.{dst_proj}.bias"] = hf[bias_key]

            for src_norm, dst_norm in norm_pairs:
                put(f"{src_prefix}.{i}.{src_norm}.weight", f"{dst_prefix}.{i}.{dst_norm}.weight")
                put(f"{src_prefix}.{i}.{src_norm}.bias", f"{dst_prefix}.{i}.{dst_norm}.bias")

            put(f"{src_prefix}.{i}.fc1.weight", f"{dst_prefix}.{i}.mlp.0.weight")
            put(f"{src_prefix}.{i}.fc1.bias", f"{dst_prefix}.{i}.mlp.0.bias")
            put(f"{src_prefix}.{i}.fc2.weight", f"{dst_prefix}.{i}.mlp.2.weight")
            put(f"{src_prefix}.{i}.fc2.bias", f"{dst_prefix}.{i}.mlp.2.bias")

    checkpoint = {
        "dims": {
            "n_mels": config["num_mel_bins"],
            "n_vocab": config["vocab_size"],
            "n_audio_ctx": config["max_source_positions"],
            "n_audio_state": config["d_model"],
            "n_audio_head": config["encoder_attention_heads"],
            "n_audio_layer": config["encoder_layers"],
            "n_text_ctx": config["max_target_positions"],
            "n_text_state": config["d_model"],
            "n_text_head": config["decoder_attention_heads"],
            "n_text_layer": config["decoder_layers"],
        },
        "model_state_dict": converted,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(checkpoint, output_path)


def validate_checkpoint(path: Path) -> None:
    import whisper

    whisper.load_model(str(path), device="cpu")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache-dir", type=Path, default=default_cache_dir())
    parser.add_argument("--source", choices=["auto", "cdn", "huggingface"], default="auto")
    parser.add_argument("--skip-validate", action="store_true")
    args = parser.parse_args()

    hf_dir = args.cache_dir / "hf-openai-whisper-tiny"
    output_path = args.cache_dir / "tiny.pt"
    source_used = download_model_files(hf_dir, args.source)
    convert_hf_to_openai(hf_dir, output_path)
    if not args.skip_validate:
        validate_checkpoint(output_path)
    print(output_path)
    print(f"source={source_used}")


if __name__ == "__main__":
    main()
