# 2026年AI漫剧出海全链路工业化方案（claude版）.docx.64290e26

## 入库元信息
- 资料名称：2026年AI漫剧出海全链路工业化方案（claude版）.docx.64290e26.md
- 入库日期：2026-07-06
- 原抽取汇总分类：待人工归类
- 入库目录：01_内容形态/2D动漫_16比9
- 适用内容形态：2D动漫_16比9
- 适用题材：待二次精炼；本文件为扩展搜索抽取资料的首轮归档。
- 适用环节：01_内容形态
- 禁止误用范围：不得直接整份塞入 SKILL.md；不得把旧指令流程与资料案例混为一个巨大提示词；长剧本只作为题材/节奏/问题样例。
- 可被调用的技能：project-dna-builder（项目基因建立）
- 来源路径：01_抽取文本/扩展搜索/2026年AI漫剧出海全链路工业化方案（claude版）.docx.64290e26.md
- 内容哈希：d452f90083a69d577326d3ef6bc44441ae6d3ff08a37e3f691d7a1a29dba394e
- 重复组：首个版本
- 当前状态：首轮入库，待二次精炼为字段、案例、规则、禁区。

## 资料正文
# 扩展资料抽取

源文件：`
E:\xwechat_files\wxid_kmch34ztok5a12_4d3f\msg\file\2026-01\2026年AI漫剧出海全链路工业化方案（claude版）.docx
`
归类建议：
待人工归类
抽取时间：2026-07-05

---
2026 AI
"
"
+ IP-Adapter
+
"
,
11
6
,
"
" "
"
:
"
"——
";IP-Adapter
"
";
"
";
"
"
";
",
"
"
:
,
:
:
4.0 /
Max /
AI /
Pro
AI
:
:
/
/
(Kling) /
AI
/ Pika
/
:
:
/
/
/
: Claude 4 / GPT-4 / Gemini Pro
: Midjourney / Flux.1 / Stable Diffusion
: Runway Gen-3 / Luma Dream Machine / Pika
: ElevenLabs / PlayHT / Descript
: CapCut( ) / Adobe Premiere Pro
:
(
30-50%)
:
(
)
**"
" "
"**
,
3
1:
2:
AI
(Claude 4 GPT-5)
Markdown
(Visual Prompt)
:
(Camera)
(Dialogue)
(SFX)
3:
(
B:
)
"
"
,
"
"
"
(Underdog Success)"
( "
(Absurdist)
( Rizz, Pookie),
"→"Core Energy","
"→"Ancient Code")
2026
Sarcasm(
)
4:
(
)
AI
:
TikTok/
3
Memes
BGM
YouTube Shorts/
/Instagram
:
"
"
"
"
"
"
:
1
3
"
"
**
(
AI)
(
AI)**
(
(
/
/
):
"
"
"
"
"
"
,
,
B
,
Claude/GPT/Gemini):
You are a cross-cultural producer who deeply understands Chinese internet meme culture. You excel at reconstructing
Eastern narratives through "contrast cuteness" and "high emotional value", making them globally appealing while
preserving unique Eastern wisdom and dry humor. You constantly monitor trending memes on Douyin, Xiaohongshu, and
Bilibili, naturally integrating them into script creation.
:
"
",
Markdown
(Dialogue)
,
:
(Visual Prompt)
:
(Camera)
"
(SFX)
- Visual Prompt
"
+
- Camera
-
(Extreme Close-up)
(
(Tracking Shot)
/Midjourney)
AI
/
:
Convert the following web novel into an "industrial-grade comic drama storyboard script" in Markdown table format,
including columns: Scene Number, Visual Subject, Visual Prompt, Camera Movement, Key Dialogue, SFX.
Requirements:
- Visual Prompt must use "noun + adjective" structure
- Camera must use professional terms like Extreme Close-up or Tracking Shot
- Each scene's visual description must be optimized for AI image tools (Midjourney/Flux.1/Stable Diffusion)
:
,
2026
(
"CPU
"
"
"
"
"
"),
"
"
"
"
"
,
/
(
"
"→"
","
"→"
")
:
Enhance contrast cuteness, automatically add absurdist elements or fourth-wall breaks. Use 2026 trending slang (like
"Rizz", "Pookie", "It's giving..."), ensuring viewers feel the character's "swagger" even with subtitles on mute. Transform
Chinese-style "face-slapping" into universally relatable "underdog success" stories, removing esoteric cultivation terms
(e.g., "
" → "Core Energy", "
" → "Ancient Code").
2026
:
,
**2026
1
**
/
/
(Memes)
BGM,
"
"(Vibe)
:
1.
2.
3.
4.
(
"
but
"
"CPU
"
"
")
"
"
(
)
"
:
"
,
"
"
"
,
XX",
:"
,
"
:
Before processing the script, first associate the three hottest visual memes or trending BGMs on TikTok/YouTube
Shorts/Instagram Reels in **January 2026**, and infuse their "spiritual essence" (Vibe) into this episode's shot
descriptions and dialogue rhythm.
Specific requirements:
1. Identify core emotions of monthly trending memes (e.g., "awkward but maintaining dignity", "brain.exe stopped
working", "pure victim energy")
2. Integrate visual elements of trending memes into the "Visual Prompt" column (e.g., specific facial expressions, popular
filter effects)
3. Use classic phrases or rhythm patterns from trending memes in the "Key Dialogue" column
4. If encountering specific terms, deconstruct them using the most popular "brainstem-absent" humor style
Example: If "It's giving [X]" is trending, dialogue could be: "It's giving protagonist energy but make it chaotic"
: "
,
,
"
B+
**
:
:**
,
(
"Error
404"
),
"
"
:"
,
——
,
, AI
CPU
**
"
:**Extreme Close-up(
)
,
Zoom In(
)
:
(
)
,
1:
9
:
2:
AI
:
(Qwen):
(Banana):
prompt
Midjourney/Flux.1:
3:
9
3×3
:
(Storyboard)
(
/
/
AI):
[
],
,
,[
],
,
,
,
,
,8K
:
,
,
,
,
,
,
,
,
,8K
(
Midjourney/Flux.1/Stable Diffusion):
[Scene description], comic book style, cinematic composition, [camera angle], dramatic lighting, high contrast, vibrant
colors, clean lineart, detailed background, 8k quality
Example:
Young hero standing in ancient temple ruins, comic book style, cinematic composition, low angle shot, dramatic lighting
with god rays, high contrast, vibrant colors, clean lineart, detailed stone pillars background, 8k quality
:
9
,
3×3
:
(
1:
2:
3:
):
):
):
-
-
-
/
(
4:
5:
6:
-
-
-
(
7:
8:
9:
-
-
-
/
:
,
,
[
],
,8K
:
Generate 9 key scene storyboards for the following story, arranged in 3×3 grid:
Row 1 (Setup):
- Scene 1: Protagonist's ordinary life
- Scene 2: Inciting incident/turning point
- Scene 3: Protagonist's reaction close-up
Row 2 (Conflict):
- Scene 4: Antagonist entrance
- Scene 5: Tense confrontation
- Scene 6: Emotional breaking point
Row 3 (Climax):
- Scene 7: Comeback preparation
- Scene 8: Decisive action
- Scene 9: Outcome/cliffhanger
Each image must include: comic book style, cinematic composition, [specific art style], unified color palette, 8k quality
:
(IP
)
"
",
1:
:
(Front view)
(Side/Profile view)
(3/4 view)
(Back view)
(
3/4
)
(
)
2:
(Technical Sheet)
:
(Front):
,
(Side):
,
(Back):
,
(Visual Bible)
3:
ComfyUI WebUI
IP-Adapter FaceID
0.65-0.8
FaceID Plus V2
0.4
(
/
):
[
(
]
,
(
3/4
),
(
),
,8K
),[
],
,
,
,
,
:
,
(
3/4
),
(
),
,
,
,
,
,
,
,
,8K
(
Midjourney/Flux.1):
Character Name full reference sheet, multiple angles (front view, side view, 3/4 view, back view), multiple expressions
(happy, angry, surprised, sad, neutral), multiple poses (standing, walking, action pose), [detailed character description],
consistent character design, white background, clean lineart, flat colors, professional character sheet, 8k resolution
Example:
Zhao Chen full reference sheet, multiple angles (front view, side view, 3/4 view, back view), multiple expressions (happy,
angry, surprised, sad, neutral), handsome young man with short black hair, wearing modern cyberpunk style robe with
oriental cloud patterns, lean athletic build, consistent character design, white background, clean lineart, flat colors,
professional character sheet, 8k resolution
:
[
]
,
(
),
,
,
,
,
,
,
,
,
,
,8K
:
,
(
),
,
,
,
,
,
,
,
,
,8K
:
Character Name turnaround character design, three views (front, side, back), full body, [detailed character description],
standing pose, white background, clean lineart, flat color, model sheet, orthographic projection, same scale, 8k quality
Example:
Zhao Chen turnaround character design, three views (front, side, back), full body, handsome young warrior with short
black hair, wearing blue and gold embroidered martial arts robe, standing pose, white background, clean lineart, flat color,
model sheet, orthographic projection, same scale, 8k quality
LoRA
3D
3
(Hook)
:
_
_
_
.png
,
:
(
)
,
,
1:
(IP-Adapter)
Visual Prompt
:
Midjourney:
Flux.1:
/
:
,
2:
3:
IP-Adapter FaceID
**"
"**:
:
(
(
)
)
:
Kling:
Luma:
Runway Gen-3:
(
)
(
/
+IP-Adapter):
[
],[
],
,
,[
],
,
,
,
,8K
IP-Adapter
:
-
-
-
:0.65-0.8
:0.4
:
,
,
,
,
,
,
,
,
,8K
(
Midjourney/Flux.1+IP-Adapter):
[Scene description], [character action], comic book style, cinematic lighting, [camera angle], dramatic composition,
vibrant colors, detailed background, high quality, 8k
For use with IP-Adapter:
- Upload character turnaround as reference image
- Weight setting: 0.65-0.8
- Noise strength: 0.4
Example:
Young warrior standing in ancient temple ruins, holding glowing sword, comic book style, cinematic lighting, low angle
shot, dramatic composition, vibrant colors, detailed stone pillars and statues background, high quality, 8k
(
/
):
:
-
-
:
*
*
*
*
:
:
:
:
-
-
-
:
10-20%
:2-4
:
,
3D
(
Runway/Luma/Pika):
Generate subtle motion from static image:
- Keep main subject and background static
- Only animate these elements:
* Face: blinking, slight smile, breathing
* Hair: gentle wind movement
* Clothing: fabric edges, cape flowing
* Environment: lighting shifts, particle floating
- Motion scope: 10-20% of frame
- Duration: 2-4 second loop
- Style: maintain comic aesthetic, avoid 3D realism
3D
100
80%+
10-20%
:
(
)
1:
"
"
:
:
:
:
,
AI
:
,
ElevenLabs:
PlayHT:
,
,
Descript:
2:
(Lip-sync)
:
:
:AI
:
HeyGen:
D-ID:
+
(
/
):
,
:
-
-
-
-
-
-
:[
:[
:[
],
:[
/
],
:[
]
]
/
/
/
/
/
/
]
:[
/
/
/
]
:[
:[ ...
]
1
]
:"[
]"
:
"
", 2026
1
"CPU
"
"
"
(
ElevenLabs/PlayHT):
Generate voiceover for the following dialogue with:
- Character: [Name], Gender: [M/F], Age: [specific age]
- Emotion: [angry/happy/sad/sarcastic/helpless]
- Speed: [fast/medium/slow]
- Tone: [high-pitched/deep/highly varied/steady]
- Emphasis words: [keyword list]
- Pause locations: [pause 1 second at...]
Dialogue: "[specific dialogue content]"
Special requirement: Infuse the "spiritual essence" of January 2026 trending memes into the voiceover rhythm, such as
"brain.exe stopped working" style pauses and "y'all don't even know" style sighs.
:
,
1:
"
"
:
9:16(
/TikTok/
)
16:9(YouTube/B )
1:1(Instagram/
)
:
:
,
:B
,
:
:
CapCut(
):
Adobe Premiere Pro:
DaVinci Resolve:
2:
(Human-in-the-loop)
"
5%
":
:
:
:
1.
2.
3.
4.
(
/
/
/
)
/
/
-
-
-
/PR
"
"
:
Checklist:
1. Does camera angle follow professional storyboarding (bird's eye/worm's eye/Dutch angle/eye level)
2. Does composition follow rule of thirds or golden ratio
3. Is visual focal point prominent
4. Are foreground/midground/background layers clear
Correction methods:
- Use CapCut/Premiere "Keyframe" to adjust composition
- Add blur effects to highlight subject
- Use crop tool to recompose
(In-painting)
:
AI
:
1.
2.
3.
4.
:
:
PS/Photopea
:
/
:
:
-
-
:Photopea(
PS)
:Photoshop GIMP
:
Common AI errors and fixes:
1. Deformed hands: Use PS/Photopea healing brush tool
2. Text errors: Regenerate or manually add correct text layer
3. Inconsistent facial features: Use Runway/Luma inpainting
4. Background glitches: Use smart fill tool
Recommended tools:
- Domestic: Photopea (online PS), Meitu Pro
- International: Photoshop, GIMP
:
"AI
"
:
1.
2.
3.
4.
5.
/
(
10-20%)
/
LUT
(
:
/
)
(Chromatic Aberration)
"
"
+
,
(
30-50%)
:
-
-
-
-
(
/
)
:
Methods to eliminate "AI look":
1. Add film grain/noise effect (strength 10-20%)
2. Use LUT color grading (recommend: Vintage/Cyberpunk/Japanese fresh)
3. Add chromatic aberration for "hand-drawn feel"
4. Use sharpening + slight blur combo, avoid over-perfection
5. Add hand-drawn line layer (opacity 30-50%)
Build brand visual identity:
- Unified color palette (warm/cool tones)
- Fixed intro/outro animation
- Signature transition effects
- Unique subtitle styling
:
:
($10-$30/min)
:TikTok/Shorts
:
:
3 Hook
,
($50-$150/min)
:YouTube
:
:
IP,
LoRA
($300+/min)
:
:3D+AI
:
,
**
:**
4090
:
RunPod Lambda Labs
GPU
**
:**
LoRA
,
"
"
100
:
=
(
) +
(5%) +
(
)
,
(
)
,
(
)
"
"
(
)
(
)
**
**
**
**
:**
4.0 /
Max /
Pro / Kimi
:**
:**
/
/
/
/
AI
AI
:**IP-Adapter FaceID(
)
**
**
**
:**
:**
:**
/
(Kling) /
AI /
AI
/
/ Pika
**
**
:**
/
/
:**Photopea(
) /
**
:**
/
**
**
:**
:**
PAI /
TI / AutoDL /
COS /
OSS /
:
50-150
(
)
/
(
)
**
**
**
**
:**Claude 4 / GPT-4o / Gemini 2.0 Pro
:**Midjourney / Flux.1 Pro / Stable Diffusion
:**Midjourney / Flux.1 / Leonardo.ai
:**IP-Adapter FaceID (ComfyUI/WebUI)
**
**
**
:**ElevenLabs / PlayHT / Descript
:**Runway Gen-3 / Luma Dream Machine / Pika
:**Runway Inpainting / Luma Keyframes
**
**
**
:**CapCut Pro / Adobe Premiere Pro / DaVinci Resolve
:**Photoshop / GIMP / Krita
:**Adobe After Effects / Boris FX
**
**
:**RunPod / Lambda Labs / Vast.ai / Paperspace
:**AWS S3 / Google Cloud Storage / Dropbox Business
:
$15-50
(
)
(
)
Claude 4(
) +
(
)
,
,
(
) + Midjourney(
)
+
ComfyUI + IP-Adapter
Flux.1 +
(
(
) + Runway(
)
80%
,20%
) + ElevenLabs(
)
,
AutoDL(
) + RunPod(
)
:
80-200
/ $12-30
"2026 AI
"
:
1. **
:** 11
:**
6
(
→
→
→
→
→
)
2. **
3. **
4. **
5. **
6. **
+
,
:**
+
,
:**
5%,
AI
:**
:**
+
"
,
,
**
:** "
"
",
