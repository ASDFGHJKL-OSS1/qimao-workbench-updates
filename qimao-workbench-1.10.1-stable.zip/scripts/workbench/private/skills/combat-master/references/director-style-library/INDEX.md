# Director Style Library Index

This directory is the portable reference root for Combat Master 2.0 style augmentation.

## Read Order

1. Search `primary/05_画面风格` and `primary/06_分镜镜头` for normal combat-style enhancement.
2. Read matching `primary/00_项目基因`, `primary/01A_整体基调`, `primary/03_剧本叙事`, and `primary/03A_剧本优化技法` only for project-level consistency.
3. Use `fallback/` only when a required primary file is absent or a revision comparison is needed.
4. Use `supplements/` only as candidate material. It was pending merge when packaged and must not silently override `primary/`.
5. Read `style-router-snapshot/SKILL.md` only when the user explicitly requests the full project-level global storyboard-style and video-suffix report.

## Portability

Resolve this directory relative to the installed `combat-master` skill. Do not depend on the source computer's username, Documents directory, or separately installed `shot-design-generation` skill.

Some source snapshots retain historical `/Users/staff/...` paths as provenance text. Do not follow those paths. Find the corresponding file by filename or topic key inside `primary/`, then `fallback/` if needed.
