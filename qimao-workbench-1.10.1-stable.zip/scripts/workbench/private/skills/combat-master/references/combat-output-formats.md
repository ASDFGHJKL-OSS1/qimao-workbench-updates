# Output Formats

Use this reference when the user asks for a specific format or when the default AI video prompt needs a stable structure.

## Default AI Video Prompt

Use this by default.

```text
【AI视频提示词】
全局风格与画面锁定：
写明题材、渲染/实拍风格、画幅、光线、色彩、空间氛围、镜头质感。

角色与空间锁定：
写明双方身份、服装、武器/能力颜色、起始距离、站位、环境危险和可互动物。

镜头节奏：
写明宏观节奏，例如“空间建立 -> 近身交锋 -> 反制 -> 高潮碰撞 -> 结尾定格”。

动作分镜：
按时间或镜头写，必须包含动作循环、复合运镜链、命中/格挡/反制节点、物理反馈、环境反应。

结尾定格：
写明胜负关系、站位变化、情绪余韵、环境状态。

一致性与禁止项：
锁定角色、服装、武器/能力颜色、类型物理规则；禁止空间混乱、跳过碰撞反应、单一运镜词、无关音频、字幕、水印、UI、低清晰度。
```

## Fixed Runtime Prompt

For short prompt requests, first determine whether the user means total runtime or per-segment runtime.

- If the user gives a long script and says each segment should be 5-15 seconds, split the story into multiple 5-15 second narrative segments.
- If the user explicitly says total runtime is 15 seconds, compress into one 15-second prompt.
- If the user says "最长15秒" after providing a long script but then clarifies segmentation, treat 15 seconds as the maximum length per segment.

Each segment must have a clear hook, a complete visual action arc, and a strong ending image. Do not average all plot information across every segment.

For each 5-15 second segment, first divide macro beats. Densify only important hits.

Example for 15 seconds:

```text
0-3秒：空间建立与冲入
3-6秒：第一轮近身交锋
6-9秒：格挡/反制/变招
9-12秒：高潮碰撞，加入撞击运镜和环境破坏
12-15秒：余波、站位变化、结尾定格
```

Each beat can follow:

```text
时间段 + 景别/角度 + 复合运镜链 + 锁焦对象 + 主体动作 + 命中/格挡/转折 + 撞击运镜 + 物理/环境反馈 + 特效
```

Before writing each beat, check:

- If something enters the image, write its screen direction and path, e.g. `from screen left`, `from above`, `from behind the villain`, not only `foreground`.
- If the shot is medium-wide or wide, describe the full-body posture, field pressure, attack path, collapse, or spatial result. Put tiny details such as finger trembling into a separate close-up.
- If the beat is shorter than 2 seconds, use one clean visual mechanism. Do not stack shatter, reverse flow, fragmentation, and disappearance unless the duration is extended.
- If an array or law-field appears, identify its source clearly: Shen Xuan's fingers, eyes, sleeve, back halo, sky array above him, villain's chest, or the environment.
- At impact, include an air ring, contact flash, hit stop, camera shake, pressure wave, and secondary motion such as hair or clothing blown backward if the hit needs weight. For invincible calm characters, keep expression, posture, feet, and body center unchanged unless vulnerability is requested.

## Multi-Segment Narrative Prompt

Use this when a long script needs to become several short AI video prompts.

```text
【分段总控】
每段时长：5-15秒。
分段原则：一个段落只服务一个核心视觉钩子；每段有开场吸引点、动作推进、结尾定格。
连续性：上一段结尾的空间/角色/能量状态，必须成为下一段开头的已知状态。

【第1段｜标题｜时长】
叙事目的：
视觉钩子：
时间轴：
0.0-X.X秒：
X.X-X.X秒：
结尾定格：
一致性与禁止项：
```

Segment selection priority:

1. Spectacle hook: the first second must show a striking image, threat, reveal, or impossible scale.
2. Narrative clarity: each segment should advance status, power, memory, escalation, or outcome.
3. Visual continuity: preserve character design, power colors, environment state, and previous aftermath.
4. Audience retention: end each segment with a question, reveal, impact, transformation, or dominant pose that invites the next segment.

## Optional JSON Storyboard

Use JSON only when the user asks for JSON, table-like machine readability, or structured downstream production.

```json
{
  "Shot_Number": "Shot_001",
  "Duration_sec": 3,
  "Shot_Type": "全景",
  "Camera_Angle": "低机位微仰",
  "Camera_Movement": "稳定起幅 -> 贴地跟拍前推 -> 命中点急推 -> 顿帧0.2秒 -> 短促震动 -> 稳定落幅",
  "Action_Description": "写明意图、执行、碰撞、反应、恢复或转折。",
  "Focus_Point": "锁焦对象，例如拳锋、剑尖、手部结印、护盾裂纹、受击面部。",
  "Physical_Feedback": "身体形变、后退、坠落、衣摆/发丝惯性、武器震动。",
  "Environment_Reaction": "地面裂纹、碎石、烟尘、墙体崩落、水面冲击。",
  "VFX": "火花、粒子、冲击波、法阵、护盾破裂等。",
  "Storyboard_Prompt": "Copyable English or Chinese visual prompt for this shot."
}
```

## Diagnosis Output

When the user asks to check or improve an existing fight prompt, use:

```text
【主要问题】
列出动作逻辑、空间、节奏、运镜、类型物理、反馈、禁止项的问题。

【修改原则】
给出应如何修。

【改写版】
输出可直接复制的修正版提示词。
```

## Negative Constraints

Use constraints that match the requested medium. Common constraints:

```text
禁止动作干瘪，只写“A打B”；禁止景别错位，用眼睛特写承载大跨度位移；禁止静态摆拍感和运镜缺失；禁止风格物理法则串味；禁止无意义画质词堆砌；禁止空间关系混乱；禁止跳过碰撞和受击反应；禁止只写“激烈打斗”；禁止单一运镜词；禁止角色服装/武器/能力颜色漂移；禁止特效遮挡主体动作；禁止现代物件误入古装/玄幻场景；禁止字幕、水印、UI、低清晰度、塑料质感。
```
