# Combat Storyboard Knowledge

Use this reference for fight logic, camera design, and type-specific physical rules.

## Core Logic

Fight storyboard design converts action beauty into structured spatial logic, physical energy, rhythm, and camera rules. Every useful fight beat should answer:

- Who has intent?
- How does the attacker prepare and release force?
- Where is the collision, block, dodge, or reversal?
- What body and environment feedback follows?
- How does the fight state change after the beat?

Never jump from execution directly into the next intent. Collision and reaction create weight.

## Action Cycle

```text
intent/prep -> execution/force release -> collision/receive -> reaction/consequence -> recovery/transition
```

Use this cycle for punches, kicks, weapons, magic attacks, throws, and ranged strikes.

## Body Mechanics

- Track center of gravity. Stable attacks keep balance; unstable reactions push the center outside the support foot.
- Build force through the chain: foot drive -> hips -> torso rotation -> shoulder/arm -> fist, foot, weapon, or spell release.
- Separate preparation and strike. Slow preparation builds energy; fast release spends it.
- Add compensation. The body or legs counter-rotate to stabilize a hard swing or weapon strike.
- Prefer arcs for limbs, weapons, throws, and dodges. Use straight paths only for punches, thrusts, firearms, beams, or deliberate charges.

## Distance Logic

| Distance | Actions | Storyboard Use |
| --- | --- | --- |
| Long | charge, flying kick, thrust, ranged weapon, spell trajectory | speed, route, battlefield scale |
| Medium | punches, weapons, shields, staffs, sword exchanges | technique and attack-defense readability |
| Close | elbow, knee, clinch, choke, throw, joint lock | pain, pressure, brutality |

Always establish the environment, positions, usable objects, danger zones, and escape routes before dense action.

## Shot Scale

| Shot scale | Use |
| --- | --- |
| Extreme wide / wide | battlefield, danger, destruction range, distance |
| Full shot | body action, stance, movement, spatial relation |
| Medium shot | attack-defense exchange and weapon contact |
| Close-up | effort, pain, expression, body deformation |
| Insert / macro | fist, foot, blade, spark, eye, seal, impact point |

Avoid three or more same-scale shots in a row unless the user asks for a deliberate style.

Shot-scale information hierarchy:

- Close-up / insert: use for fingers, eyes, breath, tiny cracks, weapon tips, impact sparks, and micro-reactions.
- Medium shot: use for a character's upper-body action, defensive posture, hand technique, and readable interaction with nearby energy.
- Medium-wide / wide: use for whole-body stance, formation, attack path, field pressure, knockback, collapse, and spatial outcomes. Do not hide tiny details such as finger trembling inside a medium-wide shot; the model will not know whether to show detail or composition.
- If the desired detail is small, cut to a close-up or insert before returning to the wider shot.

Screen-direction rule:

- Describe what enters the frame and from where. Use "from screen left/right/top/bottom", "from behind the villain", "from above Shen Xuan", or "from the far background toward camera".
- Avoid relying on abstract labels such as "foreground smoke" unless the visual object, direction, and stop point are specified.
- Good: "red-black demonic smoke enters rapidly from screen left, crosses the lower third of the frame, and stops three feet in front of Shen Xuan's chest."
- Weak: "foreground red-black smoke rushes toward him."

## Camera Movement

Camera movement is an extension of action. It should transmit kinetic force, pain, space, or transition.

| Movement | Function | Rule |
| --- | --- | --- |
| Push-in | approaching attack or pain | slow push for pressure; whip-in for surprise impact |
| Pull-out | aftermath and destruction range | use for knockback, explosion, AOE, battlefield expansion |
| Pan | horizontal tracking or searching | follow strikes or scan for a landing point |
| Dolly / tracking | chase, charge, companion movement | side track for clashes; forward/back track for charge |
| Rise/fall | vertical action | use for aerial combat, lightness skills, falling impacts |
| Orbit | isolation, encirclement, hero pose | use for charge-up, surrounded character, 360-degree fight |

Hard rules:

- Sync camera direction and speed with the action's force.
- Add impact push, hit stop, or shake for major hits, unless using a deliberate fixed wide shot.
- Give moving shots a clear start frame and end frame.
- Use foreground wipe/occlusion to hide weak action and increase depth.

## Impact Methods

- Hit Stop: freeze contact for 0.1-0.2 seconds.
- Impact Push: push camera in the attack direction at contact.
- Camera Shake: short sharp shake for hand-to-hand impact, live-action pain, or explosive shock.
- Contact pressure feedback: show a bright contact point, expanding air ring, visible pressure wave, short hit stop, sharp camera shake, and secondary motion such as hair tips, sleeves, and robe hems being blown backward by the shock.
- Aftermath hold: hold on recoil, stagger, collapse, broken shield, dust, or breath.

The audience feels pain mostly from aftermath, not from contact alone.

Invincible-calm contact rule:

- When Shen Xuan or a similar overpowering character receives or blocks an attack without being harmed, let the environment and clothing react while the character does not. Hair tips, sleeves, and robe hems may be blown backward by the pressure wave, but the face stays expressionless, the eyes remain calm, the feet do not slide, and the body center does not recoil.
- Do not imply pain, fear, loss of balance, or damage on the invincible character unless the user explicitly asks for vulnerability.

Short-beat capacity rule:

- In 1-2 seconds, avoid complicated sequences such as "cut into fragments -> reverse flow -> roll back -> disappear" unless each stage is visually essential and separately timed.
- For fast kill beats, prefer one readable mechanism: shockwave burst, glass-like shatter, particle disintegration, light erasure, or instant compression.
- If contact matters, add a visible contact event: a bright contact point, expanding air ring, impact push, 0.1-0.2 second hit stop, short camera shake, pressure wave, and cloth/hair shock response.
- To avoid cheap pixel-game fragments, describe fragments as "fine ash-like particles", "black glass dust", "smoke-like particles dissolving in air", or "energy motes evaporating", not as blocky pieces.

Power-source clarity rule:

- State where arrays, light pressure, or law-fields originate.
- If Shen Xuan releases it, tie it to his eyes, fingers, sleeves, chest, back halo, or a descending sky array above/behind him.
- Avoid ambiguous ground arrays when the viewer might think the villain owns the spell. Prefer "a golden law array descends from the sky behind Shen Xuan and presses downward onto the villain" over "golden array patterns light up on the ground".

## Fight Rhythm

Single heavy hit:

```text
prep 2-3s -> contact 0.5-1s -> consequence 3-5s
```

Full fight curve:

```text
space setup -> probe -> first exchange -> pause -> escalation -> disadvantage -> counterattack -> climax collision -> ending hold
```

Attack-defense patterns:

- 1:1 equal exchange: technical duel.
- 2:1 pressure: one side dominates.
- 1:3 counter: one side absorbs or avoids several attacks, then reverses with one decisive hit.

## Action Vocabulary

Unarmed: straight punch, hook, swing, uppercut, elbow, knee, front kick, side kick, roundhouse, spinning kick, axe kick.

Defense: block, parry, deflect, absorb, dodge, duck, sidestep, roll, breakfall.

Grappling: double-leg takedown, shoulder throw, choke, rear naked choke, armbar, joint lock, sweep, pin, throw reversal.

Weapons: thrust, slash, sweep, upward cut, disarm, bind, parry, blade slide, cross slash, combo strikes, heavy smash.

Fantasy/ranged: hand seal, charge, array expansion, sword qi, beam, flame burst, lightning strike, shield crack, particle recoil, weapon recall.

Feedback: head snap, body fold, shoulder collapse, stagger, knee drop, delayed cloth/hair movement, weapon vibration, cracked ground, broken wall, dust expansion.

## Environment Use

Treat the environment as a second fighter:

- Leverage: wall kick, table step, pillar turn, stone jump.
- Obstacle: wall collision, trip, cornering, doorway trap.
- Prop: chair, bottle, curtain, door, stick, tile, sand.
- Damage: shattered crate, cracked floor, cut wall, broken pillar.
- Emotion: candle extinguished, rain blown backward, dust blocking vision, blood trail.

## Genre Physics

| Type | Physics | Camera Style |
| --- | --- | --- |
| Modern combat | real force, footwork, body fatigue, pain | low handheld, physical movement, impact shake, medium/full shots |
| Wuxia | semi-real physics, lightness, qi, weapon rhythm | stabilizer/crane, smooth arcs, weapon-path tracking, eye close-ups |
| Xianxia/fantasy | magical physics, scale, powers, shields, arrays | gravity-free moves, dives, rises, FPV flight, particle traversal, extreme wides |
| Live-action stunt | real physics plus acrobatics, props, practical pain | stable wide/medium-wide, clear prop geography, environment-first movement |

Do not let one type's physics overwrite another unless the user explicitly asks for a hybrid.

## Negative Prompt Repair Rules

Treat user-provided weak fight prompts as diagnosis targets before rewriting. Reject or repair these failures:

| Failure | Reject | Repair Rule |
| --- | --- | --- |
| Dry action | `A hits B, B falls down` | Add the full physical loop: intent/prep -> execution -> collision -> reaction/consequence -> recovery/transition. |
| Shot-scale mismatch | eye close-up carrying a room-crossing flying kick | Use close-ups only for local details, force buildup, emotion, or impact details; use wide, full, or medium tracking shots for large spatial travel. |
| Missing camera dynamics | static posed action with no motion force | Bind the camera to the action path and add impact feedback such as push-in, hit stop, shake, recoil, pull-out, or aftermath hold. |
| Genre-law drift | modern combat suddenly adds hovering, spells, or impossible physics | Lock the requested physical law first; modern combat stays grounded, wuxia may use lightness and weapon arcs, xianxia/fantasy may use arrays and scale. |
| Empty quality-word stacking | generic cinematic/8K/detail words replace choreography | Spend words on body posture, camera position, action path, light, environment, material response, and the fight-state change. |

Example repairs:

- Weak: `A man punches another man in the face, the other man falls down.`
  Repair by adding stance, intent, punch path, contact point, hit stop, body fold, foot slide, environment reaction, and ending state.
- Weak: `Close up on A's eyes, A does a flying kick across the room and kicks B, B crashes into the wall.`
  Repair by splitting the eye close-up into a pre-action insert, then cutting to a wide/full tracking shot for the flying kick path, impact, wall collision, debris, and aftermath.

## Common Fixes

| Problem | Cause | Fix |
| --- | --- | --- |
| Light action | missing collision/reaction | add impact point, deformation, recoil, damage, transition |
| Fake fighting | no prep/recovery or force chain | add gravity, footwork, preparation, body compensation |
| Confusing space | no establishing shot or broken axis | start with wide/overhead or neutral shot, then tighten |
| No pain | only contact is described | add hit stop, deformation, knockback, aftermath |
| Flat rhythm | same speed, shot scale, or move | add pause, reversal, slow motion, jump cut, shot variation |
| Genre mismatch | mixed physics | lock genre physics first |
| Empty spectacle | effects replace action | tie effects to impact point, trajectory, and environment feedback |
| Weak camera | one-word movement | write compound chain: start frame -> track/pan/push -> impact -> end frame |
| Ambiguous screen action | abstract labels such as foreground/background without visible direction | describe the object, screen-entry direction, path, stop point, and relation to the subject |
| Detail-scale conflict | tiny finger or eye detail inside a medium-wide shot | move the detail to a close-up/insert, then return to the wider shot for spatial consequence |
| Overloaded short beat | too many transformations inside 1-2 seconds | extend the duration or simplify to one visual mechanism such as shockwave, disintegration, or erasure |
| Ambiguous spell ownership | ground effects or arrays with unclear source | state whether the array descends from Shen Xuan, rises from the villain, or belongs to the environment |
