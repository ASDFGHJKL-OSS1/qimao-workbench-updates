/* Non-destructive ranges always refer to the original video. */
(()=>{
'use strict';
const round=n=>Math.round(n*1000)/1000;
function merge(ranges){const out=[];ranges.map(r=>r.map(round)).sort((a,b)=>a[0]-b[0]).forEach(r=>{if(out.length&&r[0]<=out[out.length-1][1]+0.001)out[out.length-1][1]=Math.max(out[out.length-1][1],r[1]);else out.push([...r])});return out}
function subtract(ranges,cut){return ranges.flatMap(([a,b])=>b<=cut[0]||a>=cut[1]?[[a,b]]:[[a,Math.min(b,cut[0])],[Math.max(a,cut[1]),b]].filter(([x,y])=>y-x>=0.1).map(r=>r.map(round)))}
const total=ranges=>ranges.reduce((sum,[a,b])=>sum+b-a,0);
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
window.QimaoReplicaRanges={merge,subtract,total,same};
const $v=id=>document.getElementById('replica-'+id),player=$v('player');
let asset=null,ranges=[],pending=false,timer=null,assetVersion=0,sourceVersion=0,source=null,loadingSource=false,editedMode=false,focusReplica=false;
const chosen=()=>source?.shots.find(s=>s.no===Number($v('shot').value)&&s.state==='saved');
const processing=()=>pending||['preparing','importing','editing'].includes(asset?.phase);
const editMatches=()=>asset?.phase==='ready'&&!!asset.edit&&same(ranges,asset.edit.ranges);
function error(message=''){$v('error').textContent=message;$v('error').hidden=!message}
function remember(){try{localStorage.setItem('qimao-replica-asset',asset.id);if(asset.duration)localStorage.setItem('qimao-replica-ranges:'+asset.id,JSON.stringify(ranges))}catch(_){}}
function sync(){
 const busy=processing(),duration=asset?.duration||0,valid=ranges.length>0&&ranges.length<=20&&total(ranges)<=60.001;
 $v('drop').setAttribute('aria-disabled',String(busy));$v('file').disabled=busy;$v('download').disabled=busy||!$v('url').value.trim();$v('url').disabled=busy;
 ['in','out','keep','remove','add','reset','render'].forEach(id=>$v(id).disabled=busy||!duration||(id==='render'&&!valid));
 ['set-in','set-out'].forEach(id=>$v(id).disabled=busy||!duration||editedMode);
 $v('source-view').disabled=!duration;$v('edit-view').disabled=!asset?.edit;
 $v('job').disabled=loadingSource||pending||!$v('job').options.length;$v('shot').disabled=loadingSource||pending||!source;
 $v('ideas').disabled=pending;$v('start').disabled=busy||loadingSource||!chosen()||!editMatches()||activeStatuses.includes(job?.status);
 $v('render').textContent=editMatches()?'重新生成剪辑预览':'生成剪辑预览';
 $v('total').textContent='已保留 '+total(ranges).toFixed(2)+' 秒 / 最多60秒'+(!valid?' · 请删减到60秒以内，保留1至20段。':asset?.edit&&!editMatches()?' · 区间已改变，请重新生成剪辑预览。':'');
 $v('total').classList.toggle('warn',!!duration&&!valid);
 $v('readiness').textContent=editMatches()?(chosen()?'已准备好：将剪辑视频套用到片段 '+chosen().no+'，检查后再回填。':'剪辑已就绪，请选择要套用的已回填片段。'):'先导入视频、调整保留区间，再生成剪辑预览。';
}
function renderRanges(){
 const duration=asset?.duration||1;
 $v('timeline').innerHTML=ranges.map(([a,b])=>`<span style="left:${a/duration*100}%;width:${(b-a)/duration*100}%"></span>`).join('');
 $v('ranges').innerHTML=ranges.map(([a,b],i)=>`<span class="replica-range">${a.toFixed(2)}–${b.toFixed(2)}秒<button type="button" data-remove-range="${i}" aria-label="移除第${i+1}个保留区间" ${processing()?'disabled':''}>×</button></span>`).join('');sync();
}
function showVideo(edit=false){
 if(!asset?.duration||edit&&!asset.edit)return;editedMode=edit;
 const url=edit?asset.edited_url:asset.source_url;
 if(player.getAttribute('src')!==url){player.pause();player.src=url;player.load()}
 $v('source-view').classList.toggle('active',!edit);$v('edit-view').classList.toggle('active',edit);
 $v('play-mode').textContent=edit?'正在预览剪辑结果 · 无参考音轨。调整区间请切回原视频；时间输入仍对应原视频。':'正在预览原视频；下方起止时间均对应原视频。';sync();
}
function acceptAsset(next,{fresh=false,showEdit=false}={}){
 const first=fresh||next.id!==asset?.id||!asset?.duration&&!!next.duration;
 asset=next;$v('status').textContent=next.message||'';$v('name').textContent=next.name||'';$v('video-workspace').hidden=!next.duration;
 if(first&&next.duration){
  ranges=!fresh&&next.edit?.ranges?next.edit.ranges.map(r=>[...r]):[[0,round(next.duration)]];
  if(!fresh)try{const saved=JSON.parse(localStorage.getItem('qimao-replica-ranges:'+next.id));if(Array.isArray(saved)&&saved.length<=20&&saved.every(r=>Array.isArray(r)&&r.length===2&&r.every(Number.isFinite)&&r[0]>=0&&r[1]<=next.duration+0.001&&r[1]-r[0]>=0.1))ranges=saved}catch(_){}
  $v('in').max=$v('out').max=next.duration;$v('in').value=0;$v('out').value=Math.min(60,next.duration).toFixed(3);showVideo(false);
 }
 if(showEdit&&next.edit)showVideo(true);renderRanges();remember();
}
function pollAsset(version,showEdit=false){
 clearTimeout(timer);timer=setTimeout(async()=>{if(version!==assetVersion||!asset)return;try{const next=await api('/api/replica/asset/'+asset.id);if(version!==assetVersion)return;acceptAsset(next,{showEdit:showEdit&&next.phase==='ready'});if(['preparing','importing','editing'].includes(next.phase))pollAsset(version,showEdit);else if(next.phase==='error')error(next.message)}catch(e){if(version===assetVersion){error(e.message+'；可重新打开此页面恢复查看。');pending=false;sync()}}},900);
}
function receive(next,showEdit=false){const version=++assetVersion;acceptAsset(next,{fresh:next.id!==asset?.id});if(['preparing','importing','editing'].includes(next.phase))pollAsset(version,showEdit);else if(showEdit)showVideo(true)}
async function upload(file){
 if(processing()||!file)return;if(file.size>200*1024*1024||!file.size)return error('请使用200MB以内的非空视频');
 if(!/\.(mp4|mov|m4v|webm|mkv)$/i.test(file.name))return error('请选择MP4、MOV、M4V、WebM或MKV视频');
 pending=true;error();sync();$v('upload-progress').hidden=false;$v('upload-progress').value=0;$v('status').textContent='正在上传视频…';
 try{
  const next=await new Promise((resolve,reject)=>{const xhr=new XMLHttpRequest();xhr.open('POST','/api/replica/upload?name='+encodeURIComponent(file.name));xhr.setRequestHeader('X-Workbench-Token',token);xhr.setRequestHeader('Content-Type','application/octet-stream');xhr.timeout=600000;xhr.upload.onprogress=e=>{if(e.lengthComputable)$v('upload-progress').value=e.loaded/e.total*100};xhr.onload=()=>{try{const result=JSON.parse(xhr.responseText);if(xhr.status<200||xhr.status>=300)throw Error(result.error||'视频上传失败');resolve(result)}catch(e){reject(e)}};xhr.onerror=()=>reject(Error('视频上传连接中断，请重新选择'));xhr.ontimeout=()=>reject(Error('视频上传超时，请重新选择'));xhr.send(file)});
  receive(next);
 }catch(e){error(e.message)}finally{pending=false;$v('upload-progress').hidden=true;$v('file').value='';sync()}
}
function selection(){const a=Number($v('in').value),b=Number($v('out').value);if(!$v('in').value||!$v('out').value||!Number.isFinite(a)||!Number.isFinite(b)||a<0||b>asset.duration+0.001||b-a<0.1)throw Error('请设置原视频范围内的起止时间，至少0.1秒');return [round(a),round(Math.min(b,asset.duration))]}
function mutate(action){if(processing()||!asset?.duration)return;error();try{const cut=selection();ranges=action==='keep'?[cut]:action==='remove'?subtract(ranges,cut):merge([...ranges,cut]);remember();renderRanges()}catch(e){error(e.message)}}
async function loadSource(id){
 const version=++sourceVersion;loadingSource=true;source=null;$v('shot').innerHTML='';targetPreview();sync();
 try{const next=await api('/api/job/'+encodeURIComponent(id));if(version!==sourceVersion)return;if(next.status!=='complete'||next.historical)throw Error('请先完成该集01—04回填与核验');source=next;$v('shot').innerHTML=next.shots.filter(s=>s.state==='saved').map(s=>`<option value="${s.no}">片段 ${String(s.no).padStart(2,'0')} · ${s.duration}秒</option>`).join('');if(next.id===job?.id&&currentShot()?.state==='saved')$v('shot').value=currentShot().no;targetPreview()}catch(e){if(version===sourceVersion)error(e.message)}finally{if(version===sourceVersion){loadingSource=false;sync()}}
}
function ideaKey(){return source&&chosen()?'qimao-replica-ideas:'+source.id+':'+chosen().no:null}
function targetPreview(){const s=chosen();$v('prompt-preview').hidden=!s;if(s){$v('prompt-title').textContent=source.project_name+' · 第'+source.episode+'集 · 片段 '+s.no;$v('prompt-text').textContent=s.candidate||s.original}try{$v('ideas').value=localStorage.getItem(ideaKey())||''}catch(_){$v('ideas').value=''}sync()}
window.addEventListener('qimao:revision-setup',e=>{
 if(focusReplica){focusReplica=false;document.getElementById('video-replica').scrollIntoView({behavior:'smooth',block:'start'})}
 const {rows,preferred}=e.detail;sourceVersion++;source=null;loadingSource=false;$v('job').innerHTML=rows.map(j=>`<option value="${esc(j.id)}">${esc(j.project_name)} · 第${j.episode}集 · ${esc(j.updated||j.created)}</option>`).join('');$v('shot').innerHTML='';$v('no-source').hidden=!!rows.length;targetPreview();if(rows.length){$v('job').value=preferred||rows[0].id;loadSource($v('job').value)}
});
window.addEventListener('qimao:context',sync);
document.getElementById('replica-open').onclick=()=>{focusReplica=true;document.getElementById('step05-button').click()};
const drop=$v('drop');drop.onclick=()=>{if(!processing())$v('file').click()};drop.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();drop.click()}};
['dragenter','dragover'].forEach(name=>drop.addEventListener(name,e=>{e.preventDefault();if(!processing())drop.classList.add('dragging')}));drop.ondragleave=()=>drop.classList.remove('dragging');drop.ondrop=e=>{e.preventDefault();drop.classList.remove('dragging');if(e.dataTransfer.files.length!==1)return error('每次请拖入一个参考视频');upload(e.dataTransfer.files[0])};
// Stop dropped files opening a browser tab when they miss the drop area.
document.getElementById('video-replica').addEventListener('dragover',e=>e.preventDefault());document.getElementById('video-replica').addEventListener('drop',e=>e.preventDefault());
 $v('file').onchange=e=>upload(e.target.files[0]);$v('url').oninput=sync;
 $v('download').onclick=async()=>{if(processing())return;pending=true;error();sync();$v('status').textContent='正在连接谱码公开视频…';try{receive(await api('/api/replica/import',{url:$v('url').value.trim()}))}catch(e){error(e.message)}finally{pending=false;sync()}};
 ['keep','remove','add'].forEach(action=>$v(action).onclick=()=>mutate(action));
 $v('reset').onclick=()=>{if(processing()||!asset?.duration)return;ranges=[[0,round(asset.duration)]];remember();renderRanges();error()};
 $v('ranges').onclick=e=>{const button=e.target.closest('[data-remove-range]');if(!button||processing())return;ranges=ranges.filter((_,i)=>i!==Number(button.dataset.removeRange));remember();renderRanges();error()};
 $v('source-view').onclick=()=>showVideo(false);$v('edit-view').onclick=()=>showVideo(true);
 ['in','out'].forEach(id=>$v('set-'+id).onclick=()=>{if(!editedMode)$v(id).value=player.currentTime.toFixed(3)});
 $v('render').onclick=async()=>{if(processing()||!ranges.length)return;pending=true;sync();error();try{receive(await api('/api/replica/edit',{asset_id:asset.id,ranges}),true)}catch(e){error(e.message)}finally{pending=false;sync()}};
 $v('job').onchange=()=>loadSource($v('job').value);$v('shot').onchange=()=>{targetPreview();error()};$v('ideas').oninput=()=>{const key=ideaKey();if(key)try{localStorage.setItem(key,$v('ideas').value)}catch(_){}};
 $v('start').onclick=async()=>{
  if(processing()||loadingSource)return;error();if(dirty)return error('请先保存当前片段的本地修改');if(!editMatches()||!chosen())return error('请生成当前剪辑预览，并选择一个已回填片段');
  pending=true;sync();try{const result=await api('/api/replica/start',{id:source.id,numbers:[chosen().no],asset_id:asset.id,edit_id:asset.edit.id,instructions:$v('ideas').value});await openJob(result.id);await refreshJobs();toast('视频深度复刻已开始，完成后检查完整稿与差异再回填。')}catch(e){error(e.message)}finally{pending=false;sync()}
 };
 try{const id=localStorage.getItem('qimao-replica-asset');if(/^[a-f0-9]{32}$/.test(id||''))api('/api/replica/asset/'+id).then(next=>{if(!asset&&!pending){const version=++assetVersion;acceptAsset(next);if(['preparing','importing','editing'].includes(next.phase))pollAsset(version)}}).catch(()=>{})}catch(_){}
 sync();
})();
