/* Independent signed update channel. No project data is sent to the release server. */
(()=>{
  const el=id=>document.getElementById(id), page=crypto.randomUUID();
  let state=null, editing=false, changed=false, pending=false, wasInstalling=false, running=false, lastError='';
  const dialog=el('updates-dialog');
  const unsaved=()=>typeof dirty!=='undefined'&&dirty;
  const payload=()=>({page,dirty:unsaved()});
  async function reconnect(){const h=await api('/api/health');token=h.token;return h;}
  function showError(message){el('update-error').textContent=message;el('update-error').hidden=!message;}
  function render(s){
    state=s;el('update-version').textContent='v'+s.version;el('update-current').textContent='v'+s.version;
    el('update-key').textContent=s.public_key_fingerprint;
    const admin=!!s.admin;
    el('update-role').textContent=admin?'高级管理员':'普通用户';
    el('admin-login').hidden=admin;
    const pub=s.publisher||{};
    el('publisher-panel').hidden=!admin;
    el('publisher-status').textContent=pub.message||(pub.unlocked?'已解锁统一发布，修改程序后会自动提交':'统一发布尚未完成首次配置');
    el('publisher-submit').disabled=!pub.unlocked||pub.active||s.busy||s.unsaved||pub.phase==='submitted';
    el('publisher-setup').hidden=!s.publisher_setup_available||pub.unlocked;
    el('publisher-details').hidden=!pub.details_url;
    if(pub.details_url)el('publisher-details').href=pub.details_url;
    el('update-settings').classList.toggle('update-readonly',!admin);
    for(const id of ['update-server','update-channel','update-policy','update-settings-save','update-import'])el(id).disabled=!admin;
    el('updates-open').classList.toggle('has-update',s.available);
    el('updates-open').textContent=s.available?'● 有新版本':'↻ 版本更新';
    el('update-headline').textContent=s.installing?'正在更新，请稍候':s.available?'新版本已就绪':s.settings.server_url?'你的创作工具，持续进化':'连接你的独立更新服务器';
    el('update-status').textContent=s.message||'等待检查';
    el('update-progress').value=s.progress||0;
    showError(s.error||'');
    if(!editing&&!changed){el('update-server').value=s.settings.server_url;el('update-channel').value=s.settings.channel;el('update-policy').value=s.settings.policy;}
    const active=['checking','downloading','verifying'].includes(s.phase)||s.installing;
    el('update-check').disabled=active||!s.settings.server_url||pending;
    el('update-download').disabled=active||!s.available||s.downloaded||pending;
    el('update-install').disabled=active||!s.downloaded||s.busy||s.unsaved||unsaved()||pending;
    el('update-settings-save').disabled=!admin||active||pending;
    el('update-import').disabled=!admin||active||pending;
    el('update-settings').hidden=!admin;
    el('update-import').hidden=!admin;
    el('update-save-hint').textContent=changed?'配置尚未保存':s.installing?'完成后会自动重新连接':s.unsaved||unsaved()?'请先保存各页面的片段修改，再安装更新':s.busy?'创作任务正在运行，完成后可安装':'每15分钟检查一次 · 仅在工作台打开时';
    const m=s.manifest;
    if(s.available&&m){try{const key='qimao-update-notified:'+m.channel+':'+m.version;if(!localStorage.getItem(key)){toast('发现七猫工作台新版本 v'+m.version+'，可在右上角查看');localStorage.setItem(key,'1');}}catch(_){}}
    el('update-next').textContent=m?'v'+m.version+(m.channel==='beta'?' · 测试版':' · 正式版'):'等待首次发布';
    el('update-notes').replaceChildren();
    const notes=m?.notes||['独立服务器更新通道，支持正式版与测试版。','更新包签名校验、空闲安装与启动失败回滚。'];
    notes.forEach(n=>{const li=document.createElement('li');li.textContent=n;el('update-notes').append(li);});
    el('update-history').replaceChildren();
    (s.history||[]).forEach(h=>{const p=document.createElement('p');p.textContent='v'+h.version+' · '+h.published_at.slice(0,10)+' · '+h.notes.join('；');el('update-history').append(p);});
    if(!(s.history||[]).length)el('update-history').textContent='首次安装的 v'+s.version+' · 后续升级记录将在这里保留';
    if(wasInstalling&&!s.installing){toast(s.message);wasInstalling=false;}
    if(s.installing)wasInstalling=true;
  }
  async function refresh(tick=false){
    if(running)return;running=true;
    try{await reconnect();render(await api(tick?'/api/updates/tick':'/api/updates/status',tick?payload():undefined));lastError='';}
    catch(e){if(wasInstalling){el('update-status').textContent='工作台正在重启，正在自动重新连接…';}else if(dialog.open){showError('连接中断，请确认本地工作台已启动。');}}
    finally{running=false;}
  }
  async function act(name){
    if(name==='install'){
      if(unsaved())return showError('请先保存当前片段的修改');
      if(!confirm('安装后工作台将自动重启。项目、提示词和聊天数据会保留，确定现在安装？'))return;
    }
    pending=true;
    try{await reconnect();await api('/api/updates/page',payload());render(await api('/api/updates/'+name,{}));}
    catch(e){showError(e.message);}finally{pending=false;}
  }
  el('publisher-submit').onclick=async()=>{try{render(await api('/api/updates/publish',{}));}catch(e){showError(e.message);}};
  el('publisher-setup').onsubmit=async e=>{e.preventDefault();try{render(await api('/api/updates/publisher/setup',{password:el('publisher-setup-password').value,token:el('publisher-setup-token').value}));el('publisher-setup-password').value='';el('publisher-setup-token').value='';toast('统一密码发布已启用');}catch(e){showError(e.message);}};
  el('admin-login-button').onclick=async()=>{try{await reconnect();render(await api('/api/updates/admin-login',{password:el('admin-password').value}));el('admin-password').value='';toast('高级管理员权限已解锁');}catch(e){showError(e.message);}};
  el('updates-open').onclick=()=>{dialog.showModal();refresh();};el('updates-close').onclick=()=>dialog.close();
  for(const action of ['check','download','install'])el('update-'+action).onclick=()=>act(action);
  el('update-settings').addEventListener('focusin',()=>editing=true);
  el('update-settings').addEventListener('focusout',()=>editing=false);
  el('update-settings').addEventListener('input',()=>{changed=true;el('update-save-hint').textContent='配置尚未保存';});
  el('update-settings').onsubmit=async e=>{
    e.preventDefault();pending=true;
    try{await reconnect();const s=await api('/api/updates/settings',{server_url:el('update-server').value.trim(),channel:el('update-channel').value,policy:el('update-policy').value});changed=false;editing=false;render(s);toast('更新设置已保存');}
    catch(e){showError(e.message);}finally{pending=false;}
  };
  el('update-import').onclick=()=>{if(!state?.admin)return showError('只有高级管理员可以导入签名更新包');el('update-file').click();};
  el('update-file').onchange=async()=>{
    const f=el('update-file').files[0];if(!f)return;
    if(!f.size||f.size>64*1024*1024)return showError('请选择不超过64MB的签名ZIP更新包');
    pending=true;
    try{await reconnect();el('update-status').textContent='正在导入并校验本地更新包…';const r=await fetch('/api/updates/import',{method:'POST',headers:{'Content-Type':'application/zip','X-Workbench-Token':token},body:f});const s=await r.json();if(!r.ok)throw Error(s.error||'导入失败');render(s);}
    catch(e){showError(e.message);}finally{pending=false;el('update-file').value='';}
  };
  document.getElementById('prompt-editor').addEventListener('input',()=>api('/api/updates/page',payload()).catch(()=>{}));
  window.addEventListener('pagehide',()=>fetch('/api/updates/page',{method:'POST',headers:{'Content-Type':'application/json','X-Workbench-Token':token},body:JSON.stringify({...payload(),closed:true}),keepalive:true}).catch(()=>{}));
  setInterval(()=>refresh(!pending&&!changed),15000);
  setInterval(()=>{if(dialog.open||wasInstalling)refresh();},2000);
  refresh(true);
})();
