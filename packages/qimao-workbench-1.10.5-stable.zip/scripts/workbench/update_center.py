"""Independent update client; checks only versions, never uploads projects."""
import copy, hashlib, hmac, json, os, shutil, subprocess, sys, threading, time, urllib.request, uuid
from password_publisher import PasswordPublisher, fingerprint
from pathlib import Path
from update_protocol import UpdateError, MAX_PACKAGE, inspect_package, manifest_check, sha, url, version, write_json

class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        url(newurl)
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def fetch(address,limit):
    url(address)
    try:
        with urllib.request.build_opener(SafeRedirect()).open(address,timeout=30) as r:
            data=r.read(limit+1)
        if len(data)>limit:raise UpdateError('更新响应超过大小限制')
        return data
    except UpdateError:raise
    except Exception as e:raise UpdateError('无法连接更新服务器，请检查地址、网络或服务器部署状态') from e

class UpdateCenter:
    def __init__(self,root,busy=lambda:False):
        self.root=Path(root);self.skill=self.root.parent.parent;self.dir=self.root/'data/updates'
        self.dir.mkdir(parents=True,exist_ok=True)
        self.lock=threading.RLock();self.operation=threading.Lock();self.busy=busy;self.maintenance=False;self.pages={}
        self.key=(self.root/'update-public.pem').read_text()
        self.current=json.loads((self.root/'version.json').read_text())['version']
        # 发布权限只授予发布者本机。普通安装用户永远只能检查、下载和安装。
        self.admin=os.environ.get('QIMAO_UPDATE_ADMIN','').strip().lower() in ('1','true','yes','on')
        self.admin_auth=self.read('admin-auth.json',{})
        self.admin_unlocked=False
        self.publisher=PasswordPublisher(self.root);self.publisher_poll=threading.Lock()
        self.settings=self.read('settings.json',{'server_url':'https://asdfghjkl-oss1.github.io/qimao-workbench-updates','channel':'stable','policy':'notify'})
        if not self.settings.get('server_url'):
            self.settings.update(server_url='https://asdfghjkl-oss1.github.io/qimao-workbench-updates',channel='stable',policy='notify')
        self.state=self.read('state.json',{'phase':'idle','message':'尚未配置独立更新服务器','progress':0})
        self.recover_interrupted_install()
        if self.state.get('phase') in ('checking','downloading','verifying') and not (self.dir/'install.lock').exists():

            self.set(phase='error',error='上次更新操作已中断，可重新检查',message='已保留当前工作台版本')
    def recover_interrupted_install(self):
        lock=self.dir/'install.lock'
        if not lock.exists():return
        if self.state.get('phase') in ('complete','rolled_back'):
            lock.unlink(missing_ok=True);return
        try:
            info=json.loads(lock.read_text());pid=info.get('pid')
            if pid:
                try:os.kill(pid,0);return
                except ProcessLookupError:pass
            elif time.time()-lock.stat().st_mtime<60:return
        except (ValueError,OSError):
            if time.time()-lock.stat().st_mtime<60:return
        # A surviving installer owns the lock. A dead one is recovered by a new worker.
        request=self.dir/'install-request.json'
        if request.exists():
            with (self.dir/'installer.log').open('ab') as log:
                child=subprocess.Popen([sys.executable,str(self.root/'update_worker.py'),'--recover',str(request)],stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
            write_json(lock,{'pid':child.pid})
        else:
            lock.unlink(missing_ok=True)
            self.set(phase='error',message='安装准备已中断，当前程序已保留',error='请重新导入或检查更新')
    def page(self,data):
        with self.lock:
            page=str(data.get('page',''))
            if page and len(page)<=100:
                if data.get('closed'):self.pages.pop(page,None)
                else:self.pages[page]=(time.time(),bool(data.get('dirty')))
            return self.unsaved()
    def unsaved(self):
        # Background tabs may be suspended for minutes. Never expire a dirty page
        # merely because its heartbeat stopped; only a saved/closed event clears it.
        self.pages={k:v for k,v in self.pages.items() if v[1] or time.time()-v[0]<120}
        return any(v[1] for v in self.pages.values())
    def read(self,name,default):
        try:return json.loads((self.dir/name).read_text())
        except (OSError,ValueError):return default
    def set(self,**data):
        with self.lock:
            self.state.update(data);self.state['updated_at']=time.time();write_json(self.dir/'state.json',self.state)
    def status(self):
        with self.lock:
            self.recover_interrupted_install()
            # The detached installer owns persistent progress during restart/rollback.
            self.state=self.read('state.json',self.state)
            release=self.state.get('manifest') or {}
            return dict(copy.deepcopy(self.state),version=self.current,publisher=self.publisher.public(),publisher_setup_available=(Path.home()/'.codex/qimao-update-publisher/signing-private.pem').is_file(),admin=self.is_admin,version_update_role='高级管理员' if self.is_admin else '普通用户',settings=copy.deepcopy(self.settings),unsaved=self.unsaved(),busy=self.busy(),installing=self.maintenance or (self.dir/'install.lock').exists(),available=bool(release and version(release['version'])>version(self.current)),downloaded=bool(self.state.get('package') and (self.dir/self.state['package']).is_file()),public_key_fingerprint=sha(self.key.encode())[:16],history=self.read('history.json',[]))
    def settings_save(self,data):
        with self.lock:
            if not self.is_admin:raise UpdateError('只有高级管理员可以修改更新服务器、发布渠道和更新策略')
            if self.operation.locked() or (self.dir/'install.lock').exists():raise UpdateError('更新操作进行中，请稍后再保存')
            address=str(data.get('server_url','')).strip().rstrip('/')
            if address:url(address)
            channel=data.get('channel');policy=data.get('policy')
            if channel not in ('stable','beta') or policy not in ('notify','auto','off'):raise UpdateError('请选择有效渠道和检查策略')
            self.settings={'server_url':address,'channel':channel,'policy':policy};write_json(self.dir/'settings.json',self.settings)
            self.set(manifest=None,package=None,phase='idle',error='',last_check=0,message='已保存独立更新服务器' if address else '尚未配置独立更新服务器',progress=0)
            return self.status()
    def admin_login(self,password):
        try:
            self.publisher.login(password)
            self.admin=False
            return self.status()
        except UpdateError as e:
            if '404' not in str(e):raise
        auth=self.admin_auth
        if not auth.get('salt') or not auth.get('digest'):raise UpdateError('这台电脑未配置发布者管理员身份，普通用户可直接更新')
        digest=hashlib.pbkdf2_hmac('sha256',str(password or '').encode(),bytes.fromhex(auth['salt']),200000).hex()
        if not hmac.compare_digest(digest,auth['digest']):raise UpdateError('管理员密码不正确')
        self.admin=True
        return self.status()
    def action(self,name):
        if name not in ('check','download','install'):raise UpdateError('更新操作不存在')
        if not self.operation.acquire(False):raise UpdateError('已有更新操作正在执行')
        try:
            if (self.dir/'install.lock').exists():raise UpdateError('更新正在安装，请等待工作台恢复')
            if name=='install' and (self.busy() or self.unsaved()):raise UpdateError('请先保存所有页面的修改，并等待任务、助手与语音结束')
            if name=='check' and not self.settings['server_url']:raise UpdateError('请先配置自己的更新服务器地址')
            if name=='install':self.maintenance=True
            if name=='check':self.set(last_check=time.time())
            self.set(phase={'check':'checking','download':'downloading','install':'verifying'}[name],error='',message={'check':'正在检查独立服务器','download':'正在下载更新包','install':'正在复核签名与任务状态'}[name],progress=0)
            threading.Thread(target=self.run,args=(name,),daemon=True).start()
            return self.status()
        except Exception:self.maintenance=False;self.operation.release();raise
    def run(self,name):
        try:getattr(self,name)()
        except Exception as e:self.set(phase='error',error=str(e) if isinstance(e,UpdateError) else '更新操作未完成，当前版本已保留',message='更新未完成')
        finally:self.maintenance=False;self.operation.release()
    def check(self):
        address=f'{self.settings["server_url"]}/channels/{self.settings["channel"]}/latest.json'
        try:m=json.loads(fetch(address,1024*1024))
        except ValueError as e:raise UpdateError('服务器未返回有效更新清单') from e
        manifest_check(m,self.key,self.settings['channel'])
        if version(m['version'])<version(self.current):
            self.set(manifest=None,package=None,phase='current',message='服务器版本早于当前工作台，已阻止降级',last_check=time.time(),progress=0);return
        same=self.state.get('manifest') or {};package=self.state.get('package') if same and same.get('sha256')==m['sha256'] else None
        newer=version(m['version'])>version(self.current)
        self.set(manifest=m,package=package,phase='available' if newer else 'current',message=f'发现新版本 v{m["version"]}' if newer else '当前已是最新版本',last_check=time.time(),progress=100)
    def download(self):
        m=self.state.get('manifest')
        if not m:raise UpdateError('请先检查更新')
        manifest_check(m,self.key,self.settings['channel'])
        data=fetch(m['package_url'],min(MAX_PACKAGE,m['size']))
        path=self.dir/f'{m["sha256"]}.zip';temp=path.with_suffix('.part')
        temp.write_bytes(data)
        try:
            self.set(phase='verifying',message='正在校验签名与全部文件',progress=80)
            inspect_package(temp,self.key,m);os.replace(temp,path)
        finally:temp.unlink(missing_ok=True)
        self.set(package=path.name,phase='downloaded',message='更新包已通过签名与文件校验，可以安装',progress=100)
    def import_package(self,data):
        if not self.is_admin:raise UpdateError('只有高级管理员可以导入签名更新包')
        if not self.operation.acquire(False):raise UpdateError('已有更新操作正在执行')
        path=self.dir/(uuid.uuid4().hex+'.zip')
        try:
            if (self.dir/'install.lock').exists():raise UpdateError('更新正在安装')
            path.write_bytes(data);r=inspect_package(path,self.key)
            if version(r['version'])<version(self.current):raise UpdateError('不允许导入旧版本')
            m={k:r[k] for k in ('product','version','channel','notes','published_at')}
            m.update(source='local',sha256=sha(data),size=len(data))
            self.set(manifest=m,package=path.name,phase='downloaded',error='',message='本地签名包已校验，可安装或同版本修复',progress=100)
            return self.status()
        except Exception:path.unlink(missing_ok=True);raise
        finally:self.operation.release()

    @property
    def is_admin(self):
        return self.admin or self.admin_unlocked or self.publisher.unlocked

    def unlock_admin(self,password):
        return self.admin_login(password)
    def publish_start(self):
        if not self.publisher.unlocked:raise UpdateError('请先输入管理员密码，解锁统一发布')
        if self.busy() or self.unsaved():raise UpdateError('请先保存修改并等待工作台任务结束')
        if not self.operation.acquire(False):raise UpdateError('已有更新操作正在执行')
        self.publisher.active=True
        self.publisher.set(phase='uploading',message='正在打包程序并提交统一发布后台')
        def upload():
            try:self.publisher.publish(self.current)
            except Exception as e:self.publisher.set(phase='error',message=str(e) if isinstance(e,UpdateError) else '程序打包未通过，尚未发布')
            finally:self.publisher.active=False;self.operation.release()
        threading.Thread(target=upload,daemon=True).start()
        return self.status()
    def publisher_tick(self):
        if not self.publisher.unlocked or self.publisher.active or not self.publisher_poll.acquire(False):return
        def check():
            try:
                self.publisher.poll()
                fp=fingerprint(self.skill)
                if fp!=self.publisher.observed:self.publisher.observed=fp;self.publisher.stable_since=time.time()
                if fp!=self.publisher.last_fingerprint and time.time()-self.publisher.stable_since>=120 and not self.busy() and not self.unsaved() and self.publisher.state.get('phase') not in ('submitted','error'):
                    self.publish_start()
            except UpdateError:pass
            finally:self.publisher_poll.release()
        threading.Thread(target=check,daemon=True).start()
    def install(self):
        name=self.state.get('package');m=self.state.get('manifest')
        if not name or not m:raise UpdateError('请先下载校验或导入签名更新包')
        path=self.dir/name;release=inspect_package(path,self.key,m)
        if version(release['version'])<version(self.current):raise UpdateError('已阻止旧版本覆盖')
        if self.busy() or self.unsaved():raise UpdateError('请先保存所有页面的修改，并等待任务结束')
        lock=self.dir/'install.lock'
        try:fd=os.open(lock,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        except FileExistsError:raise UpdateError('更新安装已经启动')
        os.close(fd)
        config={'root':str(self.root),'package':str(path),'version':release['version'],'manifest':m}
        try:
            write_json(lock,{'pid':os.getpid()})
            write_json(self.dir/'install-request.json',config)
            self.set(backup=None,phase='installing',message='正在备份程序并安装，完成后自动重启',progress=10)
            with (self.dir/'installer.log').open('ab') as log:
                child=subprocess.Popen([sys.executable,str(self.root/'update_worker.py'),str(self.dir/'install-request.json')],stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
            write_json(lock,{'pid':child.pid})
        except Exception:lock.unlink(missing_ok=True);raise
    def tick(self,data=None):
        self.page(data or {})
        self.publisher_tick()
        s=self.status()
        if self.operation.locked() or s['installing'] or self.settings['policy']=='off' or not self.settings['server_url']:return s
        if time.time()-self.state.get('last_check',0)>900:
            # Persist before network request so offline servers are not hammered by each page.
            self.set(last_check=time.time());self.action('check')
        elif self.settings['policy']=='auto' and s['available'] and not s['busy'] and not s['unsaved'] and s.get('phase') in ('available','downloaded'):
            self.action('install' if s['downloaded'] else 'download')
        return self.status()
