"""跨电脑密码发布；客户端不持有后台签名私钥。"""
import ast,base64,hashlib,io,json,re,shutil,subprocess,time,urllib.error,urllib.request,uuid,zipfile
from pathlib import Path
from update_protocol import UpdateError,code_path,sha,verify,sign,write_json,MAX_PACKAGE
REPO='ASDFGHJKL-OSS1/qimao-workbench-updates'
BASE='https://asdfghjkl-oss1.github.io/qimao-workbench-updates'
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args):raise UpdateError('发布入口不能重定向')
def request(url,token='',body=None,method=None):
 headers={'Accept':'application/vnd.github+json','User-Agent':'qimao-workbench'}
 if token:headers['Authorization']='Bearer '+token
 if body is not None:headers['Content-Type']='application/json'
 req=urllib.request.Request(url,data=json.dumps(body).encode() if body is not None else None,headers=headers,method=method)
 try:
  with urllib.request.build_opener(NoRedirect()).open(req,timeout=60) as r:return json.load(r)
 except urllib.error.HTTPError as e:raise UpdateError('发布服务暂不可用或发布凭据已失效（HTTP '+str(e.code)+'）') from None
 except Exception as e:
  if isinstance(e,UpdateError):raise
  raise UpdateError('无法连接统一发布后台，请检查网络') from None

def crypt(root,op,**data):
 node=next((p for p in [shutil.which('node'),str(Path.home()/'.local/bin/node'),'/Applications/ChatGPT.app/Contents/Resources/cua_node/bin/node'] if p and Path(p).is_file()),None)
 if not node:raise UpdateError('缺少 Node.js 密码校验运行时')
 r=subprocess.run([node,str(Path(root)/'publisher_crypto.js')],input=json.dumps(dict(op=op,**data)),text=True,capture_output=True,timeout=30)
 if r.returncode:raise UpdateError('管理员密码不正确或发布凭据损坏')
 return json.loads(r.stdout)

def fingerprint(skill):
 h=hashlib.sha256()
 for p in sorted(Path(skill).rglob('*')):
  name=p.relative_to(skill).as_posix()
  if p.is_file() and not p.is_symlink() and code_path(name):h.update(name.encode());h.update(p.read_bytes())
 return h.hexdigest()

def snapshot(skill):
 skill=Path(skill);out=io.BytesIO()
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(skill.rglob('*')):
   name=p.relative_to(skill).as_posix()
   if not p.is_file() or p.is_symlink() or not code_path(name):continue
   if p.name in ('auth.json','admin-auth.json','config.toml','.env'):continue
   b=p.read_bytes()
   # 开发者目录也必须使用可迁移的运行入口，不能把本机绝对路径发给接收端。
   if name=='scripts/workbench/server.py':
    text=b.decode();text=re.sub(r'CLI = .*?\nCODEX = .*?\nSKILLS = .*?\n','from runtime_paths import CLI, CODEX, SKILLS\n',text,count=1);b=text.encode()
   if name.endswith('.py'):ast.parse(b.decode(),filename=name)
   info=zipfile.ZipInfo(name);info.external_attr=(0o100755 if p.stat().st_mode&0o111 else 0o100644)<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
 if out.tell()>MAX_PACKAGE:raise UpdateError('程序更新包超过64MB')
 return out.getvalue()

class PasswordPublisher:
 def __init__(self,root):
  self.root=Path(root);self.skill=self.root.parent.parent;self.key=(self.root/'update-public.pem').read_text();self.token='';self.expires=0;self.last_fingerprint='';self.observed='';self.stable_since=0;self.active=False
  self.path=self.root/'data/updates/password-publish.json'
  try:self.state=json.loads(self.path.read_text())
  except (OSError,ValueError):self.state={}
 def set(self,**fields):self.state.update(fields);write_json(self.path,self.state)
 @property
 def unlocked(self):return bool(self.token and time.time()<self.expires)
 def login(self,password):
  envelope=request(BASE+'/publisher-access.json');verify(envelope,self.key)
  if envelope.get('repository')!=REPO:raise UpdateError('发布凭据仓库不匹配')
  token=crypt(self.root,'decrypt',password=password,envelope=envelope)['token']
  request('https://api.github.com/repos/'+REPO,token)
  self.token=token;self.expires=time.time()+3600
  # 登录时记录基线，之后的程序修改才触发自动发布。
  self.observed=fingerprint(self.skill);self.last_fingerprint=self.observed;self.stable_since=time.time()
 def public(self):return dict(self.state,unlocked=self.unlocked,active=self.active)
 def publish(self,base_version):
  if not self.unlocked:raise UpdateError('请先输入管理员密码')
  fp=fingerprint(self.skill);data=snapshot(self.skill)
  if fingerprint(self.skill)!=fp:raise UpdateError('程序正在变化，等待修改完成后再发布')
  api='https://api.github.com/repos/'+REPO+'/'
  latest=request(api+'contents/channels/stable/latest.json',self.token)
  latest=json.loads(base64.b64decode(latest['content']))
  if latest['version']!=base_version:raise UpdateError('已有新版本，请先更新本机工作台，再修改和发布')
  blobs=[]
  for pos in range(0,len(data),512*1024):
   if not self.unlocked:raise UpdateError('管理员身份已过期，请重新输入密码')
   blob=request(api+'git/blobs',self.token,{'content':base64.b64encode(data[pos:pos+512*1024]).decode(),'encoding':'base64'},'POST');blobs.append(blob['sha'])
  ident=uuid.uuid4().hex;payload={'id':ident,'channel':'stable','base_version':base_version,'sha256':sha(data),'blobs':blobs,'notes':['管理员更新工作台程序；本机项目与历史数据保留。']}
  result=request(api+'contents/incoming/'+ident+'.json',self.token,{'message':'管理员提交工作台更新 '+ident,'content':base64.b64encode(json.dumps(payload).encode()).decode(),'branch':'main'},'PUT')
  self.set(phase='submitted',message='程序已提交，后台正在校验、签名和发布',request_id=ident,commit=result['commit']['sha'],submitted_fingerprint=fp)
  self.last_fingerprint=fp
 def poll(self):
  if self.state.get('phase')!='submitted' or not self.unlocked:return
  api='https://api.github.com/repos/'+REPO+'/'
  latest=request(api+'contents/channels/stable/latest.json',self.token);m=json.loads(base64.b64decode(latest['content']))
  if m.get('request_id')==self.state['request_id']:
   online=request(BASE+'/channels/stable/latest.json')
   if online.get('sha256')!=m['sha256']:return
   verify(online,self.key);self.set(phase='published',message='新版 v'+m['version']+' 已上线，其他用户可以检查更新',published_fingerprint=self.state['submitted_fingerprint'],published_version=m['version']);return
  runs=request(api+'actions/runs?head_sha='+self.state['commit']+'&per_page=5',self.token)
  for r in runs.get('workflow_runs',[]):
   if r.get('status')=='completed' and r.get('conclusion') not in ('success',None):self.set(phase='error',message='后台发布未通过，请查看发布记录',details_url=r['html_url'])
 def setup(self,password,token):
  # 仅首台发布者配置一次，不在其他电脑生成或保存签名私钥。
  keypath=Path.home()/'.codex/qimao-update-publisher/signing-private.pem'
  if not keypath.is_file():raise UpdateError('只能在首次配置的发布者电脑完成初始化')
  if not token.startswith('github_pat_'):raise UpdateError('请输入仅限更新仓库的细粒度令牌')
  request('https://api.github.com/repos/'+REPO,token)
  envelope=crypt(self.root,'encrypt',password=password,token=token);envelope['repository']=REPO;envelope=sign(envelope,keypath.read_text())
  api='https://api.github.com/repos/'+REPO+'/contents/publisher-access.json'
  body={'message':'配置管理员密码发布入口','content':base64.b64encode(json.dumps(envelope).encode()).decode(),'branch':'main'}
  # 不把个人账号的广泛授权放进安装包，只提交专用令牌的密文。
  try:old=request(api,token);body['sha']=old['sha']
  except UpdateError as e:
   if '404' not in str(e):raise
  request(api,token,body,'PUT')
  self.token=token;self.expires=time.time()+3600;self.observed=fingerprint(self.skill);self.last_fingerprint=self.observed;self.stable_since=time.time()
  self.set(phase='ready',message='统一密码发布已配置，修改程序后可发布给所有用户')
