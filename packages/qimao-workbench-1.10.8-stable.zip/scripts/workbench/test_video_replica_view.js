const fs=require('fs'),vm=require('vm'),assert=require('assert');
const nodes={},listeners={},requests=[];let asset={id:'a'.repeat(32),name:'测试视频',phase:'ready',duration:10,source_url:'/source',edit:{id:'edit',ranges:[[0,10]],duration:10},edited_url:'/edited'};
function el(id){if(nodes[id])return nodes[id];let html='';const node={hidden:false,disabled:false,value:'',options:[],textContent:'',classList:{toggle(){},add(){},remove(){}},attrs:{},setAttribute(k,v){this.attrs[k]=v},getAttribute(k){return this.attrs[k]},addEventListener(){},pause(){},load(){},currentTime:2,click(){this.onclick?.()}};Object.defineProperty(node,'innerHTML',{get(){return html},set(value){html=value;if(id==='replica-job'||id==='replica-shot'){node.options=[...value.matchAll(/<option value="([^"]+)"/g)].map(m=>({value:m[1]}));node.value=node.options[0]?.value||''}}});return nodes[id]=node}
const storage=new Map([['qimao-replica-asset',asset.id]]),context={document:{getElementById:el},window:{addEventListener:(n,f)=>listeners[n]=f},localStorage:{getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v)},activeStatuses:['optimizing'],job:null,currentShot:()=>null,esc:String,dirty:false,token:'token',setTimeout:()=>1,clearTimeout(){},api:(path,body)=>{requests.push({path,body});if(path.startsWith('/api/replica/asset/'))return Promise.resolve(asset);if(path.startsWith('/api/job/'))return new Promise(resolve=>requests.at(-1).resolve=resolve);return Promise.resolve({id:'new'})},openJob:async()=>{},refreshJobs:async()=>{},toast(){}};
vm.createContext(context);vm.runInContext(fs.readFileSync('web/video-replica.js','utf8'),context);
const plain=x=>JSON.parse(JSON.stringify(x)),tick=()=>new Promise(resolve=>setImmediate(resolve));
(async()=>{
 const R=context.window.QimaoReplicaRanges;assert.deepEqual(plain(R.subtract([[0,10]],[3,7])),[[0,3],[7,10]]);assert.deepEqual(plain(R.merge([[0,3],[2,5],[8,9]])),[[0,5],[8,9]]);assert.deepEqual(plain(R.subtract([[0,10]],[0,10])),[]);
 await tick();assert(!el('replica-video-workspace').hidden);assert.equal(el('replica-total').textContent.startsWith('已保留 10.00'),true);
 listeners['qimao:revision-setup']({detail:{rows:[{id:'old',project_name:'旧项目',episode:1}],preferred:'old'}});const old=requests.at(-1);
 listeners['qimao:revision-setup']({detail:{rows:[{id:'new',project_name:'新项目',episode:2}],preferred:'new'}});const next=requests.at(-1);
 next.resolve({id:'new',project_name:'新项目',episode:2,status:'complete',shots:[{no:2,state:'saved',candidate:'新项目原稿',duration:10}]});await tick();assert.equal(el('replica-shot').value,'2');assert.equal(el('replica-prompt-text').textContent,'新项目原稿');assert(!el('replica-start').disabled);
 old.resolve({id:'old',project_name:'旧项目',episode:1,status:'complete',shots:[{no:1,state:'saved',candidate:'旧项目原稿'}]});await tick();assert.equal(el('replica-prompt-text').textContent,'新项目原稿');
 el('replica-in').value='3';el('replica-out').value='7';el('replica-remove').onclick();assert(el('replica-start').disabled);assert.match(el('replica-total').textContent,/6.00/);assert.match(el('replica-total').textContent,/重新生成/);
 const count=requests.length;await el('replica-start').onclick();assert.equal(requests.length,count);assert.match(el('replica-error').textContent,/剪辑预览/);
 el('replica-in').value='9';el('replica-out').value='3';el('replica-keep').onclick();assert.match(el('replica-error').textContent,/起止时间/);assert.match(el('replica-total').textContent,/6.00/);
 el('replica-reset').onclick();assert(!el('replica-start').disabled);context.dirty=true;await el('replica-start').onclick();assert.match(el('replica-error').textContent,/先保存/);context.dirty=false;
 listeners['qimao:revision-setup']({detail:{rows:[],preferred:''}});assert(el('replica-start').disabled);assert(!el('replica-no-source').hidden);assert(!el('replica-render').disabled);
 console.log('视频复刻视图通过：中段删除、多段合并、旧剪辑禁止提交、错误区间、异步项目隔离、未保存稿件和空来源保护。');
})().catch(e=>{console.error(e);process.exitCode=1});
