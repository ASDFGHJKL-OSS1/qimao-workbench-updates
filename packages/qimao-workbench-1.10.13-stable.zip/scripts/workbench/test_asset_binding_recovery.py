"""原生资产括号/集数不应变成时码；修复仍须保护真实数字与绑定。"""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import server as app


class AssetBindingRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.hero='@江尘(9-24) · 默认 · 四视图'
        self.other='@叶安带兜帽（9-14，18—21） · 默认 · 四视图'
        self.scene='@深渊秘境核心区（特效） · 默认 · 正视图'
        self.body=f'人物空间连续性：{self.hero}、{self.other}，共2人。\nc01，3秒，近景。{self.hero}右手抬起，{self.other}仍在右侧。{self.scene}，只有风声。\n'
        self.source='核心风格：写实。\n'+self.body+'【画风】原画风。'

    def test_parenthesized_native_names_are_complete_and_repeatable(self):
        self.assertEqual(app.asset_labels(self.body),{self.hero,self.other,self.scene})
        self.assertEqual(app.mentions(self.body),{'@江尘(9-24)','@叶安带兜帽（9-14，18—21）','@深渊秘境核心区（特效）'})
        changed=self.source.replace('只有风声',f'{self.hero}呼吸平稳，只有风声')
        self.assertTrue(app.validate({'original':self.source},changed,imported=True)['ok'])
        self.assertEqual(app.content_numbers(self.body),['2','01','3'])

    def test_real_duration_counts_asset_state_and_view_stay_locked(self):
        for before,after in [('3秒','4秒'),('共2人','共3人'),('9-24','9-25'),('默认','受伤'),('正视图','侧面')]:
            with self.subTest(change=after):
                self.assertFalse(app.validate({'original':self.source},self.source.replace(before,after),imported=True)['ok'])
        changed=self.source.replace('只有风声','右手抬起2次，只有风声')
        self.assertFalse(app.validate({'original':self.source},changed,imported=True)['ok'])

    def test_unknown_at_alias_is_not_silently_accepted(self):
        changed=self.source.replace('只有风声','@江尘抬手，只有风声')
        self.assertIn('资产标记集合发生变化',app.validate({'original':self.source},changed,imported=True)['errors'])
        feedback=app.structural_feedback(self.body,app.split_style(changed)[1])
        self.assertIn('@江尘抬手',json.dumps(feedback,ensure_ascii=False))

    def test_model_asset_error_has_targeted_feedback_then_fresh_audit(self):
        with tempfile.TemporaryDirectory() as folder,patch.object(app,'DATA',Path(folder)),patch.object(app,'DELAYS',(0,0)):
            shot={'no':1,'duration':3,'original':self.source}
            job={'id':'isolated','episode':1,'shots':[shot]}
            pre,body,post=app.split_style(self.source);calls=[]
            def model(prompt,jid,schema):
                calls.append(prompt)
                if schema==app.CONTENT_SCHEMA:
                    return {'complete':True,'issues':[],'checks':[{'line':n+1,'complete':True,'issues':[]} for n,line in enumerate(body.splitlines()) if line.strip()]}
                changed=body.replace('只有风声',('错误的@江尘抬手' if len(calls)==1 else self.hero+'呼吸平稳')+'，仅闻风声')
                return {'lines':[{'line':n+1,'text':line} for n,line in enumerate(changed.splitlines()) if line.strip()],'review':'在原镜头内明确呼吸与声音。'}
            with patch.object(app,'model_json',model):
                candidate,_=app.optimize_body(job,shot,'',pre,body,post,body.splitlines(keepends=True),{})
            self.assertEqual(len(calls),3)
            self.assertIn('新增或错误',calls[1]);self.assertIn('@江尘抬手',calls[1])
            self.assertTrue(app.validate(shot,candidate)['ok'])


if __name__=='__main__':unittest.main()
