"""批量回填授权、内容锁定、顺序、冲突及重启恢复；不访问真实平台。"""
import copy,json,tempfile,threading,time,unittest,urllib.request,urllib.error
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
import server as app
from test_workbench import fixture,ContractTests

class BatchSaveTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.old=app.DATA;app.DATA=Path(self.temp.name)/'jobs';app.DATA.mkdir()
        self.rows=[]
        for ep in (14,15,16):
            j=fixture();j.update(id='save-'+str(ep),episode=ep,batch_id='batch-save-test',status='review',read_complete=True,created='2026-10-30');app.store(j);self.rows.append(j)
        self.payload={'id':'batch-save-test','job_ids':[j['id'] for j in reversed(self.rows)]}
        self.delay=patch.object(app,'DELAYS',(0,0));self.delay.start()
    def tearDown(self):
        self.assertFalse(app.BUSY.locked());app.CANCEL.clear();self.delay.stop();app.DATA=self.old;self.temp.cleanup()
    def wait(self):
        deadline=time.monotonic()+5
        while app.BUSY.locked() and time.monotonic()<deadline:time.sleep(.005)
        self.assertFalse(app.BUSY.locked())
    def confirmation(self):
        review=app.prepare_batch_save(self.payload)
        return {'id':review['id'],'ticket':review['ticket'],'reviewed':True}
    def test_prepare_only_creates_review_no_writes_and_sorts_episodes(self):
        with patch.object(app,'background_batch_save') as start:
            review=app.prepare_batch_save(self.payload)
        start.assert_not_called();self.assertEqual([j['episode'] for j in review['jobs']],[14,15,16])
        self.assertTrue(all(app.load(j['id'])['status']=='review' for j in self.rows))
    def test_confirmation_required_expiry_replay_and_batch_binding(self):
        confirm=self.confirmation()
        with self.assertRaises(app.Problem):app.confirm_batch_save({**confirm,'reviewed':False})
        with self.assertRaises(app.Problem):app.confirm_batch_save({**confirm,'id':'batch-other'})
        p=app.DATA/'_batch_reviews'/(confirm['ticket']+'.json');d=json.loads(p.read_text());d['expires']=0;app.atomic(p,d)
        with self.assertRaises(app.Problem):app.confirm_batch_save(confirm)
        confirm=self.confirmation()
        with patch.object(app,'background_batch_save') as start:app.confirm_batch_save(confirm)
        self.assertEqual([j['episode'] for j in start.call_args.args[0]],[14,15,16])
        with self.assertRaises(app.Problem):app.confirm_batch_save(confirm)
    def test_changed_candidate_after_review_requires_new_confirmation(self):
        confirm=self.confirmation();j=app.load('save-15');j['shots'][0]['candidate']=j['shots'][0]['candidate'].replace('视线保持','视线仍然保持');app.store(j)
        with patch.object(app,'background_batch_save') as start,self.assertRaisesRegex(app.Problem,'稿件已改变'):app.confirm_batch_save(confirm)
        start.assert_not_called()
    def test_missing_invalid_completed_or_foreign_jobs_rejected(self):
        for ids in [[],['save-14','save-14'],['foreign'],[14]]:
            with self.subTest(ids=ids),self.assertRaises(app.Problem):app.prepare_batch_save({**self.payload,'job_ids':ids})
        for change in ['complete','failed','invalid']:
            j=app.load('save-14')
            if change=='complete':j['status']='complete'
            elif change=='failed':j['status']='review';j['shots'][0]['state']='failed'
            else:j['shots'][0]['state']='draft';j['shots'][0]['candidate']='坏稿'
            app.store(j)
            with self.subTest(change=change),self.assertRaises(app.Problem):app.prepare_batch_save(self.payload)
    def test_all_prechecks_run_before_first_write_and_writes_are_serial(self):
        calls=[]
        def check(j):calls.append(('check',j['episode']))
        def save(j):calls.append(('save',j['episode']));j['status']='complete'
        with patch.object(app,'check_save_platform',side_effect=check),patch.object(app,'save_episode',side_effect=save, __name__='save_episode'):
            app.background_batch_save(list(reversed(self.rows)));self.wait()
        self.assertEqual(calls,[('check',14),('check',15),('check',16),('save',14),('save',15),('save',16)])
        self.assertTrue(all(app.load(j['id'])['recovery']['save_authorized'] for j in self.rows))
    def test_precheck_conflict_prevents_every_write_and_pauses_other_jobs(self):
        def check(j):
            if j['episode']==15:raise app.Problem('第15集版本、内容或配置已改变')
        with patch.object(app,'check_save_platform',side_effect=check),patch.object(app,'save_episode', __name__='save_episode') as save:
            app.background_batch_save(self.rows);self.wait();save.assert_not_called()
        self.assertEqual([app.load(j['id'])['status'] for j in self.rows],['stopped','error','stopped'])
    def test_write_failure_preserves_finished_and_stops_later_episodes(self):
        calls=[]
        def save(j):
            calls.append(j['episode'])
            if j['episode']==15:raise app.Problem('版本或配置已变化')
            j['status']='complete'
        with patch.object(app,'check_save_platform'),patch.object(app,'save_episode',side_effect=save, __name__='save_episode'):
            app.background_batch_save(self.rows);self.wait()
        self.assertEqual(calls,[14,15]);self.assertEqual([app.load(j['id'])['status'] for j in self.rows],['complete','error','stopped'])
    def test_cancellation_in_first_episode_stops_later_writes(self):
        calls=[]
        def save(j):
            calls.append(j['episode'])
            for row in self.rows:app.cancel_job(app.load(row['id']))
            raise app.Problem('回填已停止')
        with patch.object(app,'check_save_platform'),patch.object(app,'save_episode',side_effect=save, __name__='save_episode'):
            app.background_batch_save(self.rows);self.wait()
        self.assertEqual(calls,[14]);self.assertTrue(all(app.load(j['id'])['status']=='stopped' for j in self.rows))
        self.assertTrue(all(app.load(j['id'])['recovery']['user_stopped'] for j in self.rows))
    def test_platform_precheck_catches_late_shot_conflict_and_uncertain_write(self):
        j=fixture();s=j['shots'][0];current=copy.deepcopy(s['snapshot']);current['edit_revision']='new'
        with patch.object(app,'preflight'),patch.object(app,'runcli',return_value={'shot':current}),self.assertRaises(app.Problem):app.check_save_platform(j)
        s['write_attempted']=True;current['prompt_text']=s['candidate']
        with patch.object(app,'preflight'),patch.object(app,'runcli',return_value={'shot':current}):app.check_save_platform(j)
    def test_uncertain_write_uses_existing_verification_without_duplicate(self):
        j=self.rows[0];contract=ContractTests();cli,writes=contract.platform(j,uncertain=True)
        with patch.object(app,'check_save_platform'),patch.object(app,'runcli',side_effect=cli),patch.object(app,'preflight'):
            app.background_batch_save([j]);self.wait()
        self.assertEqual(app.load(j['id'])['status'],'complete');self.assertEqual(len(writes),1)
    def test_restart_groups_only_authorized_unfinished_save_jobs(self):
        for j in self.rows:
            j.update(status='queued',batch_save_run='same-run',recovery={'enabled':True,'action':'save_episode','save_authorized':j['episode']!=16,'user_stopped':False});app.store(j)
        dispatched=[]
        def launch(rows,resume=False):
            dispatched.append(([j['episode'] for j in rows],resume))
            for j in rows:j['status']='complete';app.store(j)
        with patch.object(app,'background_batch_save',side_effect=launch):app.recover_interrupted_jobs()
        self.assertEqual(len(dispatched),1);self.assertEqual(set(dispatched[0][0]),{14,15});self.assertTrue(dispatched[0][1])
    def test_optimization_retry_cannot_convert_failed_save_to_optimization(self):
        j=self.rows[0];j.update(status='error',recovery={'action':'save_episode'});app.store(j)
        with self.assertRaisesRegex(app.Problem,'无需重新优化'),patch.object(app,'background_batch') as start:app.continue_batch('batch-save-test')
        start.assert_not_called()
    def test_http_prepare_confirm_requires_review_and_returns_selected_episodes(self):
        http=ThreadingHTTPServer(('127.0.0.1',0),app.Handler);t=threading.Thread(target=http.serve_forever,daemon=True);t.start()
        def request(path,body):
            req=urllib.request.Request('http://127.0.0.1:'+str(http.server_port)+path,data=json.dumps(body).encode(),headers={'Content-Type':'application/json','X-Workbench-Token':app.TOKEN})
            with urllib.request.urlopen(req,timeout=3) as r:return json.load(r)
        try:
            with patch.object(app,'PORT',http.server_port),patch.object(app,'background_batch_save') as start:
                review=request('/api/batch/save/prepare',self.payload);start.assert_not_called()
                confirm={'id':review['id'],'ticket':review['ticket']}
                with self.assertRaises(urllib.error.HTTPError):request('/api/batch/save/confirm',confirm)
                result=request('/api/batch/save/confirm',{**confirm,'reviewed':True})
                self.assertEqual(result['episodes'],[14,15,16]);self.assertEqual(start.call_count,1)
        finally:http.shutdown();http.server_close();t.join()

if __name__=='__main__':unittest.main()
