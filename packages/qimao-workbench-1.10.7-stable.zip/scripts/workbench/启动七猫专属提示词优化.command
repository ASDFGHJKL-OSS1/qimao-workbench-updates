#!/bin/zsh
qimao_label="com.local.qimao-prompt-workbench"
qimao_service="gui/$(/usr/bin/id -u)/$qimao_label"
qimao_plist="$HOME/Library/LaunchAgents/$qimao_label.plist"
if ! /usr/bin/curl -fsS http://127.0.0.1:4197/api/health >/dev/null 2>&1; then
  if ! /bin/launchctl print "$qimao_service" >/dev/null 2>&1; then
    /bin/launchctl bootstrap "gui/$(/usr/bin/id -u)" "$qimao_plist" || exit 1
  fi
  /bin/launchctl kickstart "$qimao_service" >/dev/null 2>&1
  for qimao_attempt in {1..40}; do
    /usr/bin/curl -fsS http://127.0.0.1:4197/api/health >/dev/null 2>&1 && break
    /bin/sleep 0.2
  done
fi
if /usr/bin/curl -fsS http://127.0.0.1:4197/api/health >/dev/null 2>&1; then
  /usr/bin/open 'http://127.0.0.1:4197'
else
  print '工作台启动失败，请查看 data/server.log。'
  exit 1
fi
