// 输入草稿不被轮询或切换片段覆盖；跨任务隔离、开始后沿用保存要求，05独立。
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const els={},events={},store=new Map();
function el(id){return els[id]||(els[id]={value:'',disabled:false,hidden:false,innerHTML:'开始整集优化',addEventListener(n,cb){this[n]=cb},click(){this.clicked=true}})}
const ctx={job:{id:'a',status:'ready',shots:[]},activeStatuses:['queued','reading','optimizing','saving'],
    $:el,isRevision(){return ctx.job?.kind==='revision'},document:{activeElement:null},
    localStorage:{getItem:k=>store.get(k),setItem:(k,v)=>store.set(k,v)},window:{addEventListener:(n,cb)=>events[n]=cb}};
vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/optimization-brief.js','utf8'),ctx);
const ideas=el('#optimization-brief'),sync=events['qimao:context'];
ideas.value='片段03调整视线';ideas.input();sync();assert.equal(ideas.value,'片段03调整视线');
ctx.job={id:'b',status:'ready',shots:[]};sync();assert.equal(ideas.value,'');
ideas.value='本集加强情绪';ideas.input();ctx.job={id:'a',status:'ready',shots:[]};sync();assert.equal(ideas.value,'片段03调整视线');
assert.equal(ctx.window.optimizationBriefPayload().optimization_brief,'片段03调整视线');
ctx.job={...ctx.job,status:'optimizing',optimization_run_id:'run',optimization_brief:'已提交要求'};sync();assert.equal(ideas.value,'已提交要求');assert(ideas.readOnly);
assert.equal(ctx.window.optimizationBriefPayload().optimization_brief,'已提交要求');
ctx.job={id:'child',kind:'revision'};sync();assert(el('#optimization-brief-panel').hidden);assert.equal(Object.keys(ctx.window.optimizationBriefPayload()).length,0);
ctx.job={id:'b',status:'ready',shots:[]};sync();assert.equal(ideas.value,'本集加强情绪');
el('#optimization-brief-start').click();assert(el('#optimize-button').clicked);
console.log('整集优化想法：草稿跨轮询保留、任务隔离、启动要求锁定与05独立通过。');
