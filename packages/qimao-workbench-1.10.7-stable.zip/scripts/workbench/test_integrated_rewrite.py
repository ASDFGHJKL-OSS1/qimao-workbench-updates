# -*- coding: utf-8 -*-
"""整合成稿的业务回归：不能用说明充当优化，核对失败不采纳，行内对白也锁定。"""
import copy,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import server as app
from test_workbench import fixture
from test_prompt_helpers import reply

class IntegratedRewriteTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.old=app.DATA;app.DATA=Path(self.temp.name)
        self.delay_patch=patch.object(app,'DELAYS',(0,0));self.delay_patch.start()
        self.job=fixture();self.job.update(read_complete=True);self.job['shots'][0].update(state='pending',candidate='')
    def tearDown(self):self.delay_patch.stop();app.DATA=self.old;self.temp.cleanup()
    def run_model(self,change=None):
        calls=[]
        def model(prompt,jid,schema=None):
            calls.append(schema);r=reply(prompt,schema)
            return change(r,schema) if change else r
        with patch.object(app.subprocess,'run',return_value=SimpleNamespace(returncode=0)),patch.object(app,'model_json',model):app.optimize(self.job)
        return calls
    def test_rewrites_body_and_independently_checks_then_saves(self):
        self.assertEqual(self.run_model(),[app.SCHEMA,app.CONTENT_SCHEMA]);s=self.job['shots'][0]
        self.assertEqual(s['state'],'draft');self.assertTrue(app.validate(s,s['candidate'])['ok'])
        self.assertFalse(app.subseq(s['original'],s['candidate']));self.assertNotIn('导演说明',s['candidate'])
        self.assertEqual(s['content_check']['optimizer'],app.OPTIMIZER_VERSION)
        self.assertEqual(app.load(self.job['id'])['shots'][0]['candidate'],s['candidate'])
    def test_original_plus_commentary_rejected_before_review(self):
        def change(r,schema):
            if schema==app.SCHEMA:r['lines'][1]['text']+='导演说明：保持原镜头。'
            return r
        self.assertEqual(self.run_model(change),[app.SCHEMA,app.SCHEMA,app.SCHEMA]);self.assertEqual(self.job['shots'][0]['state'],'failed');self.assertFalse(self.job['shots'][0]['candidate'])

    def test_repair_uses_rejection_and_requires_a_fresh_independent_audit(self):
        calls=[];audits=0
        def model(prompt,jid,schema=None):
            nonlocal audits
            calls.append((prompt,schema));r=reply(prompt,schema)
            if schema==app.CONTENT_SCHEMA:
                audits+=1
                if audits==1:r.update(complete=False,issues=['原定侧方冷硬轮廓被更改'])
            return r
        with patch.object(app.subprocess,'run',return_value=SimpleNamespace(returncode=0)),patch.object(app,'model_json',model):app.optimize(self.job)
        self.assertEqual([s for _,s in calls],[app.SCHEMA,app.CONTENT_SCHEMA,app.SCHEMA,app.CONTENT_SCHEMA])
        self.assertIn('原定侧方冷硬轮廓被更改',calls[2][0]);self.assertIn('rejected_body',calls[2][0])
        self.assertEqual(self.job['shots'][0]['state'],'draft')
        attempts=[__import__('json').loads(p.read_text()) for p in app.jobpath(self.job['id']).glob('attempts/*.json')]
        self.assertEqual(len(attempts),2);self.assertEqual(sum(a['audit']['complete'] for a in attempts),1)

    def test_scene_change_cannot_relabel_asset_view(self):
        original='人物空间连续性：@西院偏屋·夜态 · 夜晚状态 · 正面偏屋门外廊下。\nc01，3秒，侧方光切出冷硬轮廓。\n【画风】写实'
        good=original.replace('正面偏屋门外廊下','正面所示的偏屋室内')
        bad=good.replace('· 正面','· 屋内正面')
        self.assertTrue(app.validate({'original':original},good,imported=True)['ok'])
        self.assertIn('完整资产名称发生变化',app.validate({'original':original},bad,imported=True)['errors'])

    def test_object_audit_issues_preserve_feedback_and_retry_with_fresh_audit(self):
        calls=[];audits=0
        def model(prompt,jid,schema=None):
            nonlocal audits
            calls.append((prompt,schema));r=reply(prompt,schema)
            if schema==app.CONTENT_SCHEMA:
                audits+=1
                if audits==1:r.update(complete=False,issues=[{'line':1,'issue':'对侧人物肩背不得进入单人反打'}])
            return r
        with patch.object(app.subprocess,'run',return_value=SimpleNamespace(returncode=0)),patch.object(app,'model_json',model):app.optimize(self.job)
        self.assertEqual([s for _,s in calls],[app.SCHEMA,app.CONTENT_SCHEMA,app.SCHEMA,app.CONTENT_SCHEMA])
        self.assertIn('对侧人物肩背不得进入单人反打',calls[2][0])
        self.assertIn('rejected_body',calls[2][0])
        self.assertEqual(self.job['shots'][0]['state'],'draft')
        self.assertTrue(app.validate(self.job['shots'][0],self.job['shots'][0]['candidate'])['ok'])

    def test_malformed_audit_never_adopted_or_exceeds_three_attempts(self):
        def objects(r):r['checks'][0]['issues']=[{'issue':'遗漏动作'}]
        def null_issues(r):r['issues']=None
        def missing(r):r.pop('issues')
        def boolean(r):r['checks'][0]['complete']='true'
        for mutate in (objects,null_issues,missing,boolean):
            with self.subTest(mutate=mutate.__name__):
                self.job['shots'][0].update(state='pending',candidate='')
                def change(r,schema):
                    if schema==app.CONTENT_SCHEMA:mutate(r)
                    return r
                calls=self.run_model(change)
                self.assertEqual(calls.count(app.CONTENT_SCHEMA),3)
                s=self.job['shots'][0]
                self.assertEqual(s['state'],'failed');self.assertFalse(s['candidate'])
                self.assertIn('模型响应格式不合规',s['error'])
                self.assertNotIn('expected str instance',s['error'])

    def test_continue_reuses_only_rejected_draft_with_same_source_and_brief(self):
        s=self.job['shots'][0]
        folder=app.jobpath(self.job['id'])/'attempts'
        app.atomic(folder/'shot-1-same.json',{'source_sha256':app.digest(s['original']),'candidate':s['original'].replace('她缓缓转头','她沿原方向缓缓转头'),'optimization_brief':''})
        app.atomic(folder/'shot-1-other.json',{'source_sha256':'other','candidate':'不得使用的旧稿','optimization_brief':''})
        s['error']='视线问题需修复';calls=[]
        def model(prompt,jid,schema=None):calls.append(prompt);return reply(prompt,schema)
        with patch.object(app.subprocess,'run',return_value=SimpleNamespace(returncode=0)),patch.object(app,'model_json',model):app.optimize(self.job)
        self.assertIn('rejected_body',calls[0]);self.assertNotIn('不得使用的旧稿',calls[0])
        self.assertEqual(s['state'],'draft')
    def test_plain_append_without_heading_is_rejected(self):
        def model(prompt,jid,schema=None):
            from test_prompt_helpers import rows_from
            return {'lines':[dict(r,text=r['text']+'镜头保持稳定。') for r in rows_from(prompt)],'review':'增补'}
        with patch.object(app.subprocess,'run',return_value=SimpleNamespace(returncode=0)),patch.object(app,'model_json',model):app.optimize(self.job)
        self.assertEqual(self.job['shots'][0]['state'],'failed');self.assertFalse(self.job['shots'][0]['candidate'])
    def test_semantic_loss_or_incomplete_audit_never_adopted(self):
        for missing in (False,True):
            self.job['shots'][0].update(state='pending',candidate='')
            def change(r,schema):
                if schema==app.CONTENT_SCHEMA:
                    if missing:r['checks'].pop()
                    else:r.update(complete=False,issues=['左手持杯信息遗漏'])
                return r
            self.run_model(change);self.assertEqual(self.job['shots'][0]['state'],'failed');self.assertFalse(self.job['shots'][0]['candidate'])
    def test_missing_reordered_or_empty_source_rows_never_adopted(self):
        for kind in ('missing','reordered','empty'):
            self.job['shots'][0].update(state='pending',candidate='')
            def change(r,schema):
                if schema==app.SCHEMA:
                    if kind=='missing':r['lines'].pop()
                    elif kind=='reordered':r['lines'].reverse()
                    else:r['lines'][0]['text']=''
                return r
            self.run_model(change);self.assertEqual(self.job['shots'][0]['state'],'failed')
    def test_inline_dialogue_word_punctuation_and_speaker_are_locked(self):
        s=self.job['shots'][0];s['original']=s['original'].replace('\n台词',' 台词');s['candidate']=s['original']
        self.assertTrue(app.validate(s,s['candidate'])['ok'])
        for old,new in [('一个字不改。','一个字不改！'),('甲','乙')]:
            self.assertFalse(app.validate(s,s['candidate'].replace(old,new))['dialogue_locked'])
    def test_notes_cannot_be_manually_saved_even_when_original_preserved(self):
        s=self.job['shots'][0];s['candidate']=s['original'].replace('【画风】','导演说明：保持原样。\n【画风】')
        self.assertFalse(app.validate(s,s['candidate'])['ok'])
        with patch.object(app,'runcli') as cli:
            with self.assertRaises(app.Problem):app.save_episode(self.job)
            cli.assert_not_called()
    def test_mixed_quotes_and_inline_chinese_single_quotes_are_all_locked(self):
        s=self.job['shots'][0]
        s['original']=s['original'].replace('【画风】',"镜头承接。台词（@甲，低声）：‘别动！’\n台词（@甲）：无引号也保留。\n【画风】")
        self.assertEqual(len(app.dialogue(s['original'])),3)
        for old,new in [('别动！','别动。'),('无引号也保留。','无引号被改了。')]:
            result=app.validate(s,s['original'].replace(old,new))
            self.assertFalse(result['dialogue_locked'])
    def test_numeric_character_name_alias_is_not_a_new_duration(self):
        original='人物空间连续性：@王府丫鬟2 · 常态 · 四视图留在门口。\nc01，2秒，近景。她轻轻转头。\n【画风】写实'
        s={'original':original}
        candidate=original.replace('她轻轻转头','丫鬟2轻轻转头')
        # 完整名称的简称同样带数字，不能误报；新数字与真实时长改动仍须拦截。
        self.assertTrue(app.validate(s,candidate,imported=True)['ok'])
        candidate=original.replace('她轻轻转头','王府丫鬟2轻轻转头')
        self.assertTrue(app.validate(s,candidate,imported=True)['ok'])
        self.assertFalse(app.validate(s,candidate.replace('2秒','3秒'),imported=True)['ok'])
        self.assertFalse(app.validate(s,candidate.replace('王府丫鬟2轻','王府丫鬟20轻'),imported=True)['ok'])
        self.assertEqual(app.content_numbers('@王府丫鬟2 @邻府丫鬟2 丫鬟2，2秒'),['2','2'])

if __name__=='__main__':unittest.main()
