// 实际视图函数：局部任务读到一半也不能显示其他片段，片段号与原数组索引不混用。
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const code=fs.readFileSync('web/app.js','utf8');
const names=['isRevision','visibleShotRows','currentShot'];
const funcs=names.map(n=>code.match(new RegExp('function '+n+'\\([^\\n]+'))[0]).join('\n');
const state={job:{kind:'revision',target_nos:[2],shots:[{no:1},{no:2},{no:3}]},selected:1};vm.createContext(state);vm.runInContext(funcs,state);
assert.deepEqual(Array.from(state.visibleShotRows(),r=>[r.s.no,r.i]),[[2,1]]);assert.equal(state.currentShot().no,2);
state.selected=0;assert.equal(state.currentShot(),undefined);
state.job.shots=[{no:1}];assert.equal(state.visibleShotRows().length,0);assert.equal(state.currentShot(),undefined);
state.job={shots:[{no:1},{no:2},{no:3}]};assert.equal(state.visibleShotRows().length,3);assert.equal(state.currentShot().no,1);
console.log('05视图验证通过：只显示目标片段，读取途中不显示其他片段，整集视图保留。');
