"""关键业务校验与写回隔离测试，不触及线上数据。"""
import copy, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import server as app
TEXT='核心风格：横屏，写实CG。\n人物空间连续性：两人保持原位。\nc01，5秒，侧面近景，缓慢推近。\n台词（甲）：\'原句，一个字不改。\'\n\n【画风】\n原画风锁定。'
def fixture():
    s={'id':'11','shot_no':1,'duration_seconds':5,'model_id':'test','resolution':'480p','art_style_id':'9','edit_revision':'v1','references':[],'reference_files':[],'prompt_text':TEXT}
    new=TEXT.replace('c01，5秒，侧面近景，缓慢推近。\n','c01，5秒，侧面近景，缓慢推近。\n视线保持在既定对话对象上，原台词句尾轻收。\n')
    return {'id':'test','project_id':1,'episode':1,'context':{'script':'locked'},'order':[('11',1)],'shots':[{'id':'11','no':1,'duration':5,'original':TEXT,'candidate':new,'state':'draft','snapshot':s}],'events':[]}
class ContractTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.orig=app.DATA;app.DATA=Path(self.temp.name)
    def tearDown(self):app.DATA=self.orig;self.temp.cleanup()
    def test_preserves_all_characters(self):
        s=fixture()['shots'][0];self.assertTrue(app.validate(s,s['candidate'])['ok'])
        self.assertFalse(app.validate(s,s['candidate'].replace('两人保持原位','两人不动'))['ok'])
    def test_style_exact(self):
        s=fixture()['shots'][0];self.assertFalse(app.validate(s,s['candidate'].replace('原画风锁定','新画风'))['ok'])
    def test_dialogue_exact(self):
        s=fixture()['shots'][0];self.assertFalse(app.validate(s,s['candidate'].replace('一个字不改。','一个字不改！'))['dialogue_locked'])
    def test_long_candidate_is_valid(self):
        s=fixture()['shots'][0];a,b,c=app.split_style(TEXT);exact=a+b+'字'*(7000-len(TEXT))+c
        self.assertTrue(app.validate(s,exact)['ok']);self.assertTrue(app.validate(s,exact.replace(c,'字'+c))['ok'])
    def test_binding_locked(self):
        s=fixture()['shots'][0];self.assertFalse(app.validate(s,s['candidate'].replace('【画风】','@新角色\n【画风】'))['ok'])
    def test_unknown_boundaries(self):
        with self.assertRaises(app.Problem):app.split_style('没有分区')
    def platform(self,j,conflict=False,uncertain=False):
        current=copy.deepcopy(j['shots'][0]['snapshot']);writes=[]
        if conflict:current['edit_revision']='v2'
        def cli(args):
            if args[:2]==['shot','get']:return {'shot':copy.deepcopy(current)}
            if args[:3]==['shot','model','list']:return {'items':[]}
            if args[:3]==['shot','prompt','update']:
                self.assertEqual(args[args.index('--revision')+1],'v1')
                self.assertNotIn('--model-id',args);self.assertNotIn('--duration-seconds',args)
                writes.append(args);current['prompt_text']=Path(args[args.index('--file')+1]).read_text();current['description']=current['prompt_text'];current['edit_revision']='v3'
                if uncertain:raise app.Problem('网络响应丢失')
                return {'shot':copy.deepcopy(current)}
            raise AssertionError(args)
        return cli,writes
    def test_save_roundtrip(self):
        j=fixture();cli,writes=self.platform(j)
        with patch.object(app,'runcli',cli),patch.object(app,'preflight',lambda j:None):app.save_episode(j)
        self.assertEqual(j['status'],'complete');self.assertEqual(len(writes),1)
    def test_revision_conflict_no_write(self):
        j=fixture();cli,writes=self.platform(j,conflict=True)
        with patch.object(app,'runcli',cli),patch.object(app,'preflight',lambda j:None):
            with self.assertRaises(app.Problem):app.save_episode(j)
        self.assertEqual(writes,[])
    def test_recover_uncertain_write(self):
        j=fixture();cli,writes=self.platform(j,uncertain=True)
        with patch.object(app,'runcli',cli),patch.object(app,'preflight',lambda j:None):
            with self.assertRaises(app.Problem):app.save_episode(j)
            app.save_episode(j)
        self.assertEqual(len(writes),1);self.assertEqual(j['status'],'complete')
    def test_long_candidate_saves_complete_text(self):
        j=fixture();s=j['shots'][0];a,b,c=app.split_style(s['candidate']);s['candidate']=a+b+'字'*7000+c
        cli,writes=self.platform(j)
        with patch.object(app,'runcli',cli),patch.object(app,'preflight',lambda j:None):app.save_episode(j)
        self.assertEqual(len(writes),1);self.assertEqual(j['status'],'complete')
        self.assertEqual(Path(writes[0][writes[0].index('--file')+1]).read_text(),s['candidate'])
    def test_context_conflict_no_write(self):
        j=fixture()
        with patch.object(app,'capture_context',return_value={'script':'changed'}),patch.object(app,'runcli') as cli:
            with self.assertRaises(app.Problem):app.save_episode(j)
            cli.assert_not_called()
    def test_pagination(self):
        with patch.object(app,'runcli',side_effect=[{'items':[1],'has_more':True},{'items':[2],'has_more':False}]):self.assertEqual(app.paged(['test']),[1,2])
if __name__=='__main__':unittest.main(verbosity=2)
