// 拖动位置、边缘和弹窗适配测试；无浏览器或第三方依赖。
const assert=require('node:assert/strict');
const {dockPoint,popoverRect}=require('./web/assistant-layout.js');
for(const view of [{width:1440,height:900},{width:334,height:593},{width:760,height:500}]){
 const size={width:66,height:84};
 for(const point of [{x:-400,y:-500},{x:9999,y:9999},{x:120,y:160}]){
  const p=dockPoint(point,view,size);assert.ok(p.x>=8&&p.y>=8);assert.ok(p.x+size.width<=view.width-8);assert.ok(p.y+size.height<=view.height-8);
  const panel=popoverRect({...p,...size},view,{width:430,height:690});assert.ok(panel.x>=12&&panel.y>=12);assert.ok(panel.x+panel.width<=view.width-12);assert.ok(panel.y+panel.height<=view.height-12);
 }
}
console.log('拖动与浮层布局：3种窗口尺寸、9组位置均在可见范围。');
