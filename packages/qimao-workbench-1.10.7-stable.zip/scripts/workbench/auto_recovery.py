"""任务内自动恢复策略。只有可恢复错误重试，重试仍执行原业务校验。"""
import json
import subprocess
import re

MAX_ATTEMPTS=3
DELAYS=(3,10)

def retryable(error):
    message=str(error)
    lower=message.casefold()
    # 用户意图、权限、外部改稿和内容缺失不能靠重试覆盖。
    if any(s.casefold() in lower for s in ('已停止','已取消','登录失效','未登录','无权限','权限不足','认证失败','API key','unauthorized','forbidden','版本或配置已变化','版本、内容或配置已改变','已改变；','顺序或数量已改变','最终核验不一致','写后核验失败','没有可识别的镜头正文','原稿为空','缺失','依赖检查失败','必需的AI4399','历史记录','安全基础')):return False
    # HTTP状态须为独立编码，不能把片段/资产ID内的401、403误当权限错误。
    if re.search(r'(?<!\d)(?:401|403)(?!\d)',message):return False
    if any(s in lower for s in ('service unavailable','service_unavailable','bad gateway','bad_gateway','gateway timeout','gateway_timeout','too many requests','too_many_requests','temporarily unavailable','internal server error','connection reset','connection refused','connection aborted','timed out','timeout','服务暂时不可用','服务不可用','请求过于频繁','服务繁忙','请求限流')):return True
    if re.search(r'(?<!\d)(?:408|429|500|502|503|504)(?!\d)',message):return True
    return isinstance(error,(TimeoutError,ConnectionError,OSError,json.JSONDecodeError,subprocess.TimeoutExpired)) or any(s in message for s in ('超时','网络','连接','未成功返回','没有返回有效数据','客户端不可用','模型未完整','模型正文格式','独立内容核对未覆盖','没有实质改写','只保留原文','优化稿','正文','台词','资产','画风','风格','数字','模型响应','行号'))

def recoverable_stage(j):
    recovery=j.get('recovery',{})
    if not recovery.get('enabled') or recovery.get('user_stopped') or j.get('historical'):return None
    if j.get('status') not in ('queued','reading','optimizing','saving','recovering'):return None
    stage=recovery.get('action')
    if stage=='revise_episode' and j.get('revision_prepared'):stage='optimize'
    if stage=='save_episode' and not recovery.get('save_authorized'):return None
    return stage if stage in ('read_episode','optimize','revise_episode','save_episode','batch_episode') else None
