(()=>{
'use strict';
const panel=$('#optimization-brief-panel'),ideas=$('#optimization-brief'),start=$('#optimization-brief-start');
let currentId=null;
function key(){return 'qimao-optimization-brief:'+job.id}
function locked(){return !!(job?.historical||job?.batch_id||job?.optimization_run_id||job?.shots?.some(s=>s.candidate||s.skill_run)||job?.status==='complete')}
function sync(){
    panel.hidden=!job||isRevision();
    if(panel.hidden){currentId=null;return}
    const fixed=locked(),busy=activeStatuses.includes(job.status);
    if(currentId!==job.id){
        currentId=job.id;
        let draft='';try{draft=localStorage.getItem(key())||''}catch(_){}
        ideas.value=fixed?(job.optimization_brief||''):(draft||job.optimization_brief||'');
    }else if(fixed&&document.activeElement!==ideas){ideas.value=job.optimization_brief||''}
    ideas.readOnly=fixed;ideas.disabled=busy&&!fixed;
    $('#optimization-brief-count').textContent=[...ideas.value].length+' / 5000';
    $('#optimization-brief-state').textContent=fixed?(job.historical?'历史记录只读。重新读取后可填写本次优化想法。':'本轮优化想法已保存；继续 / 重试沿用此要求。新增想法可重新读取，或回填后使用05。'):'想法草稿在当前浏览器自动保留，开始后随任务保存，并用于优化与核对。';
    start.disabled=$('#optimize-button').disabled;
    start.innerHTML=$('#optimize-button').innerHTML;
}
ideas.addEventListener('input',()=>{if(job&&!locked())try{localStorage.setItem(key(),ideas.value)}catch(_){}sync()});
start.addEventListener('click',()=>$('#optimize-button').click());
window.optimizationBriefPayload=()=>!job||isRevision()?{}:{optimization_brief:locked()?(job.optimization_brief||''):ideas.value};
window.addEventListener('qimao:context',sync);
sync();
})();
