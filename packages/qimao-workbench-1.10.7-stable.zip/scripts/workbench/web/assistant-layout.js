(function(root){
'use strict';
const clamp=(n,min,max)=>Math.min(Math.max(n,min),Math.max(min,max));
function dockPoint(point,view,size){return{x:clamp(point.x,8,view.width-size.width-8),y:clamp(point.y,8,view.height-size.height-8)}}
function popoverRect(dock,view,preferred){const width=Math.min(preferred.width,view.width-24),height=Math.min(preferred.height,view.height-24);let y=dock.y-height-12;if(y<12)y=dock.y+dock.height+height+12<=view.height?dock.y+dock.height+12:(view.height-height)/2;return{x:clamp(dock.x+dock.width-width,12,view.width-width-12),y:clamp(y,12,view.height-height-12),width,height}}
if(typeof module!=='undefined'&&module.exports){module.exports={dockPoint,popoverRect};return}
const dock=document.getElementById('assistant-dock'),ball=document.getElementById('assistant-launcher'),panel=document.getElementById('assistant-panel');
let stored=null,position=null,drag=null,suppressUntil=0,frame=null;
try{const p=JSON.parse(localStorage.getItem('qimao-assistant-position')||'null');if(p&&Number.isFinite(p.x)&&Number.isFinite(p.y))stored=p}catch(_){}
const viewport=()=>({width:document.documentElement.clientWidth,height:window.innerHeight});
function apply(point,persist=false){const view=viewport(),bounds=dock.getBoundingClientRect();position=dockPoint(point,view,bounds);Object.assign(dock.style,{left:position.x+'px',top:position.y+'px',right:'auto',bottom:'auto'});if(persist){stored={x:position.x/Math.max(1,view.width-bounds.width),y:position.y/Math.max(1,view.height-bounds.height)};try{localStorage.setItem('qimao-assistant-position',JSON.stringify(stored))}catch(_){}}layout()}
function place(element,preferred){if(element.hidden)return;const rect=popoverRect(dock.getBoundingClientRect(),viewport(),preferred);Object.assign(element.style,{left:rect.x+'px',top:rect.y+'px',right:'auto',bottom:'auto',width:rect.width+'px',height:rect.height+'px',maxWidth:'none',maxHeight:'none'})}
function layout(){if(!position)return;const view=viewport();place(panel,{width:430,height:Math.min(view.width<=760?650:690,view.height-120)});const alert=document.getElementById('assistant-reminder-alert');if(!alert.hidden){alert.style.height='auto';place(alert,{width:440,height:alert.getBoundingClientRect().height||170});alert.style.height='auto';alert.style.maxHeight=(view.height-24)+'px';alert.style.overflowY='auto'}}
function resized(){const view=viewport(),r=dock.getBoundingClientRect();if(stored)apply({x:stored.x*(view.width-r.width),y:stored.y*(view.height-r.height)});else if(position)apply(position);else layout()}
function reset(){stored=null;position=null;try{localStorage.removeItem('qimao-assistant-position')}catch(_){}dock.removeAttribute('style');panel.removeAttribute('style');document.getElementById('assistant-reminder-alert').removeAttribute('style');dock.classList.remove('dragging');drag=null}
function start(event){if(event.button!==0||event.target.closest('button,input,textarea,a')&&event.currentTarget!==ball)return;const r=dock.getBoundingClientRect();drag={id:event.pointerId,startX:event.clientX,startY:event.clientY,x:r.x,y:r.y,moved:false,target:event.currentTarget};drag.target.setPointerCapture?.(event.pointerId)}
function move(event){if(!drag||drag.id!==event.pointerId)return;const dx=event.clientX-drag.startX,dy=event.clientY-drag.startY;if(!drag.moved&&Math.hypot(dx,dy)<6)return;drag.moved=true;event.preventDefault();dock.classList.add('dragging');apply({x:drag.x+dx,y:drag.y+dy})}
function finish(event){if(!drag||drag.id!==event.pointerId)return;if(drag.moved){suppressUntil=performance.now()+400;apply(position,true)}dock.classList.remove('dragging');drag=null}
for(const handle of [ball,document.querySelector('.assistant-header')]){handle.addEventListener('pointerdown',start);handle.addEventListener('pointermove',move);handle.addEventListener('pointerup',finish);handle.addEventListener('pointercancel',finish)}
ball.addEventListener('click',event=>{if(performance.now()<suppressUntil){event.preventDefault();event.stopImmediatePropagation()}},true);
ball.addEventListener('keydown',event=>{if(!event.altKey||!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key))return;event.preventDefault();const r=dock.getBoundingClientRect();apply({x:r.x+(event.key==='ArrowLeft'?-20:event.key==='ArrowRight'?20:0),y:r.y+(event.key==='ArrowUp'?-20:event.key==='ArrowDown'?20:0)},true)});
document.getElementById('assistant-reset-position').onclick=reset;
window.addEventListener('resize',resized);window.addEventListener('qimao:assistant-layout',layout);
new MutationObserver(()=>{cancelAnimationFrame(frame);frame=requestAnimationFrame(layout)}).observe(panel,{attributes:true,attributeFilter:['hidden']});
new MutationObserver(layout).observe(document.getElementById('assistant-reminder-alert'),{attributes:true,attributeFilter:['hidden']});
resized();
})(typeof window!=='undefined'?window:globalThis);
