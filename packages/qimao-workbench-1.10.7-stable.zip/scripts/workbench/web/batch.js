/* Multi-episode selection and progress. Each episode keeps its own existing workflow. */
(()=>{
'use strict';
let multi=false,episodeProject=null,episodeRows=[],picked=new Set(),loading=false,requestId=0;
let batches=[],currentBatch=null,serverBusy=false,submitting=false,lastProject=null;
const saveSelections=new Map();let saveReview=null,reviewSeq=0;
function storageKey(){return 'qimao-batch-selection:'+projectId()}
function remember(){try{localStorage.setItem(storageKey(),JSON.stringify([...picked]))}catch(_){}}
function parseRange(text){
    const parts=text.trim().split(/[、,，\s]+/).filter(Boolean),values=new Set();
    if(!parts.length)throw Error('请输入集数，例如：13-16、18');
    for(const part of parts){
        const m=part.match(/^(\d+)(?:[-—~～至](\d+))?$/);
        if(!m)throw Error('集数格式不正确：'+part);
        const a=Number(m[1]),b=Number(m[2]||m[1]);
        if(a<1||b<a||b>10000)throw Error('集数范围不正确：'+part);
        for(let n=a;n<=b;n++)values.add(n);
    }
    return [...values].sort((a,b)=>a-b);
}
function selectionChanged(){
    $('#episode-selection-count').textContent='已选 '+picked.size+' 集';
    for(const input of $$('#episode-checkboxes input'))input.checked=picked.has(Number(input.value));
    remember();controls();
}
function controls(){
    $('#single-mode').classList.toggle('selected',!multi);$('#multi-mode').classList.toggle('selected',multi);
    $('#single-mode').setAttribute('aria-pressed',String(!multi));$('#multi-mode').setAttribute('aria-pressed',String(multi));
    $('.episode-field').hidden=multi;$('#episode').disabled=multi;$('#episode').required=!multi;$('#batch-setup').hidden=!multi;
    const button=$('#read-button');button.innerHTML=multi?'开始多集优化 <span>→</span>':'读取整集 <span>→</span>';
    button.disabled=submitting||serverBusy||(multi&&(loading||!picked.size||episodeProject!==projectId()));
    if(serverBusy){$('#optimize-button').disabled=true;$('#save-button').disabled=true;$('#draft-button').disabled=true;$('#prompt-editor').readOnly=true;}
    $('#load-episodes').disabled=loading||submitting;
    $('#batch-submit-state').textContent=submitting?'正在创建批次，请稍候…':serverBusy?'有任务正在运行，可先勾选集数，空闲后启动。':multi&&picked.size?'将读取并自动优化 '+picked.size+' 集 · 同时 '+Math.min(picked.size,Number($('#batch-concurrency').value))+' 集 · 完成后等待检查':'';
}
function renderEpisodes(){
    $('#episode-checkboxes').innerHTML=episodeRows.map(e=>`<label class="episode-choice" title="${esc(e.title||'第'+e.episode_num+'集')}"><input type="checkbox" value="${e.episode_num}" ${picked.has(e.episode_num)?'checked':''}><span>第 ${e.episode_num} 集</span></label>`).join('');
    selectionChanged();
}
async function loadEpisodes(){
    const pid=projectId(),seq=++requestId;loading=true;controls();
    $('#episode-load-state').textContent='正在加载当前项目集数…';
    try{
        if(!pid)throw Error('请先选择有效的七猫项目');
        const rows=await api('/api/episodes?project='+encodeURIComponent(pid));
        if(seq!==requestId||projectId()!==pid)return;
        episodeRows=rows.map(e=>({...e,episode_num:Number(e.episode_num)})).filter(e=>Number.isInteger(e.episode_num)&&e.episode_num>0).sort((a,b)=>a.episode_num-b.episode_num);
        episodeProject=pid;
        const available=new Set(episodeRows.map(e=>e.episode_num));picked=new Set([...picked].filter(n=>available.has(n)));
        renderEpisodes();$('#episode-load-state').textContent=episodeRows.length?'共 '+episodeRows.length+' 集 · 勾选集数，或输入连续/不连续范围':'当前项目尚无集数';
    }catch(e){if(seq===requestId){episodeProject=null;episodeRows=[];$('#episode-checkboxes').innerHTML='';$('#episode-load-state').textContent='加载失败：'+e.message}}
    finally{if(seq===requestId){loading=false;controls()}}
}
function projectChanged(){
    const pid=projectId();if(lastProject===pid){controls();return}lastProject=pid;
    requestId++;loading=false;episodeProject=null;episodeRows=[];picked=new Set();currentBatch=null;
    try{const stored=JSON.parse(localStorage.getItem(storageKey())||'[]');if(Array.isArray(stored))picked=new Set(stored.filter(Number.isInteger));$('#batch-brief').value=localStorage.getItem('qimao-batch-brief:'+pid)||''}catch(_){}
    $('#episode-checkboxes').innerHTML='';$('#episode-range').value='';$('#episode-load-state').textContent='切换后自动加载当前项目的集数';selectionChanged();renderBatches();if(multi)loadEpisodes();
}
function setMode(value){multi=value;controls();if(multi&&episodeProject!==projectId())loadEpisodes()}
$('#single-mode').onclick=()=>setMode(false);$('#multi-mode').onclick=()=>setMode(true);$('#load-episodes').onclick=loadEpisodes;
$('#episode-checkboxes').onchange=e=>{if(e.target.type!=='checkbox')return;const n=Number(e.target.value);if(e.target.checked)picked.add(n);else picked.delete(n);selectionChanged()};
$('#select-all-episodes').onclick=()=>{picked=new Set(episodeRows.map(e=>e.episode_num));selectionChanged()};
$('#clear-episodes').onclick=()=>{picked.clear();selectionChanged()};
$('#apply-range').onclick=()=>{try{if(episodeProject!==projectId())throw Error('请先加载项目集数');const values=parseRange($('#episode-range').value),available=new Set(episodeRows.map(e=>e.episode_num)),missing=values.filter(n=>!available.has(n));if(missing.length)throw Error('项目中没有这些集数：'+missing.join('、'));picked=new Set(values);selectionChanged()}catch(e){toast(e.message,true)}};
$('#episode-range').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();$('#apply-range').click()}};
$('#batch-concurrency').onchange=controls;
$('#batch-brief').oninput=()=>{try{localStorage.setItem('qimao-batch-brief:'+projectId(),$('#batch-brief').value)}catch(_){}};
window.qimaoBatchMode=()=>multi;
window.startBatchOptimization=async()=>{
    if(submitting)return;
    if(!picked.size||episodeProject!==projectId())return toast('请先加载并勾选当前项目集数',true);
    if(dirty)return toast('请先保存当前片段修改',true);
    submitting=true;controls();
    try{
        const result=await api('/api/batch/start',{project:$('#project').value.trim(),episodes:[...picked].sort((a,b)=>a-b),concurrency:Number($('#batch-concurrency').value),optimization_brief:$('#batch-brief').value});
        currentBatch=result.id;serverBusy=true;toast('已启动多集优化，每集分别保留备份与优化稿');await refreshBatches();await refreshJobs();$('#batch-progress-panel').scrollIntoView({behavior:'smooth',block:'start'});
    }catch(e){toast(e.message,true)}finally{submitting=false;controls()}
};
function renderBatches(){
    const rows=batches.filter(b=>String(b.project_id)===projectId());
    const panel=$('#batch-progress-panel');panel.hidden=!rows.length;if(!rows.length)return;
    if(!rows.some(b=>b.id===currentBatch))currentBatch=rows[0].id;
    const batch=rows.find(b=>b.id===currentBatch);
    const eligible=batch.jobs.filter(j=>j.save_eligible),allowed=new Set(eligible.map(j=>j.id));
    if(!saveSelections.has(batch.id))saveSelections.set(batch.id,new Set(allowed));
    const savePicked=saveSelections.get(batch.id);
    for(const id of savePicked)if(!allowed.has(id))savePicked.delete(id);
    $('#batch-save-open').disabled=serverBusy||submitting||!savePicked.size;
    $('#batch-save-select-all').disabled=serverBusy||!eligible.length;$('#batch-save-clear').disabled=serverBusy;
    $('#batch-save-selection').textContent='已选回填 '+savePicked.size+' 集 · 已核验 '+batch.jobs.filter(j=>j.status==='complete').length+' / '+batch.jobs.length+' 集';
    $('#batch-history').innerHTML=rows.map(b=>`<option value="${esc(b.id)}">${esc(b.created)} · ${b.jobs.length}集</option>`).join('');$('#batch-history').value=currentBatch;
    $('#batch-progress-context').textContent=batch.project_name+' · 项目 '+batch.project_id+' · 第 '+batch.jobs.map(j=>j.episode).join('、')+' 集';
    const done=batch.jobs.filter(j=>['review','complete','error','stopped'].includes(j.status)).length;
    const saving=batch.jobs.some(j=>j.action==='save_episode'&&activeStatuses.includes(j.status));
    $('#batch-overall').textContent=(saving?'批量回填中 · 按集数顺序保存与核验':batch.running?'批量优化中':'本批处理已结束')+' · 可检查 '+batch.ready+' / '+batch.jobs.length+' 集'+(saving?'':' · 同时最多 '+batch.concurrency+' 集');
    $('#batch-progress-fill').style.width=done/Math.max(1,batch.jobs.length)*100+'%';
    $('#batch-stop').hidden=!batch.running;$('#batch-stop').disabled=submitting;
    $('#batch-retry').hidden=batch.running||!batch.jobs.some(j=>j.action!=='save_episode'&&(['stopped','error'].includes(j.status)||j.failed>0));
    $('#batch-retry').disabled=serverBusy||submitting;
    $('#batch-job-list').innerHTML=batch.jobs.map(j=>`<article class="batch-job-card" data-status="${esc(j.status)}"><div><strong>第 ${j.episode} 集</strong><span class="batch-state">${esc(j.user_stopped?'已请求停止':j.action==='save_episode'&&j.status==='queued'?'等候回填':j.failed&&j.status==='review'?'优化未完成 · 需修复':stateNames[j.status]||j.status)}</span></div><p>${j.count?'已优化 '+j.done+' / '+j.count+' 段 · 已回填 '+(j.saved||0)+' / '+j.count+' 段':j.status==='error'?'读取未完成 · 需要继续':j.status==='stopped'?'读取已停止 · 断点已保留':j.status==='recovering'?'读取暂时失败 · 正在自动重试':j.status==='queued'?'排队等待读取':'读取与备份中'}${j.failed?' · '+j.failed+' 段需处理':''}</p><div class="progress-track"><div style="width:${j.count?(saving?j.saved||0:j.done)/j.count*100:0}%"></div></div>${j.error?'<p class="batch-error">'+esc(j.error)+'</p>':''}${(j.shot_errors||[]).map(s=>'<p class="batch-error">片段 '+String(s.no).padStart(2,'0')+'：'+esc(s.error)+'</p>').join('')}<div class="batch-card-footer"><button type="button" class="textbutton" data-batch-job="${esc(j.id)}">查看片段 ↗</button><label class="batch-save-choice"><input type="checkbox" data-batch-save-job="${esc(j.id)}" ${savePicked.has(j.id)?'checked':''} ${!j.save_eligible||serverBusy?'disabled':''}>${j.status==='complete'?'已核验 · 跳过':'加入回填'}</label></div></article>`).join('');
}
$('#batch-job-list').onclick=e=>{const b=e.target.closest('[data-batch-job]');if(b)openJob(b.dataset.batchJob)};
$('#batch-job-list').onchange=e=>{const id=e.target.dataset.batchSaveJob;if(!id)return;const chosen=saveSelections.get(currentBatch);if(!chosen)return;if(e.target.checked)chosen.add(id);else chosen.delete(id);renderBatches()};
$('#batch-save-select-all').onclick=()=>{const b=batches.find(b=>b.id===currentBatch);if(!b)return;saveSelections.set(currentBatch,new Set(b.jobs.filter(j=>j.save_eligible).map(j=>j.id)));renderBatches()};
$('#batch-save-clear').onclick=()=>{saveSelections.set(currentBatch,new Set());renderBatches()};
function saveError(text){$('#batch-save-error').textContent=text;$('#batch-save-error').hidden=!text}
async function loadSaveReview(){
    const seq=++reviewSeq,id=$('#batch-save-review-job').value;
    $('#batch-save-review-content').textContent='正在读取完整优化稿与差异…';
    try{const j=await api('/api/job/'+id);if(seq!==reviewSeq||!saveReview)return;
        $('#batch-save-review-content').innerHTML=j.shots.map(s=>`<article><h4>片段 ${String(s.no).padStart(2,'0')} · ${s.candidate.length} 字符${s.state==='saved'?' · 已回填保留':''}</h4><details open><summary>完整优化稿</summary><pre>${esc(s.candidate)}</pre></details><details><summary>修改对比</summary><pre>${esc(s.diff||'原稿暂无修改')}</pre></details><details><summary>原稿</summary><pre>${esc(s.original)}</pre></details></article>`).join('');
    }catch(e){if(seq===reviewSeq){$('#batch-save-review-content').textContent='读取失败，请重新选择集数：'+e.message;saveError(e.message)}}
}
$('#batch-save-open').onclick=async()=>{
    if(submitting||serverBusy||!currentBatch)return;if(dirty)return toast('请先保存当前片段修改',true);
    submitting=true;renderBatches();
    try{saveReview=await api('/api/batch/save/prepare',{id:currentBatch,job_ids:[...(saveSelections.get(currentBatch)||[])]});
        $('#batch-save-reviewed').checked=false;$('#batch-save-confirm').disabled=true;saveError('');
        $('#batch-save-description').textContent=saveReview.project_name+' · 项目 '+saveReview.project_id+' · 本次回填 '+saveReview.jobs.length+' 集';
        $('#batch-save-list').innerHTML=saveReview.jobs.map(j=>`<span>第 ${j.episode} 集 · 待回填 ${j.pending} / ${j.count} 段</span>`).join('');
        $('#batch-save-review-job').innerHTML=saveReview.jobs.map(j=>`<option value="${esc(j.id)}">第 ${j.episode} 集 · ${j.count} 段</option>`).join('');
        $('#batch-save-review-job').value=saveReview.jobs[0].id;$('#batch-save-dialog').showModal();await loadSaveReview();
    }catch(e){toast(e.message,true)}finally{submitting=false;renderBatches()}
};
$('#batch-save-review-job').onchange=loadSaveReview;
$('#batch-save-reviewed').onchange=()=>{$('#batch-save-confirm').disabled=!$('#batch-save-reviewed').checked||submitting};
$('#batch-save-close').onclick=()=>{$('#batch-save-dialog').close();saveReview=null;reviewSeq++};
$('#batch-save-confirm').onclick=async()=>{
    if(submitting||!saveReview||!$('#batch-save-reviewed').checked)return;
    if(dirty)return saveError('请先保存当前片段修改，再重新打开批量回填');
    submitting=true;$('#batch-save-confirm').disabled=true;saveError('');
    try{await api('/api/batch/save/confirm',{id:saveReview.id,ticket:saveReview.ticket,reviewed:true});
        $('#batch-save-dialog').close();saveReview=null;reviewSeq++;serverBusy=true;
        toast('批量回填已启动，将按集数和片段顺序保存并重读核验');await refreshBatches();await refreshJobs();
    }catch(e){saveError(e.message)}finally{submitting=false;$('#batch-save-confirm').disabled=!$('#batch-save-reviewed').checked;renderBatches();controls()}
};
$('#batch-history').onchange=()=>{currentBatch=$('#batch-history').value;renderBatches()};
async function batchAction(path){if(!currentBatch||submitting)return;if(dirty)return toast('请先保存当前片段修改',true);submitting=true;controls();try{await api(path,{id:currentBatch});await refreshBatches();await refreshJobs();toast(path.endsWith('cancel')?'已请求停止本批任务，已完成结果保留':'已继续未完成集数，已完成片段保留')}catch(e){toast(e.message,true)}finally{submitting=false;controls()}}
$('#batch-stop').onclick=()=>batchAction('/api/batch/cancel');$('#batch-retry').onclick=()=>batchAction('/api/batch/continue');
$('#read-form').addEventListener('keydown',e=>{if(multi&&e.key==='Enter'&&e.target.tagName!=='TEXTAREA'&&e.target.tagName!=='BUTTON')e.preventDefault()});
async function refreshBatches(){
    try{const [list,health]=await Promise.all([api('/api/batches'),api('/api/health')]);
        const changed=JSON.stringify(batches)!==JSON.stringify(list),wasBusy=serverBusy;batches=list;serverBusy=!!health.optimization_busy;
        if(wasBusy!==serverBusy&&!dirty)renderJob();renderBatches();controls();
        if(changed&&batches.length)await refreshJobs();
    }catch(_){} // Existing connection UI reports service availability.
}
window.addEventListener('qimao:project',projectChanged);window.addEventListener('qimao:context',controls);
projectChanged();refreshBatches();setInterval(refreshBatches,2500);
})();
