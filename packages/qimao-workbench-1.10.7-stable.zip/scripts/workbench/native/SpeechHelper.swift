import AppKit
import AVFoundation
import Speech

func outputJSON(_ value: [String: Any], to path: String? = nil) {
    guard let data = try? JSONSerialization.data(withJSONObject: value, options: [.sortedKeys]) else { return }
    if let path = path { try? data.write(to: URL(fileURLWithPath: path), options: .atomic) }
    else { print(String(data: data, encoding: .utf8) ?? "{}") }
}
let args = Array(CommandLine.arguments.dropFirst())
if args.first == "--status" {
    outputJSON(["available": true, "microphone": AVCaptureDevice.authorizationStatus(for: .audio).rawValue, "speech": SFSpeechRecognizer.authorizationStatus().rawValue])
    exit(0)
}
if args.count != 1 { outputJSON(["error": "未提供语音结果文件"]); exit(1) }

class VoiceDelegate: NSObject, NSApplicationDelegate {
    let path: String
    let engine = AVAudioEngine()
    var request: SFSpeechAudioBufferRecognitionRequest?
    var task: SFSpeechRecognitionTask?
    var recognizer: SFSpeechRecognizer?
    var timer: Timer?
    var transcript = ""
    var lastChange = Date()
    var started = Date()
    var finished = false
    var installedTap = false
    init(path: String) { self.path = path }
    func status(_ state: String, _ message: String = "") {
        outputJSON(["status": state, "text": transcript, "message": message], to: path)
    }
    func applicationDidFinishLaunching(_ notification: Notification) {
        status("permission", "请允许小七助手使用麦克风与语音识别")
        NSApp.activate(ignoringOtherApps: true)
        timer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { [weak self] _ in
            guard let self = self, !self.finished else { return }
            if FileManager.default.fileExists(atPath: self.path + ".stop") { self.finish(); return }
            if Date().timeIntervalSince(self.started) > 60 { self.finish(self.transcript.isEmpty ? "未收到语音，请再次点击麦克风重试" : ""); return }
            if self.engine.isRunning && !self.transcript.isEmpty && Date().timeIntervalSince(self.lastChange) > 2 { self.finish() }
        }
        AVCaptureDevice.requestAccess(for: .audio) { allowed in
            DispatchQueue.main.async {
                guard !self.finished else { return }
                if !allowed { self.finish("麦克风权限未开启，请在系统设置的隐私与安全性中允许“小七语音助手”使用麦克风。"); return }
                SFSpeechRecognizer.requestAuthorization { state in
                    DispatchQueue.main.async {
                        guard !self.finished else { return }
                        if state != .authorized { self.finish("语音识别权限未开启，请在系统设置中允许“小七语音助手”使用语音识别。"); return }
                        self.startRecording()
                    }
                }
            }
        }
    }
    func startRecording() {
        guard let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "zh-CN")), recognizer.isAvailable else { finish("中文语音识别服务暂不可用，可以先打字聊天。"); return }
        self.recognizer = recognizer
        let request = SFSpeechAudioBufferRecognitionRequest()
        request.shouldReportPartialResults = true
        if recognizer.supportsOnDeviceRecognition { request.requiresOnDeviceRecognition = true }
        self.request = request
        let input = engine.inputNode
        let format = input.outputFormat(forBus: 0)
        guard format.sampleRate > 0 && format.channelCount > 0 else { finish("没有检测到可用麦克风。"); return }
        input.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in request.append(buffer) }
        installedTap = true
        task = recognizer.recognitionTask(with: request) { result, error in
            DispatchQueue.main.async {
                guard !self.finished else { return }
                if let result = result {
                    let text = result.bestTranscription.formattedString
                    if text != self.transcript { self.transcript = text; self.lastChange = Date() }
                    self.status("listening")
                    if result.isFinal { self.finish(); return }
                }
                if let error = error { self.finish(self.transcript.isEmpty ? "语音识别未完成：" + error.localizedDescription : "") }
            }
        }
        do {
            engine.prepare(); try engine.start(); started = Date(); lastChange = Date(); status("listening", "正在听你说话")
        } catch { finish("麦克风启动失败：" + error.localizedDescription) }
    }
    func finish(_ error: String = "") {
        guard !finished else { return }; finished = true
        timer?.invalidate(); engine.stop()
        if installedTap { engine.inputNode.removeTap(onBus: 0) }
        request?.endAudio(); task?.cancel()
        status(error.isEmpty ? "complete" : "error", error)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { NSApp.terminate(nil) }
    }
    func applicationWillTerminate(_ notification: Notification) {
        if !finished { finish() }
    }
}
let app = NSApplication.shared
let delegate = VoiceDelegate(path: args[0])
app.setActivationPolicy(.accessory)
app.delegate = delegate
app.run()
