const fs=require('fs'),vm=require('vm'),assert=require('assert');
const nodes={};let shot={no:1,state:'pending'},listeners={};
function element(id){return nodes[id]??=( {hidden:false,disabled:false,value:'',innerHTML:'',textContent:'',addEventListener:(n,f)=>{listeners[id+':'+n]=f}})}
const ctx={document:{getElementById:element},job:{id:'isolated',status:'ready'},currentShot:()=>shot,isRevision:()=>false,activeStatuses:['optimizing'],esc:s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),window:{addEventListener:(n,f)=>{listeners[n]=f}},URL,encodeURIComponent,api:()=>{},renderJob:()=>{},toast:()=>{}};
vm.runInNewContext(fs.readFileSync('web/highlight-reference.js','utf8'),ctx);
assert.match(nodes['highlight-state'].textContent,/待判断/);
shot.candidate='旧稿';listeners['qimao:context']();assert.match(nodes['highlight-state'].textContent,/未运行/);assert(nodes['highlight-policy'].disabled);
shot.highlight_reference={status:'adopted',message:'<script>bad</script>',used:true,selected:{title:'测试来源',url:'https://evil.test/a'},applications:[{line:1,before:'旧稿',after:'新稿',description:'实际采用'}],evidence:{start:0,end:3,duration:3,folder:'references/shot-1/abc',sheets:['sheet-01.jpg']},analysis:{beats:[],uncertainties:[]}};
listeners['qimao:context']();const html=nodes['highlight-reference-body'].innerHTML;
assert.match(nodes['highlight-state'].textContent,/已采用视频/);assert(!html.includes('<script>'));assert(!html.includes('https://evil.test'));assert(html.includes('/api/reference/isolated/sheet-01.jpg?folder=references%2Fshot-1%2Fabc'));assert(html.includes('修改前：旧稿'));assert(html.includes('修改后：新稿'));
console.log('高光记录视图通过：历史稿不冒认、使用位置与真实帧链接可查看、外部链接及HTML转义。');
