"""取消字符上限后的业务回归，所有模型和平台调用隔离。"""
import copy,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import server as app
from test_workbench import fixture,TEXT
from test_prompt_helpers import reply as model_reply
from workbench_notices import automatic_notices

class OutputLimitTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.old=app.DATA;app.DATA=Path(self.temp.name)
        self.delay_patch=patch.object(app,'DELAYS',(0,0));self.delay_patch.start()
    def tearDown(self):self.delay_patch.stop();app.DATA=self.old;self.temp.cleanup()
    def job(self):
        j=fixture();j.update(read_complete=True,status='ready');s=j['shots'][0]
        s['original']=TEXT.replace('两人保持原位。','两人保持原位。'+'甲左手持杯，乙站在门内右后方。'*1000)
        s['snapshot']['prompt_text']=s['original'];s.update(candidate='',state='blocked',error='原稿已超过7000；保留全文并停止自动优化')
        return j
    def run_opt(self,j,reply=None):
        calls=[]
        def model(prompt,jid,**kw):
            if kw.get('schema')==app.SCHEMA:calls.append((prompt,kw.get('schema')))
            return reply or model_reply(prompt,kw.get('schema'))
        with patch.object(app.subprocess,'run',return_value=SimpleNamespace(returncode=0)),patch.object(app,'skill_context',return_value='隔离测试技能'),patch.object(app,'model_json',model):app.optimize(j)
        return calls
    def test_long_source_and_candidate_keep_complete_content(self):
        j=self.job();before=copy.deepcopy(j['shots'][0]);calls=self.run_opt(j);s=j['shots'][0]
        self.assertEqual(len(calls),1);self.assertEqual(calls[0][1],app.SCHEMA);self.assertEqual(s['state'],'draft')
        self.assertGreater(len(s['candidate']),7000);self.assertTrue(app.content_approved(s,s['candidate']));self.assertIn('甲左手持杯，乙站在门内右后方。'*1000,s['candidate'])
        self.assertEqual(s['original'],before['original']);self.assertEqual(s['snapshot'],before['snapshot'])
        self.assertTrue(app.validate(s,s['candidate'])['ok']);self.assertEqual(app.dialogue(s['original']),app.dialogue(s['candidate']))
        restored=app.load(j['id'])['shots'][0];self.assertEqual(restored['candidate'],s['candidate'])
    def test_old_length_failure_recovers_without_alert(self):
        j=self.job();d=app.decorate(j);s=d['shots'][0]
        self.assertEqual(s['state'],'pending');self.assertNotIn('error',s);self.assertTrue(s['validation']['ok'])
        self.assertEqual(automatic_notices([d])[0]['kind'],'ready')
    def test_real_failures_and_unclear_style_remain_blocked(self):
        for error,original in [('平台版本冲突',TEXT),('原稿超过7000','无风格边界')]:
            j=self.job();s=j['shots'][0];s.update(error=error,original=original)
            app.normalize_source_limits(j);self.assertEqual(s['state'],'blocked');self.assertEqual(s['error'],error)
    def test_long_locked_style_does_not_block_model(self):
        j=self.job();s=j['shots'][0];s['original']='风格原文。'*2000+s['original'];s['snapshot']['prompt_text']=s['original']
        calls=self.run_opt(j);self.assertEqual(len(calls),1);self.assertEqual(s['state'],'draft')
        self.assertEqual(app.split_style(s['original'])[::2],app.split_style(s['candidate'])[::2])
    def test_content_dialogue_style_timing_and_bindings_still_protected(self):
        j=self.job();self.run_opt(j);s=j['shots'][0]
        changes=[('乙站在门内右后方。',''),('原句，一个字不改。','改词。'),('写实CG','其他风格'),('c01，5秒','c01，6秒'),('【画风】','@新角色\n【画风】')]
        for old,new in changes:self.assertFalse(app.validate(s,s['candidate'].replace(old,new))['ok'],old)
    def test_obsolete_insertion_response_is_not_adopted(self):
        j=self.job();self.run_opt(j,{'insertions':[{'after_line':1,'text':'@新角色出现'}],'review':'无效'})
        self.assertEqual(j['shots'][0]['candidate'],'');self.assertEqual(j['shots'][0]['state'],'failed')
    def test_read_accepts_long_original(self):
        j=self.job();snap=copy.deepcopy(j['shots'][0]['snapshot']);j['shots']=[]
        def cli(args):return {'shot':snap,'project':{'name':'隔离项目'}} if args[:2]==['shot','get'] else {'items':[]}
        with patch.object(app,'capture_context',return_value={}),patch.object(app,'paged',return_value=[{'id':snap['id'],'shot_no':1}]),patch.object(app,'runcli',cli):app.read_episode(j)
        self.assertEqual(j['shots'][0]['state'],'pending');self.assertEqual(j['shots'][0]['original'],snap['prompt_text'])

if __name__=='__main__':unittest.main(verbosity=2)
