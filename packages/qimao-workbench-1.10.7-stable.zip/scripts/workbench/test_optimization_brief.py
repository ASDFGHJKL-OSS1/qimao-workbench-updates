"""整集想法随HTTP启动保存，并传入各段生成与独立核对；全部使用隔离数据。"""
import copy,http.client,json,tempfile,threading,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import server as app
from test_workbench import fixture
from test_prompt_helpers import reply

class OptimizationBriefTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.old=app.DATA;app.DATA=Path(self.temp.name)
        self.j=fixture();self.j.update(status='ready',read_complete=True)
        self.j['shots'][0].update(candidate='',state='pending')
    def tearDown(self):app.DATA=self.old;self.temp.cleanup()
    def test_blank_and_legacy_requests_remain_supported(self):
        app.prepare_optimization(self.j,{})
        self.assertEqual(self.j['optimization_brief'],'')
        self.assertEqual(app.optimization_instructions(self.j),'')
    def test_retries_preserve_saved_ideas_and_reject_silent_changes(self):
        app.prepare_optimization(self.j,{'optimization_brief':'  增强情绪递进  '})
        self.j['optimization_run_id']='previous-run'
        app.prepare_optimization(self.j,{})
        self.assertEqual(self.j['optimization_brief'],'增强情绪递进')
        with self.assertRaises(app.Problem):app.prepare_optimization(self.j,{'optimization_brief':'改成另一要求'})
    def test_instruction_input_limit_does_not_limit_prompt(self):
        for value in [None,[],1,'字'*5001]:
            with self.assertRaises(app.Problem):app.prepare_optimization(self.j,{'optimization_brief':value})
        app.prepare_optimization(self.j,{'optimization_brief':'字'*5000})
        s=self.j['shots'][0];s['original']=s['original'].replace('【画风】','完整细节。'*1600+'\n【画风】')
        self.assertTrue(app.validate(s,s['original'],imported=True)['ok'])
    def test_both_generation_and_audit_receive_ideas_for_every_shot(self):
        brief='整集加强情绪递进；片段02采用更清楚的侧面视线。'
        app.prepare_optimization(self.j,{'optimization_brief':brief})
        second=copy.deepcopy(self.j['shots'][0]);second.update(id='12',no=2)
        self.j['shots'].append(second);calls=[]
        def model(prompt,jid,schema=None):
            calls.append((prompt,schema));return reply(prompt,schema)
        with patch.object(app.subprocess,'run',return_value=SimpleNamespace(returncode=0)),patch.object(app,'model_json',model):app.optimize(self.j)
        self.assertEqual(len(calls),4)
        for prompt,schema in calls:
            self.assertIn(brief,prompt);self.assertIn('注明片段号的要求仅用于对应片段',prompt)
            if schema==app.CONTENT_SCHEMA:self.assertIn('未落实',prompt)
        self.assertTrue(all(s['state']=='draft' for s in self.j['shots']))
        self.assertEqual(app.load(self.j['id'])['optimization_brief'],brief)
        attempts=list(app.jobpath(self.j['id']).glob('attempts/*.json'))
        self.assertEqual(len(attempts),2)
        self.assertTrue(all(json.loads(p.read_text())['optimization_brief']==brief for p in attempts))
    def test_step05_keeps_its_own_instructions(self):
        self.j.update(kind='revision',instructions='只调整所选段的目光',optimization_brief='旧整集想法')
        app.prepare_optimization(self.j,{'optimization_brief':'不应覆盖05'})
        contract=app.optimization_instructions(self.j)
        self.assertIn('只调整所选段的目光',contract)
        self.assertNotIn('旧整集想法',contract)

    def test_adjacent_sources_and_authorized_scene_scope_are_explicit(self):
        first=copy.deepcopy(self.j['shots'][0]);first.update(no=2,candidate='已优化正文',state='draft')
        last=copy.deepcopy(first);last.update(no=3,candidate='失败候选不得作依据',state='failed')
        self.j['shots'].extend([first,last]);context=app.adjacent_context(self.j,1)
        self.assertEqual(context['previous']['text'],self.j['shots'][0]['original'])
        self.assertIn('平台原稿',context['previous']['source'])
        self.assertEqual(context['next']['text'],last['original'])
        context=app.adjacent_context(self.j,2)
        self.assertEqual(context['previous']['text'],'已优化正文')
        self.assertIn('通过校验',context['previous']['source'])
        self.j['optimization_brief']='场景是在屋内，不是在外廊';calls=[]
        self.j['shots']=self.j['shots'][:1]
        def model(prompt,jid,schema=None):calls.append(prompt);return reply(prompt,schema)
        with patch.object(app.subprocess,'run',return_value=SimpleNamespace(returncode=0)),patch.object(app,'model_json',model):app.optimize(self.j)
        self.assertEqual(len(calls),2)
        for prompt in calls:
            self.assertIn('旧场景等描述不能否决',prompt)
            self.assertIn('原定光向',prompt)
        self.assertIn('不可改名的完整资产绑定清单',calls[0])
    def test_http_start_persists_ideas_before_background_launch(self):
        app.store(self.j);httpd=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
        worker=threading.Thread(target=httpd.serve_forever,daemon=True);worker.start()
        def launch(job,action):app.store(job)
        try:
            with patch.object(app,'background',side_effect=launch),patch.object(app,'runcli',side_effect=AssertionError('不访问平台')):
                conn=http.client.HTTPConnection('127.0.0.1',httpd.server_port)
                conn.request('POST','/api/optimize',json.dumps({'id':self.j['id'],'optimization_brief':'本集增强情绪'}),{'Host':f'127.0.0.1:{app.PORT}','X-Workbench-Token':app.TOKEN})
                response=conn.getresponse();body=response.read();conn.close()
                self.assertEqual(response.status,200,body)
                self.assertEqual(app.load(self.j['id'])['optimization_brief'],'本集增强情绪')
        finally:httpd.shutdown();httpd.server_close();worker.join()

if __name__=='__main__':unittest.main()
