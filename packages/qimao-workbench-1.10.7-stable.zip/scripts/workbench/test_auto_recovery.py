"""自动补齐、断点恢复及异常重试；所有外部模型与七猫写入均隔离。"""
import copy,json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import server as app
from auto_recovery import recoverable_stage, retryable
from test_workbench import fixture,TEXT
import test_workbench
from test_prompt_helpers import reply

class AutoRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.old=app.DATA;app.DATA=Path(self.temp.name)
        self.delays=patch.object(app,'DELAYS',(0,0));self.delays.start()
        self.dependencies=patch.object(app.subprocess,'run',return_value=SimpleNamespace(returncode=0));self.dependencies.start()
        self.j=fixture();self.j.update(read_complete=True,status='ready',recovery={'enabled':True,'action':'optimize'})
        self.j['shots'][0].update(state='pending',candidate='')
    def tearDown(self):
        self.dependencies.stop();self.delays.stop();app.CANCEL.discard(self.j['id']);app.DATA=self.old;self.temp.cleanup()
    def test_missing_continuity_heading_added_without_rewriting_original_style(self):
        s=self.j['shots'][0];s['original']=TEXT.replace('人物空间连续性：两人保持原位。\n','')
        before=copy.deepcopy(s)
        with patch.object(app,'model_json',side_effect=lambda prompt,jid,schema:reply(prompt,schema)):app.optimize(self.j)
        self.assertEqual(s['state'],'draft');self.assertEqual(s['original'],before['original']);self.assertEqual(s['snapshot'],before['snapshot'])
        self.assertIn('人物空间连续性：',s['candidate']);self.assertTrue(app.validate(s,s['candidate'])['ok'])
        self.assertEqual(app.split_style(s['original'])[::2],app.split_style(s['candidate'])[::2])
        backup=json.loads(next(app.jobpath(self.j['id']).glob('versions/*.json')).read_text())
        self.assertEqual(backup['text'],before['original'])
    def test_each_or_both_markers_missing_and_alias_style_preserved(self):
        for source in [TEXT.replace('【画风】',''),TEXT.replace('人物空间连续性：','').replace('【画风】',''),TEXT.replace('【画风】','画风：')]:
            # Existing narrative above c01 remains protected when no continuity title exists.
            parts,added=app.sections(source);normalized=''.join(parts)
            self.assertTrue(app.subseq(source,normalized));self.assertIn('人物空间连续性：',normalized);self.assertIn('【画风】',normalized)
            self.assertEqual(''.join(app.split_style(normalized)),normalized)
            self.assertTrue(app.validate({'original':source},normalized)['ok'])
            self.assertTrue(app.validate({'original':source},source)['ok'])
    def test_old_boundary_block_is_recovered(self):
        s=self.j['shots'][0];s.update(original=TEXT.replace('人物空间连续性：',''),state='blocked',error='无法自动确定风格边界')
        app.normalize_source_limits(self.j);self.assertEqual(s['state'],'pending');self.assertNotIn('error',s)
    def test_timeout_then_valid_result_automatically_finishes_only_pending_shot(self):
        completed=copy.deepcopy(self.j['shots'][0]);completed.update(no=2,state='draft',candidate=TEXT);self.j['shots'].append(completed)
        before=copy.deepcopy(completed);calls=[]
        def model(prompt,jid,schema):
            calls.append(schema)
            if len(calls)==1:raise app.Problem('模型响应超时')
            return reply(prompt,schema)
        with patch.object(app,'model_json',side_effect=model):app.optimize(self.j)
        self.assertEqual(self.j['shots'][0]['state'],'draft');self.assertEqual(self.j['shots'][1],before)
        self.assertEqual(self.j['shots'][0]['auto_recovery']['state'],'complete')
        self.assertEqual(calls,[app.SCHEMA,app.SCHEMA,app.CONTENT_SCHEMA])
    def test_bad_format_retries_then_still_requires_independent_audit(self):
        calls=[]
        def model(prompt,jid,schema):
            calls.append(schema)
            return {'lines':[],'review':''} if len(calls)==1 else reply(prompt,schema)
        with patch.object(app,'model_json',side_effect=model):app.optimize(self.j)
        self.assertEqual(calls,[app.SCHEMA,app.SCHEMA,app.CONTENT_SCHEMA]);self.assertTrue(self.j['shots'][0]['content_check']['complete'])
    def test_login_error_not_retried_and_cannot_become_valid_draft(self):
        with patch.object(app,'model_json',side_effect=app.Problem('登录失效，请重新登录')) as model:app.optimize(self.j)
        self.assertEqual(model.call_count,1);self.assertEqual(self.j['shots'][0]['state'],'failed');self.assertFalse(self.j['shots'][0]['candidate'])
    def test_persistent_invalid_content_stops_after_three_full_checks(self):
        calls=[]
        def model(prompt,jid,schema):
            calls.append(schema);r=reply(prompt,schema)
            if schema==app.CONTENT_SCHEMA:r.update(complete=False,issues=['原动作被删除'])
            return r
        with patch.object(app,'model_json',side_effect=model):app.optimize(self.j)
        self.assertEqual(len(calls),6);self.assertFalse(self.j['shots'][0]['candidate']);self.assertEqual(self.j['shots'][0]['state'],'failed')
    def test_stop_during_delay_is_respected(self):
        app.CANCEL.add(self.j['id'])
        with self.assertRaises(app.Problem):app.recovery_wait(self.j,1,'模型响应超时')
    def test_restart_resumes_only_enabled_authorized_actions(self):
        j=self.j;j['status']='optimizing';self.assertEqual(recoverable_stage(j),'optimize')
        j['recovery']['user_stopped']=True;self.assertIsNone(recoverable_stage(j));j['recovery']['user_stopped']=False
        j['recovery']['action']='save_episode';j['status']='saving';self.assertIsNone(recoverable_stage(j))
        j['recovery']['save_authorized']=True;self.assertEqual(recoverable_stage(j),'save_episode')
        j['status']='review';self.assertIsNone(recoverable_stage(j))
        j.update(status='optimizing',revision_prepared=True);j['recovery']['action']='revise_episode'
        self.assertEqual(recoverable_stage(j),'optimize')
    def test_job_stage_transient_network_failure_is_retried(self):
        calls=[]
        def action(j):
            calls.append(1)
            if len(calls)==1:raise app.Problem('七猫读取超时')
            j['status']='ready'
        app.run_recovering(self.j,action);self.assertEqual(len(calls),2);self.assertEqual(self.j['recovery']['state'],'complete')
    def test_english_service_errors_retry_and_auth_conflicts_remain_blocked(self):
        for message in ['Service Unavailable','SERVICE_UNAVAILABLE','HTTP 503','Bad Gateway','gateway timeout','Too Many Requests','HTTP 429','HTTP 502','HTTP 504','Internal Server Error','connection reset by peer','request timed out','服务繁忙','片段40301 Service Unavailable']:
            with self.subTest(message=message):self.assertTrue(retryable(app.Problem(message)))
        for message in ['UNAUTHORIZED Service Unavailable','HTTP 403 Service Unavailable','HTTP 401','已停止 Service Unavailable','片段1版本或配置已变化 HTTP 503','原稿为空 HTTP 503','未知不可恢复问题']:
            with self.subTest(message=message):self.assertFalse(retryable(app.Problem(message)))
    def test_real_cli_service_unavailable_then_success_resumes_batch_without_write(self):
        j=self.j;j['read_complete']=False;calls=[]
        def read(row):
            app.runcli(['shot','get']);row['read_complete']=True;row['status']='ready';calls.append('read')
        def optimized(row):calls.append('optimize');row['status']='review'
        fail=SimpleNamespace(returncode=1,stdout=json.dumps({'error':{'message':'Service Unavailable'}}))
        good=SimpleNamespace(returncode=0,stdout=json.dumps({'data':{'ok':True}}))
        with patch.object(app.subprocess,'run',side_effect=[fail,good]) as cli,patch.object(app,'read_episode',side_effect=read),patch.object(app,'optimize',side_effect=optimized),patch.object(app,'save_episode') as save:
            app.run_recovering(j,app.batch_episode)
        self.assertEqual(cli.call_count,2);self.assertEqual(calls,['read','optimize']);self.assertEqual(j['status'],'review');save.assert_not_called()
        self.assertEqual(j['recovery']['attempt'],1);self.assertEqual(j['recovery']['state'],'complete')
    def test_persistent_503_still_stops_after_three_attempts(self):
        with patch.object(app,'read_episode',side_effect=app.Problem('HTTP 503 Service Unavailable')) as read:
            self.j['read_complete']=False
            with self.assertRaisesRegex(app.Problem,'503'):app.run_recovering(self.j,app.batch_episode)
        self.assertEqual(read.call_count,3)
    def test_worker_progress_cannot_erase_persisted_manual_stop(self):
        j=self.j;j['recovery'].update(run_id='same-run',user_stopped=True,enabled=False);app.store(j)
        stale=copy.deepcopy(j);stale['recovery'].update(user_stopped=False,enabled=True);app.store(stale)
        self.assertTrue(app.load(j['id'])['recovery']['user_stopped'])
        # 用户明确再次开始属于新一轮，允许恢复。
        stale['recovery'].update(run_id='new-run',user_stopped=False,enabled=True);app.store(stale)
        self.assertFalse(app.load(j['id'])['recovery']['user_stopped'])
    def test_startup_recovery_dispatches_pending_stage_and_skips_stopped_or_review(self):
        for jid,status,stopped in [('pending','optimizing',False),('stopped','optimizing',True),('review','review',False)]:
            j=copy.deepcopy(self.j);j.update(id=jid,status=status);j['recovery']['user_stopped']=stopped;app.store(j)
        calls=[]
        def launch(j,action,resume=False):calls.append((j['id'],action.__name__,resume))
        with patch.object(app,'background',side_effect=launch):app.recover_interrupted_jobs()
        self.assertEqual(calls,[('pending','optimize',True)])
    def test_uncertain_authorized_write_is_verified_without_duplicate_submission(self):
        j=fixture();j['recovery']={'enabled':True,'save_authorized':True}
        contract=test_workbench.ContractTests();cli,writes=contract.platform(j,uncertain=True)
        with patch.object(app,'runcli',cli),patch.object(app,'preflight',lambda j:None):app.run_recovering(j,app.save_episode)
        self.assertEqual(j['status'],'complete');self.assertEqual(len(writes),1)
    def test_version_conflict_is_never_retried_or_overwritten(self):
        with patch.object(app,'save_episode',side_effect=app.Problem('片段1版本或配置已变化，停止覆盖')) as action:
            with self.assertRaises(app.Problem):app.run_recovering(self.j,action)
        self.assertEqual(action.call_count,1)

if __name__=='__main__':unittest.main()
