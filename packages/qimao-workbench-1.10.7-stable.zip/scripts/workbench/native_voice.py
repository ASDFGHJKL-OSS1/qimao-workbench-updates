"""为不支持Web Speech的内置浏览器提供macOS原生语音入口。"""
import json,subprocess,threading,time,uuid
from pathlib import Path
class VoiceError(Exception):pass
class NativeVoice:
    def __init__(self,root):
        self.root=Path(root);self.app=self.root/'native/小七语音助手.app';self.binary=self.app/'Contents/MacOS/SpeechHelper';self.folder=self.root/'data/voice';self.folder.mkdir(parents=True,exist_ok=True)
        self.lock=threading.RLock();self.session=None;self.player=None;self.voice=None
    def state(self):
        with self.lock:
            result={'available':self.binary.is_file(),'status':'idle','text':'','message':''}
            if not self.session:return result
            p=self.session['path']
            try:result.update(json.loads(p.read_text()))
            except (OSError,ValueError):result.update(status='starting',message='正在打开系统语音…')
            proc=self.session['process']
            if proc.poll() is not None and result['status'] in ('starting','permission','listening'):
                result.update(status='error',message='系统语音未能完成，请检查系统权限或先打字聊天。')
            result['session_id']=self.session['id'];return result
    def busy(self):return self.state()['status'] in ('starting','permission','listening')
    def start(self):
        with self.lock:
            if not self.binary.is_file():raise VoiceError('当前机器未安装原生语音组件，可以先打字聊天')
            if self.busy():raise VoiceError('麦克风已在使用，请先结束当前语音输入')
            sid=uuid.uuid4().hex;p=self.folder/(sid+'.json')
            with open(self.folder/'voice.log','a') as log:
                proc=subprocess.Popen(['/usr/bin/open','-W','-n',str(self.app),'--args',str(p)],stdout=log,stderr=log)
            self.session={'id':sid,'path':p,'process':proc};return self.state()
    def stop(self):
        with self.lock:
            if self.session:self.session['path'].with_suffix('.json.stop').touch()
            return {'ok':True}
    def stop_speaking(self):
        with self.lock:
            if self.player and self.player.poll() is None:
                self.player.terminate()
                try:self.player.wait(timeout=1)
                except subprocess.TimeoutExpired:self.player.kill();self.player.wait()
            return {'ok':True}
    def speak(self,text):
        if not isinstance(text,str) or not text.strip() or len(text)>15000:raise VoiceError('朗读内容为空或过长')
        with self.lock:
            self.stop_speaking()
            if self.voice is None:
                p=subprocess.run(['/usr/bin/say','-v','?'],capture_output=True,text=True,timeout=5)
                matches=[line.split('zh_CN')[0].strip() for line in p.stdout.splitlines() if 'zh_CN' in line]
                self.voice=next((v for v in matches if v.lower().startswith('ting')),matches[0] if matches else '')
            args=['/usr/bin/say','-r','190']+(['-v',self.voice] if self.voice else [])
            self.player=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,text=True)
            self.player.stdin.write(text);self.player.stdin.close();return {'ok':True,'mode':'macos'}
