import tempfile,threading,time,unittest
from datetime import datetime,timedelta,timezone
from pathlib import Path
from assistant_service import AssistantService,AssistantError
class AssistantTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.path=Path(self.temp.name)/'assistant.json';self.cancel=set()
    def tearDown(self):self.temp.cleanup()
    def service(self,model=None):return AssistantService(self.path,model or (lambda *a,**kw:{'reply':'测试回答','reminder':None}),lambda scope:{'label':'测试片段'},self.cancel)
    def due(self,seconds=60):return (datetime.now(timezone.utc)+timedelta(seconds=seconds)).isoformat()
    def wait_done(self,s):
        deadline=time.monotonic()+3
        while s.active and time.monotonic()<deadline:time.sleep(.01)
        self.assertIsNone(s.active)
    def test_reminders_survive_restart(self):
        s=self.service();r=s.add_reminder('检查回填',self.due());fresh=self.service();self.assertEqual(fresh.state()['reminders'][0]['id'],r['id'])
    def test_past_and_naive_dates_rejected(self):
        s=self.service()
        for due in [self.due(-5),'2026-11-10T12:00','not-a-date']:
            with self.assertRaises(AssistantError):s.add_reminder('检查',due)
        self.assertEqual(s.state()['reminders'],[])
    def test_claim_once_and_not_early(self):
        s=self.service();r=s.add_reminder('检查',self.due())
        with self.assertRaises(AssistantError):s.claim_reminder(r['id'])
        s.data['reminders'][0]['due_at']=time.time()-1
        self.assertTrue(s.claim_reminder(r['id'])['claimed']);self.assertFalse(s.claim_reminder(r['id'])['claimed'])
    def test_cancelled_reminder_never_fires(self):
        s=self.service();r=s.add_reminder('检查',self.due());s.cancel_reminder(r['id']);s.data['reminders'][0]['due_at']=time.time()-1;self.assertFalse(s.claim_reminder(r['id'])['claimed'])
    def test_message_idempotency_and_real_reply_flow(self):
        calls=[]
        def model(*args,**kwargs):calls.append(args);return {'reply':'只读取，没有再次优化','reminder':None}
        s=self.service(model);first=s.send('又优化了吗','request-12345678',{});self.wait_done(s);second=s.send('又优化了吗','request-12345678',{})
        self.assertEqual(first['message_id'],second['message_id']);self.assertEqual(len(calls),1);self.assertEqual(s.state()['messages'][-1]['status'],'done');self.assertEqual(len(s.state()['messages']),2)
    def test_chat_reminder_creates_after_valid_response(self):
        s=self.service(lambda *a,**k:{'reply':'我会帮你记下。','reminder':{'text':'检查回填','due_at':self.due()}});s.send('一分钟后提醒我检查回填','request-22345678',{});self.wait_done(s)
        self.assertEqual(len(s.state()['reminders']),1);self.assertIn('已设提醒',s.state()['messages'][-1]['text'])
    def test_chat_failure_stores_error_without_claiming_success(self):
        def model(*a,**k):raise RuntimeError('测试连接失败')
        s=self.service(model);s.send('问题','request-32345678',{});self.wait_done(s);last=s.state()['messages'][-1];self.assertEqual(last['status'],'error');self.assertIn('未完成',last['text'])
    def test_cancel_discards_late_result(self):
        gate=threading.Event()
        def model(*a,**k):gate.wait(2);return {'reply':'迟到结果','reminder':{'text':'不应创建','due_at':self.due()}}
        s=self.service(model);s.send('问题','request-42345678',{});s.cancel();gate.set();self.wait_done(s)
        self.assertEqual(s.state()['reminders'],[]);self.assertEqual(s.state()['messages'][-1]['text'],'回答已停止。')
    def test_restart_recovers_interrupted_message(self):
        s=self.service();s.data['messages'].append({'id':'test','role':'assistant','status':'thinking','text':''});s._save();s=self.service();self.assertEqual(s.state()['messages'][-1]['status'],'error')
if __name__=='__main__':unittest.main(verbosity=2)
