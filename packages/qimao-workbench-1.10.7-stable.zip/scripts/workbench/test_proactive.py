"""主动提醒和必用技能链的业务测试，使用隔离任务与模型。"""
import copy,hashlib,json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import server as app
from assistant_service import AssistantService
from test_workbench import fixture
from test_prompt_helpers import reply
from workbench_notices import automatic_notices
class ProactiveTests(unittest.TestCase):
    def job(self):
        j=fixture();j.update(episode=7,created='2026-10-28 17:00:00',updated='2026-10-28 17:01:00',status='ready',read_complete=True);return j
    def test_automatic_ready_without_any_user_reminder(self):
        notices=automatic_notices([self.job()]);self.assertEqual(notices[0]['kind'],'ready');self.assertIn('已完整读取',notices[0]['text'])
    def test_long_candidate_does_not_trigger_length_warning(self):
        j=self.job();j['shots'][0]['candidate']='字'*7005;item=automatic_notices([j])[0]
        self.assertEqual(item['kind'],'ready');self.assertNotIn('超出',item['text'])
    def test_active_work_does_not_prematurely_announce_completion(self):
        for status in ('reading','queued','optimizing','saving'):
            j=self.job();j['status']=status;self.assertEqual(automatic_notices([j]),[])
    def test_review_and_completion_have_different_ids(self):
        j=self.job();j['status']='review';first=automatic_notices([j])[0];j['status']='complete';last=automatic_notices([j])[0]
        self.assertNotEqual(first['id'],last['id']);self.assertIn('等待你检查',first['text']);self.assertIn('重读核验完成',last['text'])
    def test_latest_episode_only_and_historical_copy_is_ignored(self):
        old=self.job();new=copy.deepcopy(old);new.update(id='new',created='2026-10-28 18:00:00',status='review')
        history=copy.deepcopy(new);history.update(id='history',historical=True,created='2026-10-28 19:00:00')
        notices=automatic_notices([old,new,history]);self.assertEqual(len(notices),1);self.assertEqual(notices[0]['job_id'],'new')
    def test_revision_checks_selected_only(self):
        j=self.job();s=copy.deepcopy(j['shots'][0]);s.update(no=2,candidate='字'*8000);j['shots'].append(s);j.update(kind='revision',target_nos=[1],status='review')
        self.assertEqual(automatic_notices([j])[0]['kind'],'review')
    def test_failed_and_stopped_explain_real_error(self):
        for status in ('error','stopped'):
            j=self.job();j.update(status=status,error='平台版本改变');self.assertIn('平台版本改变',automatic_notices([j])[0]['text'])
    def test_notice_claim_is_once_and_survives_restart(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'assistant.json';service=AssistantService(path,None,None,set());item=automatic_notices([self.job()])[0]
            self.assertTrue(service.claim_notice(item)['claimed']);self.assertFalse(service.claim_notice(item)['claimed'])
            again=AssistantService(path,None,None,set());self.assertTrue(again.notices([item])[0]['delivered']);self.assertEqual(again.state()['messages'],[])
    def test_same_problem_does_not_repeat_on_unrelated_update(self):
        j=self.job();first=automatic_notices([j])[0];j['updated']='2026-10-28 20:00:00';self.assertEqual(first['id'],automatic_notices([j])[0]['id'])
    def test_real_skill_files_are_injected_and_audited_for_every_optimization(self):
        context=app.skill_context();status=app.optimization_skill_status();self.assertTrue(status['ready'])
        for f in app.OPTIMIZATION_SKILL_FILES:self.assertIn((app.SKILLS/f).read_text(),context)
        with tempfile.TemporaryDirectory() as td:
            j=self.job();j['shots'][0].update(candidate='',state='pending');old=app.DATA;app.DATA=Path(td);seen=[]
            def model(prompt,*args,**kw):
                seen.append(prompt);return reply(prompt,kw.get('schema'))
            try:
                with patch.object(app.subprocess,'run',return_value=SimpleNamespace(returncode=0)),patch.object(app,'model_json',model):app.optimize(j)
                self.assertIn(context,seen[0]);audit=j['shots'][0]['skill_run'];self.assertEqual(audit['status'],'complete');self.assertEqual(audit['context_sha256'],hashlib.sha256(context.encode()).hexdigest());self.assertIn('人物情绪表演导演',audit['required'])
            finally:app.DATA=old
if __name__=='__main__':unittest.main(verbosity=2)
