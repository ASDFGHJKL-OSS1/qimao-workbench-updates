"""可迁移安装包的本机路径解析，不包含登录凭据。"""
import os,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PRIVATE=ROOT/'private/skills'
SKILLS=Path(os.environ['QIMAO_SKILLS_ROOT']).expanduser() if os.environ.get('QIMAO_SKILLS_ROOT') else PRIVATE if PRIVATE.is_dir() else Path(__file__).resolve().parents[3]
def find_tool(env,name,candidates):
    if os.environ.get(env):return str(Path(os.environ[env]).expanduser())
    for candidate in candidates:
        p=Path(candidate).expanduser()
        if p.is_file() and os.access(p,os.X_OK):return str(p)
    return shutil.which(name) or name
CLI=find_tool('QIMAO_CINEFLOW_PATH','cineflow',[Path.home()/'.local/bin/cineflow','/opt/homebrew/bin/cineflow','/usr/local/bin/cineflow'])
CODEX=find_tool('QIMAO_CODEX_PATH','codex',[
    '/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex',
    '/Applications/Codex.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex',
    Path.home()/'Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex',
    Path.home()/'Applications/Codex.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex',
    '/Applications/ChatGPT.app/Contents/Resources/codex-cli/bin/codex',
    '/Applications/Codex.app/Contents/Resources/codex',Path.home()/'.local/bin/codex',
    '/opt/homebrew/bin/codex','/usr/local/bin/codex'])
