// 验证实际多集页面脚本的选择、项目隔离、异步切换与提交行为。
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const els={},events={},storage=new Map(),calls=[],loaders=[];let pid='2278',defer=false,batchList=[];
function el(id){return els[id]||(els[id]={value:'',textContent:'',style:{},hidden:false,disabled:false,required:false,readOnly:false,innerHTML:'',classList:{toggle(){}},setAttribute(){},addEventListener(n,cb){this[n]=cb},scrollIntoView(){},showModal(){this.open=true},close(){this.open=false},click(){return this.onclick?.()}})}
el('#batch-concurrency').value='3';el('#project').value='2278';
const rows=Array.from({length:20},(_,i)=>({episode_num:i+1,title:'第'+(i+1)+'集'}));
const ctx={console,Set,Promise,Number,JSON,Error,$:el,$$:()=>[],projectId:()=>pid,esc:s=>String(s),dirty:false,
    localStorage:{getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v)},
    window:{addEventListener:(n,cb)=>events[n]=cb},setInterval(cb){events.tick=cb},renderJob(){},refreshJobs:async()=>{},toast:(s,e)=>calls.push({toast:s,error:e}),
    openJob:async id=>calls.push({open:id}),activeStatuses:['queued','reading','optimizing','saving','recovering'],stateNames:{},
    api:async(path,body)=>{calls.push({path,body});if(path.startsWith('/api/episodes')){if(defer)return await new Promise(r=>loaders.push(r));return rows}if(path==='/api/batches')return batchList;if(path==='/api/health')return {optimization_busy:false};if(path==='/api/batch/start')return {id:'new-batch'};if(path==='/api/batch/save/prepare')return {id:'batch-view',ticket:'ticket',project_name:'测试项目',project_id:'b',jobs:body.job_ids.map(id=>({id,episode:1,count:2,pending:2}))};if(path.startsWith('/api/job/'))return {shots:[{no:1,candidate:'完整优化稿',original:'原稿',diff:'+修改内容',state:'draft'}]};return {ok:true}}};
vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/batch.js','utf8'),ctx);
const settle=()=>new Promise(r=>setImmediate(r));
(async()=>{
 await settle();el('#multi-mode').click();await settle();assert(ctx.window.qimaoBatchMode());assert(el('#episode').disabled);assert.equal(el('#episode').required,false);
 el('#episode-range').value='13-16、18、13';el('#apply-range').click();assert.equal(el('#episode-selection-count').textContent,'已选 5 集');assert(!el('#read-button').disabled);
 await ctx.window.startBatchOptimization();let payload=calls.find(x=>x.path==='/api/batch/start').body;assert.deepEqual(Array.from(payload.episodes),[13,14,15,16,18]);assert.equal(payload.concurrency,3);
 el('#episode-range').value='19-21';el('#apply-range').click();assert(calls.some(x=>x.error&&x.toast.includes('21')));assert.equal(el('#episode-selection-count').textContent,'已选 5 集');
 el('#clear-episodes').click();assert(el('#read-button').disabled);await ctx.window.startBatchOptimization();assert.equal(calls.filter(x=>x.path==='/api/batch/start').length,1);
 el('#select-all-episodes').click();assert.equal(el('#episode-selection-count').textContent,'已选 20 集');
 pid='other';events['qimao:project']();await settle();assert.equal(el('#episode-selection-count').textContent,'已选 0 集');
 pid='2278';events['qimao:project']();await settle();assert.equal(el('#episode-selection-count').textContent,'已选 20 集');
 // 快速切换项目时，晚返回的旧集数不能覆盖新项目。
 defer=true;pid='a';events['qimao:project']();pid='b';events['qimao:project']();loaders[1]([{episode_num:8}]);await settle();loaders[0]([{episode_num:2}]);await settle();
 assert(el('#episode-checkboxes').innerHTML.includes('value="8"'));assert(!el('#episode-checkboxes').innerHTML.includes('value="2"'));
 batchList=[{id:'batch-view',project_id:'b',project_name:'测试项目',created:'2026-10-30',concurrency:3,running:false,ready:1,jobs:[{id:'done',episode:1,status:'review',count:2,done:2,save_eligible:true},{id:'failed',episode:2,status:'error',count:3,done:1,failed:1,error:'暂时网络错误'}]}];
 await events.tick();assert.equal(el('#batch-progress-panel').hidden,false);assert(el('#batch-overall').textContent.includes('可检查 1 / 2 集'));assert(el('#batch-job-list').innerHTML.includes('暂时网络错误'));assert.equal(el('#batch-retry').hidden,false);
 assert(!el('#batch-save-open').disabled);assert(el('#batch-save-selection').textContent.includes('已选回填 1 集'));
 await el('#batch-save-open').click();assert(el('#batch-save-dialog').open);assert(el('#batch-save-review-content').innerHTML.includes('完整优化稿'));assert(el('#batch-save-confirm').disabled);
 await el('#batch-save-confirm').click();assert(!calls.some(x=>x.path==='/api/batch/save/confirm'));
 el('#batch-save-reviewed').checked=true;el('#batch-save-reviewed').onchange();assert(!el('#batch-save-confirm').disabled);
 await el('#batch-save-confirm').click();assert(calls.some(x=>x.path==='/api/batch/save/confirm'&&x.body.reviewed===true&&x.body.ticket==='ticket'));
 el('#batch-save-clear').click();assert(el('#batch-save-open').disabled);el('#batch-save-select-all').click();assert(!el('#batch-save-open').disabled);
 batchList[0].jobs[1].count=0;await events.tick();assert(el('#batch-job-list').innerHTML.includes('读取未完成 · 需要继续'));
 batchList[0].jobs[1].status='recovering';await events.tick();assert(el('#batch-job-list').innerHTML.includes('读取暂时失败 · 正在自动重试'));
 batchList[0].jobs[1].status='error';await events.tick();
 batchList[0].jobs[1].status='review';batchList[0].jobs[1].count=3;batchList[0].jobs[1].shot_errors=[{no:2,error:'构图与特写冲突'}];await events.tick();
 assert(el('#batch-job-list').innerHTML.includes('优化未完成 · 需修复'));assert(el('#batch-job-list').innerHTML.includes('片段 02：构图与特写冲突'));assert(!el('#batch-retry').hidden);
 await el('#batch-retry').click();assert(calls.some(x=>x.path==='/api/batch/continue'&&x.body.id==='batch-view'));
 el('#batch-job-list').onclick({target:{closest(){return {dataset:{batchJob:'done'}}}}});assert(calls.some(x=>x.open==='done'));
 el('#single-mode').click();assert.equal(el('#episode').disabled,false);assert.equal(el('#episode').required,true);assert.equal(el('#batch-setup').hidden,true);
 console.log('多集选择、范围校验、实际提交、项目隔离、异步切换及单集兼容通过。');
})().catch(e=>{console.error(e);process.exitCode=1});
