# -*- coding: utf-8 -*-
"""隔离模型返回，生成与内容审查分别模拟；不调用线上模型。"""
import json
import server as app

def rows_from(prompt):
    return json.JSONDecoder().raw_decode(prompt.split('【原正文编号行】\n')[-1])[0]

def reply(prompt,schema):
    rows=rows_from(prompt)
    if schema==app.CONTENT_SCHEMA:
        return {'complete':True,'issues':[],'checks':[{'line':r['line'],'complete':True,'issues':[]} for r in rows]}
    return {'lines':[{'line':r['line'],'text':r['text'].replace('侧面近景，缓慢推近。','从侧面近景起幅，镜头沿原方向缓慢推进，落在既定人物的视线上。')} for r in rows],'review':'将侧面推进的起落幅融入镜头，保留全部原台词和既定站位。'}
