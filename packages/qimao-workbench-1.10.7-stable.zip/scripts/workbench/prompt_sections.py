"""只插入分区标记，不改写原稿；风格文本仍由调用方逐字锁定。"""
import re

CONTINUITY = '人物空间连续性：'
STYLE = '【画风】'
SHOT = re.compile(r'(?im)^[ \t]*(?:c\d+[，,：:\s]|shot[ _-]*\d+\b|镜头\s*[一二三四五六七八九十\d]+|\d+(?:\.\d+)?\s*[s秒]\s*[-—~～至])')
CONT = re.compile(r'(?m)^[ \t]*(?:【人物空间连续性】|人物空间连续性[：:]|空间连续性[：:]|【空间连续性】)')
LOOK = re.compile(r'(?m)^[ \t]*(?:【画风】|【画面风格】|\[画风\]|画风[：:]|视觉风格[：:]|全程锁定[：:]|Masterpiece\b)')

def sections(text):
    if not isinstance(text,str) or not text.strip():raise ValueError('原稿为空，需先读取有效提示词')
    continuity=CONT.search(text);shot=SHOT.search(text)
    start=continuity.start() if continuity else shot.start() if shot else None
    if start is None:raise ValueError('原稿没有可识别的镜头正文，需要核实内容；原稿已保留')
    look=LOOK.search(text,start)
    end=look.start() if look else len(text)
    if end<=start:raise ValueError('画风分区位于正文之前，需要核实内容；原稿已保留')
    pre,body,post=text[:start],text[start:end],text[end:]
    added=[]
    if not body.startswith(CONTINUITY):
        body=CONTINUITY+'\n'+body;added.append(CONTINUITY)
    if not post.startswith(STYLE):
        # 无尾部画风时只补空标题，绝不从其他集复制或发明风格。
        post=('\n' if not look and not text.endswith('\n') else '')+STYLE+'\n'+post
        added.append(STYLE)
    return (pre,body,post),added
