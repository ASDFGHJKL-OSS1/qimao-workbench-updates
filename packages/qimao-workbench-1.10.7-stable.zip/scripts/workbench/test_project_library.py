"""项目目录、删除恢复与运行中保护；临时数据和HTTP服务隔离验证。"""
import copy, http.client, json, tempfile, threading, unittest
from pathlib import Path
from unittest.mock import patch
import server as app
from project_library import ProjectLibrary, LibraryError


class ProjectTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.data=Path(self.temp.name)/'jobs';self.data.mkdir()
        self.library=ProjectLibrary(self.data)
        for ident,pid,source in [('base',1,None),('child',1,'base'),('other',2,None)]:
            j={'id':ident,'project_id':pid,'episode':7,'project_name':'项目'+str(pid),'created':'2026-10-28 10:00:00','updated':'2026-10-28 10:01:00','status':'ready','read_complete':True,'shots':[],'source_job_id':source}
            (self.data/ident).mkdir();(self.data/ident/'job.json').write_text(json.dumps(j,ensure_ascii=False))
            (self.data/ident/'backup.txt').write_text('原始完整备份')
        self.original={str(p.relative_to(self.data)):p.read_bytes() for p in self.data.rglob('*') if p.is_file()}
        self.patches=[patch.object(app,'DATA',self.data),patch.object(app,'runcli',side_effect=AssertionError('禁止访问线上'))]
        for p in self.patches:p.start()
    def tearDown(self):
        for p in reversed(self.patches):p.stop()
        self.temp.cleanup()
    def test_catalog_groups_by_stable_project_identity(self):
        self.library.remember([{'id':1,'name':'项目1'},{'id':3,'name':'尚未读取的项目'}])
        catalog=self.library.catalog(app.job_summary)
        self.assertEqual({p['id']:p['count'] for p in catalog['projects']},{1:2,2:1,3:0})
        self.assertEqual(next(j for j in catalog['jobs'] if j['id']=='child')['source_job_id'],'base')
    def test_delete_parent_keeps_its_revision_and_all_file_bytes(self):
        self.library.change('job','base')
        self.assertEqual({j['id'] for j in self.library.active_jobs()},{'child','other'})
        for name,value in self.original.items():self.assertEqual((self.data/name).read_bytes(),value)
        with self.assertRaises(app.Problem):app.load('base')
        self.assertEqual(app.load('child')['source_job_id'],'base')
    def test_restore_record_survives_new_library_instance(self):
        self.library.change('job','base')
        again=ProjectLibrary(self.data);again.change('job','base',restore=True)
        self.assertEqual(len(again.active_jobs()),3)
        self.assertEqual(app.load('base')['id'],'base')
    def test_project_restore_keeps_previously_deleted_record_in_trash(self):
        self.library.change('job','base');self.library.change('project','1')
        catalog=self.library.catalog(app.job_summary)
        self.assertEqual([j['id'] for j in catalog['jobs']],['other'])
        self.assertEqual([(t['type'],t['id']) for t in catalog['trash']],[('project','1')])
        with self.assertRaises(LibraryError):self.library.change('job','base',restore=True)
        self.library.change('project','1',restore=True)
        self.assertEqual({j['id'] for j in self.library.active_jobs()},{'child','other'})
        self.assertEqual(self.library.catalog(app.job_summary)['trash'][0]['id'],'base')
    def test_invalid_identity_does_not_change_catalog(self):
        for kind,identity in [('job','../base'),('project','nothing'),('job','missing')]:
            with self.assertRaises(LibraryError):self.library.change(kind,identity)
        self.assertFalse(self.library.path.exists())
    def test_deleted_jobs_do_not_reappear_in_active_context_or_notices(self):
        self.library.change('project',1)
        with patch.object(app,'skill_context',return_value='测试技能'):
            self.assertEqual([j['id'] for j in app.assistant_context({})['records']],['other'])
        self.assertTrue(all(n['job_id']=='other' for n in app.current_automatic_notices()))

    def request(self,path,body=None):
        connection=http.client.HTTPConnection('127.0.0.1',self.port,timeout=5)
        headers={'X-Workbench-Token':app.TOKEN,'Content-Type':'application/json'}
        connection.request('POST' if body is not None else 'GET',path,json.dumps(body) if body is not None else None,headers)
        response=connection.getresponse();result=(response.status,json.loads(response.read()));connection.close();return result
    def test_http_delete_restore_and_running_task_guard(self):
        server=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler);self.port=server.server_port
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            with patch.object(app,'PORT',self.port):
                app.BUSY.acquire()
                try:self.assertEqual(self.request('/api/library/delete',{'type':'job','id':'base'})[0],400)
                finally:app.BUSY.release()
                self.assertEqual(len(self.request('/api/library')[1]['jobs']),3)
                self.assertEqual(self.request('/api/library/delete',{'type':'job','id':'base'})[0],200)
                self.assertEqual(len(self.request('/api/jobs')[1]),2)
                self.assertEqual(self.request('/api/job/base')[0],400)
                self.assertEqual(self.request('/api/library/restore',{'type':'job','id':'base'})[0],200)
                self.assertEqual(self.request('/api/job/base')[0],200)
        finally:server.shutdown();server.server_close();thread.join()

if __name__=='__main__':unittest.main(verbosity=2)
