"""Detached code-only installer. Keeps data in place and rolls back on health failure."""
import json, os, py_compile, shutil, subprocess, sys, tempfile, time, uuid, urllib.request, zipfile
from pathlib import Path
from update_protocol import inspect_package, write_json

def apply_files(skill,stage,release,backup):
    """Every changed file is journalled before replacement; no data path is accepted."""
    journal=[]
    for name,spec in release['files'].items():
        dest=skill/name
        if dest.is_symlink() or any(p.is_symlink() for p in dest.parents if p==skill or skill in p.parents):raise RuntimeError('安装路径包含符号链接')
        existed=dest.exists();old=backup/'files'/name
        if existed:old.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dest,old)
        journal.append({'name':name,'existed':existed});write_json(backup/'journal.json',journal)
        dest.parent.mkdir(parents=True,exist_ok=True)
        temp=dest.with_name(dest.name+'.update-tmp');shutil.copyfile(stage/name,temp);temp.chmod(spec['mode']);os.replace(temp,dest)
    return journal

def restore_files(skill,backup):
    journal=json.loads((backup/'journal.json').read_text()) if (backup/'journal.json').exists() else []
    for item in reversed(journal):
        dest=skill/item['name']
        if item['existed']:
            temp=dest.with_name(dest.name+'.restore-tmp');shutil.copy2(backup/'files'/item['name'],temp);os.replace(temp,dest)
        else:dest.unlink(missing_ok=True)

def run(request,restart=None,healthy=None):
    root=Path(request['root']);skill=root.parent.parent;data=root/'data/updates'
    key=(root/'update-public.pem').read_text()
    backup=data/'backups'/(time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8])
    def state(**kw):
        obj=json.loads((data/'state.json').read_text());obj.update(kw,updated_at=time.time());write_json(data/'state.json',obj)
    def default_restart():
        p=subprocess.run(['launchctl','kickstart','-k',f'gui/{os.getuid()}/com.local.qimao-prompt-workbench'],capture_output=True,timeout=20)
        if p.returncode:raise RuntimeError('工作台重启失败')
    def default_healthy(expected):
        for _ in range(30):
            try:
                with urllib.request.urlopen('http://127.0.0.1:4197/api/health',timeout=2) as r:h=json.load(r)
                if h.get('ok') and h.get('version')==expected:return True
            except Exception:pass
            time.sleep(1)
        return False
    restart=restart or default_restart;healthy=healthy or default_healthy
    previous=json.loads((root/'version.json').read_text())['version']
    try:
        backup.mkdir(parents=True,exist_ok=False)
        state(backup=str(backup))
        release=inspect_package(request['package'],key,request['manifest'])
        with tempfile.TemporaryDirectory(prefix='qimao-stage-') as folder:
            stage=Path(folder)
            with zipfile.ZipFile(request['package']) as z:z.extractall(stage)
            for p in stage.rglob('*.py'):py_compile.compile(str(p),doraise=True)
            state(message='程序备份已建立，正在安装文件',progress=40,backup=str(backup))
            apply_files(skill,stage,release,backup)
        state(phase='restarting',message='安装完成，正在重启并检查服务',progress=85)
        restart()
        if not healthy(release['version']):raise RuntimeError('新版本服务未通过启动检查')
        history=json.loads((data/'history.json').read_text()) if (data/'history.json').exists() else []
        history.insert(0,{k:release[k] for k in ('version','notes','published_at','channel')});write_json(data/'history.json',history[:100])
        state(phase='complete',message=f'已更新到 v{release["version"]}',progress=100,error='',manifest=None,package=None)
    except Exception as e:
        state(phase='rolling_back',message='更新失败，正在恢复原版本',error=str(e),progress=50)
        restore_files(skill,backup)
        try:
            restart();ok=healthy(previous)
            state(phase='rolled_back' if ok else 'error',message='更新失败，已恢复原版本' if ok else '原程序已恢复，请重新打开工作台',progress=0,error=str(e),backup=str(backup))
        except Exception:state(phase='error',message='原程序已恢复，请重新打开工作台',error=str(e),backup=str(backup))
    finally:(data/'install.lock').unlink(missing_ok=True)

def recover(request):
    root=Path(request['root']);data=root/'data/updates';state=json.loads((data/'state.json').read_text())
    backup=Path(state['backup']) if state.get('backup') else None
    try:
        if backup:
            if backup.parent.resolve()!=(data/'backups').resolve():raise RuntimeError('恢复路径无效')
            restore_files(root.parent.parent,backup)
        state.update(phase='rolled_back',message='安装进程中断，已恢复原程序',error='请重新检查更新',progress=0)
        write_json(data/'state.json',state)
        subprocess.run(['launchctl','kickstart','-k',f'gui/{os.getuid()}/com.local.qimao-prompt-workbench'],capture_output=True,timeout=20)
    finally:(data/'install.lock').unlink(missing_ok=True)

if __name__=='__main__':
    if sys.argv[1]=='--recover':recover(json.loads(Path(sys.argv[2]).read_text()))
    else:run(json.loads(Path(sys.argv[1]).read_text()))
