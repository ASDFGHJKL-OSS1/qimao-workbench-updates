"""局部重优化的版本隔离、选段边界与写入冲突测试，不访问真实平台。"""
import copy,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import server as app
from test_workbench import fixture,TEXT
from test_prompt_helpers import reply

def source_fixture(saved=True):
    j=fixture();j.update(id='source',read_complete=True,status='complete' if saved else 'review',project_name='测试项目',created='2026-10-28 17:00:00')
    first=j['shots'][0];j['shots']=[];j['order']=[]
    for no in range(1,4):
        s=copy.deepcopy(first);s.update(id=str(10+no),no=no,state='saved' if saved else 'draft');s['snapshot'].update(id=s['id'],shot_no=no)
        if saved:s['saved_revision']='v2'
        j['shots'].append(s);j['order'].append((s['id'],no))
    return j
class RevisionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.orig=app.DATA;app.DATA=Path(self.temp.name)
    def tearDown(self):app.DATA=self.orig;self.temp.cleanup()
    def build(self,source=None,numbers=None,mutate=None,postfill=False):
        source=source or source_fixture();app.store(source);original=copy.deepcopy(app.load(source['id']))
        create=app.postfill_revision_job if postfill else app.revision_job
        j=create(source,numbers or [2],'片段02先保持戒备，再以呼吸慢慢放松，保留台词和画风。')
        def read(job):
            fresh=copy.deepcopy(source)
            for s in fresh['shots']:
                if s['state']=='saved':
                    s['snapshot']['prompt_text']=s['candidate'];s['snapshot']['edit_revision']=s['saved_revision']
                s['original']=s['snapshot']['prompt_text'];s['candidate']='';s['state']='pending'
            if mutate:mutate(fresh)
            for key in ['context','order','shots','read_complete']:job[key]=fresh[key]
            app.store(job)
        calls=[]
        def model(prompt,jid,**kw):
            if kw.get('schema')==app.SCHEMA:calls.append(prompt)
            return reply(prompt,kw.get('schema'))
        with patch.object(app,'read_episode',read),patch.object(app,'skill_context',return_value='测试技能'),patch.object(app.subprocess,'run',return_value=SimpleNamespace(returncode=0)),patch.object(app,'model_json',model):app.revise_episode(j)
        return j,original,calls
    def platform(self,j,change_no=None,uncertain=False):
        current={s['no']:copy.deepcopy(s['snapshot']) for s in j['shots']};writes=[]
        if change_no:current[change_no]['edit_revision']='external'
        def cli(args):
            no=int(args[args.index('--shot')+1])
            if args[:2]==['shot','get']:return {'shot':copy.deepcopy(current[no])}
            if args[:3]==['shot','model','list']:return {'items':[]}
            if args[:3]==['shot','prompt','update']:
                writes.append(no);self.assertEqual(args[args.index('--revision')+1],current[no]['edit_revision'])
                current[no]['prompt_text']=Path(args[args.index('--file')+1]).read_text();current[no]['edit_revision']='saved-'+str(no)
                if uncertain:raise app.Problem('写入响应丢失')
                return {'shot':copy.deepcopy(current[no])}
            raise AssertionError(args)
        return current,writes,cli
    def save(self,j,cli):
        with patch.object(app,'runcli',cli),patch.object(app,'capture_context',return_value=j['context']),patch.object(app,'paged',return_value=[{'id':sid,'shot_no':no} for sid,no in j['order']]):app.save_episode(j)
    def test_completed_episode_targets_only_and_archives_source(self):
        j,source,calls=self.build(numbers=[3,1]);self.assertEqual(len(calls),2);self.assertEqual(j['target_nos'],[1,3]);self.assertEqual(app.load('source'),source)
        self.assertEqual(j['shots'][1]['state'],'unchanged');self.assertEqual(j['shots'][1]['candidate'],'')
        self.assertTrue((app.jobpath(j['id'])/'versions/上一轮任务.json').is_file())
        self.assertTrue(all('片段02先保持戒备' in p for p in calls))
        self.assertTrue(all(app.validate(s,s['candidate'])['ok'] for s in app.target_shots(j)))
    def test_unsaved_candidate_is_preserved_as_previous_version(self):
        j,source,_=self.build(source_fixture(saved=False));s=j['shots'][1]
        self.assertEqual(s['revision_base'],source['shots'][1]['candidate']);self.assertTrue(app.content_approved(s,s['candidate']))
        self.assertFalse(app.validate(s,TEXT)['ok']);self.assertIn('上一版',app.decorate(j)['shots'][1]['revision_diff'])
    def test_local_draft_on_stale_platform_stops(self):
        with self.assertRaisesRegex(app.Problem,'旧平台版本'):
            self.build(source_fixture(saved=False),mutate=lambda fresh:fresh['shots'][1]['snapshot'].update(edit_revision='external'))
    def test_only_selected_saved_with_long_unselected_source(self):
        j,_,_=self.build();s=j['shots'][0];s['original']=s['original'].replace('【画风】','字'*7000+'【画风】');s['snapshot']['prompt_text']=s['original']
        current,writes,cli=self.platform(j);before=copy.deepcopy(current);self.save(j,cli)
        self.assertEqual(writes,[2]);self.assertEqual(current[1],before[1]);self.assertEqual(current[3],before[3]);self.assertEqual(j['status'],'complete')
    def test_unselected_external_change_blocks_all_writes(self):
        j,_,_=self.build();_,writes,cli=self.platform(j,change_no=1)
        with self.assertRaisesRegex(app.Problem,'版本、内容或配置'):self.save(j,cli)
        self.assertEqual(writes,[])
    def test_selected_version_change_blocks_all_writes(self):
        j,_,_=self.build();_,writes,cli=self.platform(j,change_no=2)
        with self.assertRaises(app.Problem):self.save(j,cli)
        self.assertEqual(writes,[])
    def test_uncertain_selected_write_recovers_without_duplicate(self):
        j,_,_=self.build();_,writes,cli=self.platform(j,uncertain=True)
        with self.assertRaisesRegex(app.Problem,'响应丢失'):self.save(j,cli)
        self.save(j,cli);self.assertEqual(writes,[2]);self.assertEqual(j['status'],'complete')
    def test_input_validation_and_required_ideas(self):
        source=source_fixture()
        for numbers,ideas in [([], '想法'),([999],'想法'),([True],'想法'),([1,1],'想法'),([1],''),([1],'字'*5001)]:
            with self.assertRaises(app.Problem):app.revision_job(source,numbers,ideas)
    def test_long_locked_style_is_preserved_and_optimized(self):
        source=source_fixture();s=source['shots'][1];s['candidate']=s['candidate'].replace('核心风格：','核心风格：'+'字'*7000)
        j,_,calls=self.build(source);result=j['shots'][1];self.assertEqual(len(calls),1);self.assertEqual(result['state'],'draft');self.assertGreater(len(result['candidate']),7000);self.assertEqual(app.split_style(result['revision_base'])[::2],app.split_style(result['candidate'])[::2]);self.assertTrue(app.validate(result,result['candidate'])['ok'])
    def test_reoptimization_can_be_repeated_after_completion(self):
        j,_,_=self.build();current,_,cli=self.platform(j);self.save(j,cli);app.store(j)
        later=app.revision_job(j,[2],'进一步加强呼吸层次');self.assertNotEqual(later['id'],j['id']);self.assertEqual(later['source_job_id'],j['id'])
        self.assertEqual(current[2]['prompt_text'],j['shots'][1]['candidate'])
    def test_step05_rejects_not_completed_history_and_multiple_selection(self):
        for status in ('ready','review','reading','optimizing','saving','error','stopped','history'):
            source=source_fixture();source['status']=status
            with self.assertRaisesRegex(app.Problem,'01—04'):app.postfill_revision_job(source,[2],'调整朝向')
        source=source_fixture();source['historical']=True
        with self.assertRaises(app.Problem):app.postfill_revision_job(source,[2],'调整朝向')
        source=source_fixture()
        with self.assertRaisesRegex(app.Problem,'一个片段'):app.postfill_revision_job(source,[1,2],'调整朝向')
        source['shots'][1]['state']='draft'
        with self.assertRaisesRegex(app.Problem,'已经回填'):app.postfill_revision_job(source,[2],'调整朝向')
    def test_step05_only_optimizes_and_saves_one_then_can_repeat(self):
        j,source,calls=self.build(postfill=True)
        self.assertEqual(j['workflow'],'postfill_single');self.assertEqual(len(calls),1)
        self.assertEqual(j['target_nos'],[2]);self.assertEqual(app.job_summary(j)['count'],1)
        current,writes,cli=self.platform(j);before=copy.deepcopy(current);self.save(j,cli)
        self.assertEqual(writes,[2]);self.assertEqual(current[1],before[1]);self.assertEqual(current[3],before[3])
        self.assertEqual(app.load('source'),source)
        again=app.postfill_revision_job(j,[2],'再调整这一段');self.assertEqual(again['source_job_id'],j['id'])
if __name__=='__main__':unittest.main(verbosity=2)
