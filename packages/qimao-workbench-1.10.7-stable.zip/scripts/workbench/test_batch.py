"""批量并发、独立断点与授权保护。模型、CLI和所有数据均隔离。"""
import copy,json,tempfile,threading,time,unittest,urllib.request,urllib.error
from pathlib import Path
from unittest.mock import patch
from http.server import ThreadingHTTPServer
import server as app
from test_workbench import fixture
from auto_recovery import recoverable_stage

class BatchTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.old=app.DATA;app.DATA=Path(self.temp.name)/'jobs';app.DATA.mkdir()
        self.dependencies=patch.object(app,'runcli',return_value={'items':[{'episode_num':n} for n in range(1,8)]});self.dependencies.start()
    def tearDown(self):
        self.assertFalse(app.BUSY.locked());app.CANCEL.clear();self.dependencies.stop();app.DATA=self.old;self.temp.cleanup()
    def job(self,ep):
        j=fixture();j.update(id='batch-test-'+str(ep),episode=ep,status='queued',read_complete=True,batch_id='batch-one',batch_concurrency=2,created='2026-10-30 16:00:00',optimization_brief='加强情绪')
        return j
    def wait(self):
        deadline=time.monotonic()+5
        while app.BUSY.locked() and time.monotonic()<deadline:time.sleep(.01)
        self.assertFalse(app.BUSY.locked(),'批次未正常释放占用')
    def test_parallel_workers_bounded_and_distinct_episode_contexts(self):
        rows=[self.job(n) for n in range(1,6)];lock=threading.Lock();entered=threading.Barrier(2);running=0;peak=0;seen=[]
        def optimize(j):
            nonlocal running,peak
            with lock:running+=1;peak=max(peak,running);seen.append((j['episode'],j['optimization_brief'],j['id']))
            if j['episode']<=2:entered.wait(2)
            time.sleep(.015);j['status']='review'
            with lock:running-=1
        with patch.object(app,'optimize',side_effect=optimize):
            app.background_batch(rows);self.wait()
        self.assertEqual(peak,2);self.assertEqual(len(seen),5);self.assertEqual(len({x[2] for x in seen}),5)
        self.assertTrue(all(x[1]=='加强情绪' for x in seen));self.assertTrue(all(app.load(j['id'])['status']=='review' for j in rows))
    def test_one_episode_failure_does_not_abort_others_or_authorize_writes(self):
        rows=[self.job(n) for n in (1,2,3)]
        def optimize(j):
            if j['episode']==2:raise app.Problem('登录失效')
            j['status']='review'
        with patch.object(app,'optimize',side_effect=optimize),patch.object(app,'save_episode') as save:
            app.background_batch(rows);self.wait();save.assert_not_called()
        self.assertEqual([app.load(j['id'])['status'] for j in rows],['review','error','review'])
        self.assertTrue(all(not app.load(j['id'])['recovery']['save_authorized'] for j in rows))
    def test_resume_does_not_read_again_or_replace_finished_candidates(self):
        j=self.job(1);original=copy.deepcopy(j['shots']);j['recovery']={'enabled':True}
        with patch.object(app,'read_episode') as read,patch.object(app,'optimize') as optimize:
            app.batch_episode(j);read.assert_not_called();optimize.assert_called_once_with(j)
        self.assertEqual(j['shots'],original)
    def test_read_then_optimize_uses_saved_brief(self):
        j=self.job(1);j.pop('read_complete');calls=[]
        def read(j):calls.append('read');j['read_complete']=True;j['status']='ready'
        def optimize(j):calls.append('optimize');self.assertEqual(j['optimization_brief'],'加强情绪')
        with patch.object(app,'read_episode',side_effect=read),patch.object(app,'optimize',side_effect=optimize):app.batch_episode(j)
        self.assertEqual(calls,['read','optimize'])
    def test_cancel_waiting_and_running_children_without_touching_finished(self):
        rows=[self.job(n) for n in (1,2,3,4)];started=threading.Event();finish=threading.Event();seen=[]
        def optimize(j):started.set();finish.wait(2);seen.append(j['episode']);j['status']='review'
        with patch.object(app,'optimize',side_effect=optimize):
            app.background_batch(rows);self.assertTrue(started.wait(2))
            with app.STATE_LOCK:
                app.cancel_job(app.load(rows[2]['id']));app.cancel_job(app.load(rows[3]['id']))
            finish.set();self.wait()
        self.assertEqual(sorted(seen),[1,2]);self.assertEqual([app.load(j['id'])['status'] for j in rows[2:]],['stopped','stopped'])
        finished=app.load(rows[0]['id']);app.cancel_job(finished);self.assertEqual(app.load(finished['id'])['status'],'review')
    def test_restart_restores_batch_concurrently_and_skips_user_stop(self):
        for n in (1,2,3):
            j=self.job(n);j.update(status='optimizing',recovery={'enabled':True,'action':'batch_episode','user_stopped':n==3});app.store(j)
        dispatched=[]
        def launch(rows,resume=False):
            dispatched.append(([j['episode'] for j in rows],resume))
            for j in rows:j['status']='review';app.store(j)
        with patch.object(app,'background_batch',side_effect=launch):app.recover_interrupted_jobs()
        self.assertEqual(len(dispatched),1);self.assertEqual(set(dispatched[0][0]),{1,2});self.assertTrue(dispatched[0][1])
    def test_continue_ignores_successful_review_and_completed_jobs(self):
        for n,status in [(1,'review'),(2,'complete'),(3,'stopped'),(4,'review')]:
            j=self.job(n);j['status']=status
            if n==4:j['shots'][0]['state']='failed'
            app.store(j)
        with patch.object(app,'background_batch') as launch:
            app.continue_batch('batch-one');self.assertEqual([j['episode'] for j in launch.call_args.args[0]],[3,4])
    def test_start_validates_available_episodes_deduplicates_and_sorts(self):
        with patch.object(app,'background_batch') as launch:
            result=app.create_batch({'project':'2278','episodes':[3,1,3],'optimization_brief':'  本批要求  ','concurrency':2})
        rows=launch.call_args.args[0];self.assertEqual([j['episode'] for j in rows],[1,3]);self.assertEqual(len(set(result['job_ids'])),2)
        self.assertTrue(all(j['optimization_brief']=='本批要求' and j['batch_id']==result['id'] for j in rows))
        for body in [{'episodes':[]},{'episodes':[True]},{'episodes':['1']},{'episodes':[8]},{'episodes':[1],'concurrency':4},{'episodes':[1],'optimization_brief':'a'*5001}]:
            with self.subTest(body=body),self.assertRaises(app.Problem),patch.object(app,'background_batch') as launch:
                app.create_batch({'project':'2278',**body})
            launch.assert_not_called()
    def test_busy_rejection_leaves_no_phantom_jobs(self):
        app.BUSY.acquire()
        try:
            with self.assertRaises(app.Problem):app.create_batch({'project':'2278','episodes':[1,2]})
            self.assertEqual(list(app.DATA.iterdir()),[])
        finally:app.BUSY.release()
    def test_missing_batch_id_cannot_match_or_modify_ordinary_jobs(self):
        j=fixture();j['status']='ready';app.store(j);before=app.load(j['id'])
        for bid in (None,'',1,[],{}):
            with self.subTest(bid=bid),self.assertRaises(app.Problem):app.batch_jobs(bid)
        self.assertEqual(app.load(j['id']),before)
    def test_summary_distinguishes_partial_failure_and_keeps_project_isolated(self):
        for n in (1,2):
            j=self.job(n);j['status']='review'
            if n==2:j['shots'][0]['state']='failed'
            app.store(j)
        s=app.batch_summaries()[0];self.assertEqual(s['ready'],1);self.assertEqual(s['project_id'],1)
        self.assertEqual(s['jobs'][1]['failed'],1);self.assertFalse(s['running'])
    def test_http_start_progress_cancel_and_continue_contract(self):
        http=ThreadingHTTPServer(('127.0.0.1',0),app.Handler);thread=threading.Thread(target=http.serve_forever,daemon=True);thread.start()
        port=http.server_port
        def request(path,body=None):
            data=None if body is None else json.dumps(body).encode()
            req=urllib.request.Request('http://127.0.0.1:'+str(port)+path,data=data,headers={'X-Workbench-Token':app.TOKEN,'Content-Type':'application/json'})
            with urllib.request.urlopen(req,timeout=3) as r:return json.load(r)
        def launch(rows):
            for j in rows:app.initialize_run(j,app.batch_episode)
        try:
            with patch.object(app,'PORT',port),patch.object(app,'background_batch',side_effect=launch):
                result=request('/api/batch/start',{'project':'2278','episodes':[1,2]})
                s=request('/api/batches')[0];self.assertEqual(s['id'],result['id']);self.assertEqual(len(s['jobs']),2)
                request('/api/batch/cancel',{'id':result['id']})
                self.assertTrue(all(j['status']=='stopped' for j in request('/api/batches')[0]['jobs']))
                request('/api/batch/continue',{'id':result['id']});self.assertTrue(request('/api/batches')[0]['running'])
                with self.assertRaises(urllib.error.HTTPError):request('/api/batch/start',{'project':'2278','episodes':[8]})
        finally:http.shutdown();http.server_close();thread.join()

if __name__=='__main__':unittest.main()
