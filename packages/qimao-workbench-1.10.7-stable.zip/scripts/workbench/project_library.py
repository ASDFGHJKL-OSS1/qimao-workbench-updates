"""本地项目目录与可恢复删除；不修改七猫平台或提示词文件。"""
import json, os, re, tempfile, threading, time
from pathlib import Path
_LOCK = threading.RLock()


class LibraryError(Exception):
    pass


class ProjectLibrary:
    def __init__(self, jobs_dir):
        self.jobs_dir = Path(jobs_dir)
        self.path = self.jobs_dir.parent / 'project-library.json'
        self.lock = _LOCK

    def state(self):
        if self.path.exists():
            return json.loads(self.path.read_text())
        return {'projects': {}, 'hidden_projects': {}, 'deleted_jobs': {}}

    def save(self, state):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(dir=self.path.parent, prefix='.projects-', suffix='.tmp')
        try:
            with os.fdopen(fd, 'w') as f:
                json.dump(state, f, ensure_ascii=False, indent=2)
            os.replace(name, self.path)
        finally:
            if os.path.exists(name):
                os.unlink(name)

    def all_jobs(self):
        return [json.loads(p.read_text()) for p in self.jobs_dir.glob('*/job.json')]

    def visible(self, job, state=None):
        state = self.state() if state is None else state
        return job['id'] not in state['deleted_jobs'] and str(job.get('project_id')) not in state['hidden_projects']

    def active_jobs(self):
        with self.lock:
            state = self.state()
            return [j for j in self.all_jobs() if self.visible(j, state)]

    def remember(self, projects):
        with self.lock:
            state = self.state()
            for p in projects:
                pid = str(p.get('id', ''))
                if pid.isdigit():
                    state['projects'][pid] = {'id': int(pid), 'name': p.get('name') or p.get('title') or f'七猫项目 {pid}'}
            self.save(state)

    def catalog(self, summary):
        with self.lock:
            state = self.state()
            all_jobs = self.all_jobs()
            projects = dict(state['projects'])
            for j in sorted(all_jobs, key=lambda j:j.get('updated', '')):
                pid = str(j['project_id'])
                projects[pid] = {'id': j['project_id'], 'name': j.get('project_name') or projects.get(pid, {}).get('name') or f'七猫项目 {pid}'}
            active = [j for j in all_jobs if self.visible(j, state)]
            items = []
            for pid, p in projects.items():
                if pid in state['hidden_projects']:
                    continue
                rows = [j for j in active if str(j['project_id']) == pid]
                items.append(p | {'episodes': sorted(set(j['episode'] for j in rows)), 'count': len(rows), 'updated': max((j.get('updated', j.get('created', '')) for j in rows), default='')})
            trash = []
            for pid, deleted_at in state['hidden_projects'].items():
                if pid in projects:
                    trash.append({'type': 'project', 'id': pid, 'name': projects[pid]['name'], 'deleted_at': deleted_at,
                                  'count': sum(str(j['project_id']) == pid for j in all_jobs)})
            for j in all_jobs:
                if j['id'] in state['deleted_jobs'] and str(j['project_id']) not in state['hidden_projects']:
                    trash.append({'type': 'job', 'id': j['id'], 'name': f'{j.get("project_name") or "七猫项目"} · 第{j["episode"]}集',
                                  'deleted_at': state['deleted_jobs'][j['id']], 'kind': j.get('kind'), 'created': j.get('created')})
            return {'projects': sorted(items, key=lambda p:(p['updated'], p['id']), reverse=True),
                    'jobs': sorted([summary(j) for j in active], key=lambda j:j.get('updated', ''), reverse=True),
                    'trash': sorted(trash, key=lambda x:x['deleted_at'], reverse=True)}

    def change(self, kind, identity, restore=False):
        identity = str(identity)
        if kind not in ('project', 'job') or not re.fullmatch(r'[a-zA-Z0-9_-]{1,80}', identity):
            raise LibraryError('项目或记录编号无效')
        with self.lock:
            state = self.state()
            jobs = self.all_jobs()
            if kind == 'project':
                if not identity.isdigit() or not (identity in state['projects'] or any(str(j['project_id']) == identity for j in jobs)):
                    raise LibraryError('没有找到这个项目')
                table = state['hidden_projects']
            else:
                j = next((j for j in jobs if j['id'] == identity), None)
                if not j:
                    raise LibraryError('没有找到这个记录')
                if str(j['project_id']) in state['hidden_projects']:
                    raise LibraryError('请先恢复所属项目')
                table = state['deleted_jobs']
            if restore:
                table.pop(identity, None)
            else:
                table.setdefault(identity, time.strftime('%Y-%m-%d %H:%M:%S'))
            self.save(state)
            return {'ok': True, 'type': kind, 'id': identity, 'restored': restore}
