"""从已保存的真实任务状态生成主动提醒，不调用模型或写入平台。"""
import hashlib,json
from datetime import datetime
from zoneinfo import ZoneInfo

def automatic_notices(jobs):
    latest={}
    for job in sorted(jobs,key=lambda j:(j.get('created',''),j.get('updated','')),reverse=True):
        if job.get('historical'):continue
        latest.setdefault((job.get('project_id'),job.get('episode')),job)
    notices=[]
    for j in latest.values():
        status=j.get('status');shots=j.get('shots',[])
        if status in ('reading','queued','optimizing','saving') or not shots:continue
        targets=[s for s in shots if j.get('kind')!='revision' or s['no'] in j.get('target_nos',[])]
        scope=f'第{j["episode"]}集'
        bad=[s for s in targets if s.get('state') in ('failed','blocked')]
        kind='';text='';action='查看任务'
        if status in ('error','stopped'):
            kind=status;text=f'{scope}{"任务已停止" if status=="stopped" else "任务需要处理"}：{j.get("error") or "请查看任务动态，已完成内容仍保留。"}'
        elif bad:
            kind='blocked';text=scope+'片段'+'、'.join(f'{s["no"]:02}' for s in bad)+'需要处理：'+str(bad[0].get('error') or '优化未完成，请检查后重试。')
        elif status=='review':
            drafts=[s for s in targets if s.get('candidate') and s.get('state')=='draft']
            if drafts:kind='review';text=f'{scope}{len(drafts)}个片段已优化，等待你检查完整稿与修改对比，再确认回填。';action='检查优化稿'
        elif status=='complete':
            kind='complete';text=f'{scope}{"所选片段" if j.get("kind")=="revision" else "整集"}已回填并重读核验完成，可以检查实际生成效果。';action='查看回填结果'
        elif status=='ready' and j.get('read_complete'):
            kind='ready';text=f'{scope}{len(shots)}个片段已完整读取并备份，可以开始优化。';action='查看片段'
        if not text:continue
        updated=j.get('updated') or j.get('created','')
        signature=[j['id'],kind,text,j.get('optimization_run_id','')]
        key='auto-'+hashlib.sha256(json.dumps(signature,ensure_ascii=False).encode()).hexdigest()[:24]
        try:created=datetime.strptime(updated,'%Y-%m-%d %H:%M:%S').replace(tzinfo=ZoneInfo('Asia/Shanghai')).timestamp()
        except ValueError:created=0
        notices.append({'id':key,'kind':kind,'text':text,'job_id':j['id'],'episode':j['episode'],'action':action,'created':created,'automatic':True})
    return sorted(notices,key=lambda n:n['created'],reverse=True)[:20]
