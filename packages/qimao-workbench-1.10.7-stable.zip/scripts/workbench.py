#!/usr/bin/env python3
"""技能内的本地工作台服务入口；不调用浏览器、不修改平台内容。"""
import argparse,json,os,plistlib,subprocess,sys,time,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent/'workbench'
URL='http://127.0.0.1:4197'
LABEL='com.local.qimao-prompt-workbench'
DOMAIN=f'gui/{os.getuid()}'
SERVICE=f'{DOMAIN}/{LABEL}'
PLIST=Path.home()/'Library/LaunchAgents'/f'{LABEL}.plist'

def health():
    try:
        with urllib.request.urlopen(URL+'/api/health',timeout=2) as r:d=json.load(r)
        if d.get('name')!='七猫专属提示词优化':return {'ok':False,'error':'端口4197由其他服务占用'}
        return {'ok':bool(d.get('ok')),'name':d.get('name'),'version':d.get('version'),'busy':bool(d.get('busy')),'url':URL,'root':str(ROOT)}
    except Exception:return {'ok':False,'url':URL,'root':str(ROOT),'error':'工作台尚未启动'}

def command(*args):return subprocess.run(['launchctl',*args],capture_output=True,text=True,timeout=15)

def start():
    current=health()
    if current.get('ok'):return current
    if current.get('error')=='端口4197由其他服务占用':return current
    if not (ROOT/'server.py').is_file():raise RuntimeError('技能内工作台文件缺失')
    loaded=command('print',SERVICE).returncode==0
    desired={'Label':LABEL,'ProgramArguments':['/usr/bin/python3',str(ROOT/'server.py')],'WorkingDirectory':str(ROOT),'RunAtLoad':True,'KeepAlive':True,'ThrottleInterval':8,'StandardOutPath':str(ROOT/'data/server.log'),'StandardErrorPath':str(ROOT/'data/server.log'),'EnvironmentVariables':{'PATH':str(Path.home()/'.local/bin')+':/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'}}
    (ROOT/'data').mkdir(exist_ok=True)
    previous=plistlib.loads(PLIST.read_bytes()) if PLIST.exists() else None
    if loaded and previous!=desired:
        result=command('bootout',SERVICE)
        if result.returncode:raise RuntimeError('旧启动项未停止，未覆盖配置')
        loaded=False
    if previous!=desired:
        PLIST.parent.mkdir(parents=True,exist_ok=True)
        PLIST.write_bytes(plistlib.dumps(desired))
    if not loaded:
        result=command('bootstrap',DOMAIN,str(PLIST))
        if result.returncode:raise RuntimeError('无法加载工作台后台服务：'+result.stderr.strip())
    else:command('kickstart',SERVICE)
    for _ in range(40):
        current=health()
        if current.get('ok'):return current
        time.sleep(.2)
    raise RuntimeError('启动后仍未连接，请查看 '+str(ROOT/'data/server.log'))

def main():
    parser=argparse.ArgumentParser(description='七猫专属提示词优化');parser.add_argument('action',choices=['start','status','stop'],nargs='?',default='start');args=parser.parse_args()
    try:
        if args.action=='start':result=start()
        elif args.action=='status':result=health()
        else:
            current=health()
            if current.get('busy'):raise RuntimeError('当前仍有任务运行，请先在工作台停止任务')
            stopped=command('bootout',SERVICE)
            result={'ok':stopped.returncode==0 or not health().get('ok'),'status':'stopped'}
        print(json.dumps(result,ensure_ascii=False));return 0 if result.get('ok') else 1
    except Exception as e:print(json.dumps({'ok':False,'error':str(e)},ensure_ascii=False));return 1
if __name__=='__main__':sys.exit(main())
