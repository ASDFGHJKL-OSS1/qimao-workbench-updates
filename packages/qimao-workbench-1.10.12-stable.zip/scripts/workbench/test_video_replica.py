"""Manual video: real non-destructive editing, immutable evidence and isolated HTTP."""
import copy,hashlib,http.client,io,json,tempfile,threading,time,unittest
from pathlib import Path
from http.server import ThreadingHTTPServer
from unittest.mock import patch
import video_replica as video
import server as app
from test_workbench import fixture
from test_prompt_helpers import reply

class RangeTests(unittest.TestCase):
 def test_subtracted_middle_maps_to_original(self):
  ranges=video.normalize_ranges([[0,2],[5,8]],10)
  self.assertEqual(video.source_mapping(1,4,ranges),[[1,2],[5,7]])
  self.assertEqual(video.source_mapping(2,5,ranges),[[5,8]])
 def test_invalid_ranges(self):
  for ranges in ([],[[False,2]],[[0,float('nan')]],[[0,3],[2,4]],[[0,61]],[[0,.01]],[[0,11]],[[1,0]],[[0,1]]*21):
   with self.subTest(ranges=ranges),self.assertRaises(video.VideoError):video.normalize_ranges(ranges,100 if ranges==[[0,61]] else 10)
 def test_only_public_detail_links(self):
  with tempfile.TemporaryDirectory() as d:
   lib=video.VideoLibrary(d)
   for url in ('http://www.promptmart.cn/prompt/1','https://evil.test/prompt/1','https://www.promptmart.cn@evil.test/prompt/1','https://www.promptmart.cn/c/texiao','https://www.promptmart.cn/prompt/1?redirect=evil','file:///etc/passwd'):
    with self.assertRaises(video.VideoError):lib.import_start(url)
   self.assertFalse(lib.busy)

class MediaTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.temp=tempfile.TemporaryDirectory();cls.root=Path(cls.temp.name);cls.original=cls.root/'sample.mp4'
  video.command([video.tool('ffmpeg'),'-hide_banner','-loglevel','error','-y','-f','lavfi','-i','testsrc2=size=160x90:rate=30:duration=3','-c:v','libx264','-pix_fmt','yuv420p',str(cls.original)])
 @classmethod
 def tearDownClass(cls):cls.temp.cleanup()
 def setUp(self):self.temp_case=tempfile.TemporaryDirectory();self.lib=video.VideoLibrary(self.temp_case.name)
 def tearDown(self):self.wait();self.temp_case.cleanup()
 def wait(self):
  deadline=time.monotonic()+30
  while self.lib.busy and time.monotonic()<deadline:time.sleep(.02)
  self.assertFalse(self.lib.busy)
 def upload(self):
  data=self.original.read_bytes();r=self.lib.upload(io.BytesIO(data),len(data),'sample.mp4');self.wait();r=self.lib.state(r['id']);self.assertEqual(r['phase'],'ready',r);return r
 def test_real_upload_multi_range_edit_old_edition_and_tamper(self):
  r=self.upload();original=self.lib.path(r['id'])/r['original_file'];before=hashlib.sha256(original.read_bytes()).hexdigest()
  self.lib.render_start(r['id'],[[.2,.8],[2,2.7]]);self.wait();r=self.lib.state(r['id']);self.assertEqual(r['phase'],'ready',r);first=r['edit'];self.assertAlmostEqual(first['duration'],1.3,delta=.04)
  self.assertEqual(self.lib.bind(r['id'],first['id'])['edit']['ranges'],[[.2,.8],[2,2.7]])
  self.lib.render_start(r['id'],[[1,2]]);self.wait();r=self.lib.state(r['id']);self.assertNotEqual(first['id'],r['edit']['id']);self.assertTrue(self.lib.media_path(r['id'],first['id']).exists());self.assertEqual(before,hashlib.sha256(original.read_bytes()).hexdigest())
  with self.assertRaises(video.VideoError):self.lib.bind(r['id'],first['id'])
  self.lib.media_path(r['id'],r['edit']['id']).write_bytes(b'tampered')
  with self.assertRaises(video.VideoError):self.lib.bind(r['id'],r['edit']['id'])
 def test_bad_upload_releases_lock(self):
  with self.assertRaises(video.VideoError):self.lib.upload(io.BytesIO(b'bad'),12,'bad.mp4')
  self.assertFalse(self.lib.busy)
  r=self.lib.upload(io.BytesIO(b'bad'),3,'bad.mp4');self.wait();self.assertEqual(self.lib.state(r['id'])['phase'],'error')
  for args in (('../outside',None),('0'*32,'../outside')):
   with self.assertRaises(video.VideoError):self.lib.media_path(*args)
 def test_analysis_errors_never_become_adoption(self):
  r=self.upload();self.lib.render_start(r['id'],[[0,1],[2,3]]);self.wait();r=self.lib.state(r['id']);bound=self.lib.bind(r['id'],r['edit']['id']);j={'id':'isolated','manual_video':bound};s={'no':1}
  with patch.object(video,'extract',side_effect=video.ReferenceError('decode failed')):
   with self.assertRaises(video.ReferenceError):self.lib.analyze(j,s,'动作',None,lambda _:None,lambda:False,Path(self.temp_case.name)/'job')
  self.assertEqual(s['highlight_reference']['status'],'unavailable');self.assertFalse(s['highlight_reference']['used'])
  def extract(path,dest):return ({'start':0,'end':2,'duration':2,'sheets':[]},[])
  result={'suitable':True,'reason':'相容','beats':[{'line':1,'start':.5,'end':1.5,'observation':'身体前倾','camera':'侧面中景','action':'起势前进收势','adaptation':'套用原人物'}]}
  with patch.object(video,'extract',extract):
   analysis=self.lib.analyze(j,s,'动作',lambda *a,**kw:copy.deepcopy(result),lambda _:None,lambda:False,Path(self.temp_case.name)/'job')
  self.assertEqual(analysis['analysis']['beats'][0]['source_ranges'],[[.5,1],[2,2.5]]);self.assertFalse(analysis['used']);self.assertEqual(analysis['status'],'analyzed')
 def test_isolated_http_auth_range_and_start_gates(self):
  server=ThreadingHTTPServer(('127.0.0.1',0),app.Handler);port=server.server_address[1]
  with patch.object(app,'MEDIA',self.lib),patch.object(app,'PORT',port),patch.object(app,'TOKEN','isolated-token'):
   thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
   def call(method,path,body=None,headers=None):
    conn=http.client.HTTPConnection('127.0.0.1',port);h={'X-Workbench-Token':'isolated-token'};h.update(headers or {});conn.request(method,path,body=body,headers=h);response=conn.getresponse();data=response.read();out=(response.status,dict(response.getheaders()),data);conn.close();return out
   try:
    status,_,_=call('POST','/api/replica/upload?name=sample.mp4',self.original.read_bytes(),{'X-Workbench-Token':'wrong'});self.assertEqual(status,403)
    status,_,data=call('POST','/api/replica/upload?name=sample.mp4',self.original.read_bytes());self.assertEqual(status,200,data);r=json.loads(data);self.wait()
    status,headers,data=call('GET','/api/replica/media/'+r['id']+'/source',headers={'Range':'bytes=0-15'});self.assertEqual(status,206);self.assertEqual(len(data),16);self.assertTrue(headers['Content-Range'].startswith('bytes 0-15/'))
    status,headers,data=call('HEAD','/api/replica/media/'+r['id']+'/source');self.assertEqual(status,200);self.assertEqual(data,b'');self.assertGreater(int(headers['Content-Length']),16)
    status,_,_=call('GET','/api/replica/media/'+r['id']+'/source',headers={'Range':'bytes=999999999-'});self.assertEqual(status,416)
    status,_,data=call('POST','/api/replica/edit',json.dumps({'asset_id':r['id'],'ranges':[]}));self.assertEqual(status,400);self.assertIn('error',json.loads(data))
    self.lib.render_start(r['id'],[[0,1]]);self.wait();r=self.lib.state(r['id']);source=fixture();source.update(status='complete',read_complete=True);source['shots'][0]['state']='saved'
    payload={'id':'test','numbers':[1],'asset_id':r['id'],'edit_id':r['edit']['id']}
    with patch.object(app,'load',return_value=source),patch.object(app,'background') as background:
     status,_,data=call('POST','/api/replica/start',json.dumps(payload));self.assertEqual(status,200,data);revision=background.call_args[0][0];self.assertEqual(revision['manual_video']['edit']['id'],r['edit']['id']);self.assertEqual(revision['target_nos'],[1]);self.assertEqual(revision['workflow'],'postfill_single')
     background.reset_mock();source['status']='review';status,_,_=call('POST','/api/replica/start',json.dumps(payload));self.assertEqual(status,400);background.assert_not_called()
    self.lib.operation.acquire()
    try:
     with patch.object(app,'create_batch') as batch:
      status,_,_=call('POST','/api/batch/start','{}');self.assertEqual(status,400);batch.assert_not_called()
    finally:self.lib.operation.release()
   finally:server.shutdown();server.server_close();thread.join()

class ManualAdoptionTests(unittest.TestCase):
 def test_plain_rewrite_cannot_pass_as_manual_replica(self):
  j=fixture();j['manual_video']={};j['manual_video']['asset_id']='x';s=j['shots'][0];pre,body,post=app.split_style(s['original']);line=next(i+1 for i,text in enumerate(body.splitlines()) if '侧面近景' in text)
  s['highlight_reference']={'status':'analyzed','manual':True,'analysis':{'suitable':True,'beats':[{'line':line,'start':0,'end':1}]}}
  def model(prompt,jid,schema=None,**kwargs):
   result=reply(prompt,schema);result['reference_usage']={'used':False,'applications':[]};return result
  with patch.object(app,'model_json',model),self.assertRaises(app.RewriteRejected):app._optimize_body_once(j,s,'',pre,body,post,body.splitlines(keepends=True),{})
  self.assertNotEqual(s['highlight_reference']['status'],'adopted')

if __name__=='__main__':unittest.main()
