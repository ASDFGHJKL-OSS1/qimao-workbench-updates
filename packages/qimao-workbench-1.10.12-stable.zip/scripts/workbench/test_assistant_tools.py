import copy,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import assistant_tools as tools
from assistant_service import AssistantService
import server as app

class AssistantToolsTests(unittest.TestCase):
 def job(self,**kw):
  return dict(id='sample',project_id=1,episode=2,project_name='测试项目',created='2026-11-10 10:00:00',updated='2026-11-10 10:00:00',status='review',read_complete=True,shots=[dict(no=1,state='draft',original='原稿',candidate='建议稿'),dict(no=2,state='failed',original='原稿2',error='Service Unavailable')],**kw)
 def test_diagnosis_reports_actual_failure_and_location(self):
  report=tools.diagnose(self.job());self.assertEqual(report['issues'][0]['shot_no'],2);self.assertEqual(report['issues'][0]['kind'],'连接暂时异常');self.assertIn('Service Unavailable',report['issues'][0]['evidence']);self.assertTrue(any(a['shot_no']==2 for a in report['actions']))
 def test_revision_does_not_act_on_other_shots(self):
  j=self.job(kind='revision',target_nos=[1],revision_prepared=True);report=tools.diagnose(j);self.assertEqual(report['issues'],[]);self.assertEqual(report['total'],1);self.assertNotIn('retry',[a['kind'] for a in report['actions']])
 def test_running_task_only_has_view_actions(self):
  j=self.job();j['status']='optimizing';self.assertEqual(set(a['kind'] for a in tools.actions(j,1)),{'open_job','open_diff'})
 def test_completed_task_goes_to_revision_and_video_without_retry(self):
  j=self.job();j['status']='complete';j['shots'][0]['state']='saved';kinds={a['kind'] for a in tools.actions(j,1)};self.assertTrue({'open_revision','open_video'}<=kinds);self.assertNotIn('retry',kinds)
 def test_save_action_requires_all_candidates_pass(self):
  j=self.job();j['shots'][1].update(state='draft',candidate='未通过');self.assertNotIn('review_save',[a['kind'] for a in tools.actions(j,validate=lambda s,t:{'ok':t!='未通过'})]);self.assertIn('review_save',[a['kind'] for a in tools.actions(j,validate=lambda s,t:{'ok':True})])
 def test_stale_action_and_forged_kind_rejected(self):
  j=self.job();a=next(a for a in tools.actions(j) if a['kind']=='retry');j['shots'][0]['candidate']='新候选稿'
  with self.assertRaisesRegex(ValueError,'已变化'):tools.resolve_action(j,a)
  a['baseline']=tools.baseline(j)
  with self.assertRaisesRegex(ValueError,'不可用'):tools.resolve_action(j,a)
 def test_busy_blocks_resume_but_allows_view(self):
  j=self.job();a=next(a for a in tools.actions(j) if a['kind']=='retry')
  with self.assertRaisesRegex(ValueError,'正在处理'):tools.resolve_action(j,a,busy=True)
  a=next(a for a in tools.actions(j) if a['kind']=='open_job' and not a['shot_no']);self.assertEqual(tools.resolve_action(j,a,busy=True)['kind'],'open_job')
 def test_model_cannot_invent_actions_or_change_labels(self):
  catalog=[dict(id='good',kind='open_job',label='真实入口')];result=AssistantService.allowed_actions({'action_ids':['fake','good','good',{'id':'evil'}]},{'available_actions':catalog});self.assertEqual(result,catalog);result[0]['label']='篡改';self.assertEqual(catalog[0]['label'],'真实入口')
 def test_dashboard_latest_per_episode_and_project(self):
  first=self.job();latest=copy.deepcopy(first);latest.update(id='latest',created='2026-11-10 11:00:00',status='complete',shots=[]);other=copy.deepcopy(first);other.update(id='other',project_id=2)
  result=tools.dashboard([first,latest,other],1);self.assertEqual([r['job_id'] for r in result['tasks']],['latest']);self.assertIn('本机',result['source'])
 def test_hidden_records_cannot_be_actioned(self):
  from project_library import ProjectLibrary
  with tempfile.TemporaryDirectory() as d,patch.object(app,'DATA',Path(d)):
   j=self.job();p=Path(d)/j['id'];p.mkdir();import json;(p/'job.json').write_text(json.dumps(j));a=tools.actions(j)[0];ProjectLibrary(Path(d)).change('job',j['id'])
   with self.assertRaisesRegex(app.Problem,'回收站'):app.assistant_action({'action':a})
   self.assertEqual(app.assistant_inspect({},1)['tasks'],[])
 def test_no_prompt_length_cap_in_assistant_context(self):
  j=self.job();j['shots']=[]
  with patch.object(app.ProjectLibrary,'active_jobs',return_value=[j]),patch.object(app,'load',return_value=j),patch.object(app,'decorate',side_effect=lambda x:{**x,'shots':[dict(no=1,state='draft',duration=5,original='原文',candidate='稿',validation={'ok':True,'chars':1,'errors':[]})]}):
   result=app.assistant_context({'job_id':j['id'],'shot_no':1,'draft':'长'*31000});self.assertEqual(len(result['selected']['unsaved_draft']),31000);self.assertNotIn('skills',result)

if __name__=='__main__':unittest.main()
