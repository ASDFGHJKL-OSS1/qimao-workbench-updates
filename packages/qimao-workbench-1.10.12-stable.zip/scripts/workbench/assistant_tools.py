"""Grounded assistant diagnostics and bounded, reviewable workbench actions."""
import hashlib,json,re,time

ACTIVE={'queued','reading','optimizing','recovering','saving'}
LABELS={'ready':'已读取，待优化','review':'待检查','complete':'已回填核验','error':'需要处理','stopped':'已停止','queued':'排队中','reading':'读取中','optimizing':'优化中','recovering':'恢复中','saving':'回填中'}

def targets(job):return [s for s in job.get('shots',[]) if job.get('kind')!='revision' or s['no'] in job.get('target_nos',[])]

def baseline(job):
 value={k:job.get(k) for k in ('id','status','read_complete','revision_prepared','updated','optimization_run_id','target_nos')}
 value['shots']=[{k:s.get(k) for k in ('no','state','original','candidate','error')} for s in targets(job)]
 return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def actions(job,shot_no=None,validate=None):
 if job.get('historical'):return []
 rows=targets(job);selected=next((s for s in rows if s['no']==shot_no),None)
 stamp=baseline(job);out=[]
 def add(kind,label,description,no=None):
  aid=hashlib.sha256(json.dumps([job['id'],kind,no,stamp]).encode()).hexdigest()[:24]
  out.append({'id':aid,'kind':kind,'label':label,'description':description,'job_id':job['id'],'shot_no':no,'baseline':stamp})
 add('open_job','查看这条任务','打开实际任务与动态',selected and selected['no'])
 if selected and selected.get('candidate'):add('open_diff','查看这段修改对比','同时检查原稿与完整候选稿',selected['no'])
 if not selected:
  for row in rows:
   if row.get('error') or row.get('state') in ('failed','blocked'):add('open_job',f'查看片段{row["no"]:02}的异常','定位实际失败片段',row['no'])
 if job.get('status') in ACTIVE:return out
 if job.get('status')=='complete':
  if selected and selected.get('state')=='saved':
   add('open_revision','去修改这一段','进入05，保留上一版并填写本次想法',selected['no'])
   add('open_video','去做视频深度复刻','进入06，导入、剪辑并选择参考',selected['no'])
 elif job.get('read_complete') and (job.get('kind')!='revision' or job.get('revision_prepared')):
  unfinished=[s for s in rows if s.get('state') not in ('draft','saved')]
  if unfinished:add('retry','开始 / 继续未完成优化','开始优化未完成部分；已通过的片段保留')
  if rows and all(s.get('candidate') and (not validate or validate(s,s['candidate']).get('ok')) for s in rows) and any(s.get('state')!='saved' for s in rows):
   add('review_save','检查并准备回填','打开完整稿与差异；仍需在原确认窗口确认')
 return out

def classify(error):
 text=str(error or '');low=text.casefold()
 if any(x in low for x in ('unauthorized','forbidden','未登录','登录失效','权限','认证失败')):return '登录或权限','先恢复七猫或模型登录，再继续原任务。'
 if any(x in text for x in ('版本','配置已变化','平台内容','顺序或数量')):return '平台版本冲突','保留本地稿，重新读取平台当前版本后核对；不能直接覆盖。'
 if any(x in text for x in ('核对','校验','遗漏','台词','资产','风格','画风','正文','格式','证据')):return '内容或格式未通过','查看具体失败行与反馈，再继续未完成优化；原保护规则继续生效。'
 if any(x in low for x in ('timeout','timed out','超时','网络','连接','service unavailable','bad gateway','限流','429','503')):return '连接暂时异常','连接恢复后继续未完成部分；已经完成的片段不会重做。'
 return '需要核对','先打开任务动态和失败片段，依据实际错误处理。'

def diagnose(job,validate=None):
 rows=targets(job);issues=[]
 if job.get('error'):
  kind,next_step=classify(job['error']);issues.append({'kind':kind,'evidence':str(job['error']),'next_step':next_step})
 for s in rows:
  if s.get('state') in ('failed','blocked') or s.get('error'):
   kind,next_step=classify(s.get('error'));issues.append({'kind':kind,'shot_no':s['no'],'evidence':str(s.get('error') or '该段尚未完成'),'next_step':next_step})
  if s.get('candidate') and validate:
   check=validate(s,s['candidate'])
   if not check.get('ok'):issues.append({'kind':'候选稿校验未通过','shot_no':s['no'],'evidence':'；'.join(check.get('errors',[])),'next_step':'检查完整稿和具体错误，不能带着未通过的稿件回填。'})
 status=job.get('status')
 if not issues:
  if status=='complete':next_step='这条任务已回填并核验；若想再次调整某一段，进入05或06。'
  elif status in ACTIVE:next_step='任务正在处理，查看进度即可。'
  elif status=='review':next_step='查看全部候选稿与修改对比，再确认回填。'
  elif status=='ready':next_step='原稿已读取并备份，填写想法后可以开始优化。'
  else:next_step='打开任务动态，核对当前断点。'
 else:next_step=issues[0]['next_step']
 return {'job_id':job['id'],'project_id':job.get('project_id'),'project_name':job.get('project_name','七猫项目'),'episode':job.get('episode'),'kind':job.get('kind'),'manual_video':bool(job.get('manual_video')),'workflow':job.get('workflow'),'target_nos':job.get('target_nos',[]),'status':status,'status_label':LABELS.get(status,status),'updated':job.get('updated') or job.get('created'),'total':len(rows),'drafts':sum(s.get('state')=='draft' for s in rows),'saved':sum(s.get('state')=='saved' for s in rows),'failed':sum(s.get('state') in ('failed','blocked') for s in rows),'issues':issues,'next_step':next_step,'actions':actions(job,validate=validate)}

def dashboard(jobs,project_id=None,validate=None):
 latest={}
 for job in sorted(jobs,key=lambda j:(j.get('created',''),j.get('updated','')),reverse=True):
  if job.get('historical') or project_id is not None and str(job.get('project_id'))!=str(project_id):continue
  latest.setdefault((job.get('project_id'),job.get('episode')),job)
 rows=[diagnose(j,validate) for j in latest.values()]
 rows.sort(key=lambda r:(not bool(r['issues']),r['status']=='complete',-(r['episode'] or 0)))
 return {'checked_at':time.strftime('%Y-%m-%d %H:%M:%S'),'source':'本机任务记录；不代表实时平台查询','project_id':project_id,'counts':{'episodes':len(rows),'attention':sum(bool(r['issues']) for r in rows),'review':sum(r['status']=='review' and not r['issues'] for r in rows),'running':sum(r['status'] in ACTIVE for r in rows),'complete':sum(r['status']=='complete' for r in rows)},'tasks':rows}


def resolve_action(job,request,validate=None,busy=False):
 if request.get('baseline')!=baseline(job):raise ValueError('任务已变化，请重新体检或重新提问，再使用新按钮。')
 allowed=actions(job,request.get('shot_no'),validate)
 action=next((a for a in allowed if a['id']==request.get('id')),None)
 if not action:raise ValueError('这个操作已不可用，请重新体检。')
 if busy and action['kind'] not in ('open_job','open_diff'):raise ValueError('工作台正在处理任务或视频，请等待完成。')
 return action
