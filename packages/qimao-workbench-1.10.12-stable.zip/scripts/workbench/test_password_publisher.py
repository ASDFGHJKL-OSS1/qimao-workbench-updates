"""Publication baselines must survive authentication, restart and installation."""
import base64,hashlib,json,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
from password_publisher import PasswordPublisher,REPO,fingerprint
from update_protocol import node_crypto,UpdateError,write_json
from test_updates import publisher as release_tool
from test_credential_vault import MemoryVault

class PublisherBaselineTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.keys=node_crypto('keygen')
 def setUp(self):
  MemoryVault.records={};vault=patch('password_publisher.CredentialVault',MemoryVault);vault.start();self.addCleanup(vault.stop)
  self.temp=tempfile.TemporaryDirectory();self.skill=Path(self.temp.name)/'skill';self.root=self.skill/'scripts/workbench';self.root.mkdir(parents=True)
  (self.root/'update-public.pem').write_text(self.keys['publicKey']);(self.root/'version.json').write_text(json.dumps({'product':'qimao-prompt-workbench','version':'1.0.0'}));(self.root/'server.py').write_text('print("original")\n');(self.skill/'SKILL.md').write_text('version: "1.0.0"')
  (self.root/'web').mkdir();(self.root/'web/index.html').write_text('<h1>test</h1>');(self.skill/'scripts/workbench.py').write_text('print("entry")\n')
  self.private=Path(self.temp.name)/'key.pem';self.private.write_text(self.keys['privateKey'])
 def tearDown(self):self.temp.cleanup()
 def login(self,p):
  with patch('password_publisher.request',return_value={'repository':REPO}),patch('password_publisher.crypt',return_value={'token':'test-token'}),patch('password_publisher.verify'):p.login('test-password')
 def test_reauthentication_does_not_swallow_pending_edits(self):
  p=PasswordPublisher(self.root);self.login(p);baseline=p.last_fingerprint;(self.root/'server.py').write_text('print("changed")\n');self.assertTrue(p.unlocked);self.login(p);self.assertEqual(p.last_fingerprint,baseline);self.assertTrue(p.has_changes());p.require_changes()
 def test_restart_preserves_edits_and_admin_session(self):
  p=PasswordPublisher(self.root);self.login(p);(self.root/'server.py').write_text('print("changed")\n');p=PasswordPublisher(self.root);self.assertTrue(p.has_changes());self.assertTrue(p.unlocked);self.assertTrue(p.public()['has_changes'])
 def test_login_without_edits_cannot_publish(self):
  p=PasswordPublisher(self.root);self.login(p);self.assertFalse(p.has_changes())
  with self.assertRaisesRegex(UpdateError,'暂无'):p.require_changes()
 def test_signed_install_recovers_baseline_even_after_edit_before_first_boot(self):
  package,manifest=release_tool.build(Path(self.temp.name)/'release','https://updates.example.com','stable',['test'],self.private,self.skill)
  write_json(self.root/'data/updates/install-request.json',{'package':str(package),'manifest':manifest});original=fingerprint(self.skill);(self.root/'server.py').write_text('print("edited-before-first-start")\n');p=PasswordPublisher(self.root);self.assertEqual(p.last_fingerprint,original);self.assertTrue(p.has_changes());self.assertEqual(json.loads(p.baseline_path.read_text())['source'],'signed_install')
 def test_new_version_gets_new_signed_baseline(self):
  p=PasswordPublisher(self.root);old=p.last_fingerprint;(self.skill/'SKILL.md').write_text('version: "1.0.1"');(self.root/'version.json').write_text(json.dumps({'product':'qimao-prompt-workbench','version':'1.0.1'}));package,manifest=release_tool.build(Path(self.temp.name)/'release','https://updates.example.com','stable',['test'],self.private,self.skill);write_json(self.root/'data/updates/install-request.json',{'package':str(package),'manifest':manifest});p=PasswordPublisher(self.root);self.assertNotEqual(p.last_fingerprint,old);self.assertFalse(p.has_changes())
 def test_tampered_package_cannot_supply_baseline(self):
  package,manifest=release_tool.build(Path(self.temp.name)/'release','https://updates.example.com','stable',['test'],self.private,self.skill);package.write_bytes(b'not a signed zip');write_json(self.root/'data/updates/install-request.json',{'package':str(package),'manifest':manifest});p=PasswordPublisher(self.root);self.assertEqual(json.loads(p.baseline_path.read_text())['source'],'first_start')
 def test_data_changes_are_not_program_edits(self):
  p=PasswordPublisher(self.root);write_json(self.root/'data/assistant.json',{'messages':['private']});write_json(self.root/'data/jobs/a/job.json',{'id':'a'});self.assertFalse(p.has_changes())
 def test_maintenance_is_independent_of_password(self):
  p=PasswordPublisher(self.root);(self.root/'server.py').write_text('print("changed")\n');lock=self.root/'data/updates/publisher-maintenance.lock';lock.touch();self.login(p)
  with self.assertRaisesRegex(UpdateError,'维护'):p.require_changes()
  lock.unlink();p.require_changes();self.assertIsNone(p.public()['expires_at']);self.assertTrue(p.public()['remembered'])
 def test_only_confirmed_online_publication_advances_baseline(self):
  p=PasswordPublisher(self.root);(self.root/'server.py').write_text('print("changed")\n');fp=fingerprint(self.skill);self.login(p);p.state={'phase':'submitted','request_id':'test-id','submitted_fingerprint':fp};before=p.last_fingerprint
  manifest={'request_id':'other-id','sha256':'test-sha','version':'1.0.1'}
  with patch('password_publisher.request',side_effect=[{'content':base64.b64encode(json.dumps(manifest).encode()).decode()},{'workflow_runs':[]}]):p.state['commit']='test-commit';p.poll()
  self.assertEqual(p.last_fingerprint,before)
  manifest['request_id']='test-id'
  with patch('password_publisher.request',side_effect=[{'content':base64.b64encode(json.dumps(manifest).encode()).decode()},manifest]),patch('password_publisher.verify'):p.poll()
  self.assertEqual(p.state['phase'],'published');self.assertFalse(p.has_changes());self.assertFalse(PasswordPublisher(self.root).has_changes())

 def test_login_never_times_out_and_password_is_not_saved(self):
  p=PasswordPublisher(self.root);self.login(p)
  with patch('password_publisher.time.time',return_value=time.time()+86400*365):self.assertTrue(p.unlocked)
  self.assertNotIn('password',str(MemoryVault.records));self.assertIsNone(p.public()['expires_at'])
 def test_logout_is_persistent_and_keeps_pending_edits(self):
  p=PasswordPublisher(self.root);self.login(p);(self.root/'server.py').write_text('print("changed")\n');p.logout();self.assertFalse(p.unlocked);self.assertFalse(p.public()['remembered']);fresh=PasswordPublisher(self.root);self.assertFalse(fresh.unlocked);self.assertTrue(fresh.has_changes());self.login(fresh);self.assertTrue(fresh.unlocked)
 def test_credential_is_not_distributed_in_snapshot(self):
  from password_publisher import snapshot
  p=PasswordPublisher(self.root);self.login(p);import io,zipfile
  with zipfile.ZipFile(io.BytesIO(snapshot(self.skill))) as z:
   self.assertFalse(any('/data/' in n for n in z.namelist()));self.assertFalse(any(b'test-token' in z.read(n) for n in z.namelist()))
 def test_update_center_logout_restores_ordinary_user(self):
  from update_center import UpdateCenter
  with patch.dict('os.environ',{'QIMAO_UPDATE_ADMIN':'0'}):
   center=UpdateCenter(self.root);self.login(center.publisher);self.assertTrue(UpdateCenter(self.root).is_admin);self.assertFalse(center.admin_logout()['admin']);self.assertFalse(UpdateCenter(self.root).is_admin)

if __name__=='__main__':unittest.main()
