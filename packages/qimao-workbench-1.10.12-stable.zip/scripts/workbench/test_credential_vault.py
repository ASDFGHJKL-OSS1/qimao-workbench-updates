"""Credential persistence is user scoped and uses the system Keychain, never package files."""
import json,subprocess,unittest
from pathlib import Path
from unittest.mock import patch
from credential_vault import CredentialVault,VaultError

class MemoryVault:
 records={}
 def __init__(self,root):self.account=str(Path(root).resolve())
 def load(self):return self.records.get(self.account)
 def save(self,value):self.records[self.account]={'schema':1,**value}
 def clear(self):self.records.pop(self.account,None)

class CredentialVaultTests(unittest.TestCase):
 def test_account_is_installation_scoped(self):
  a=CredentialVault('/tmp/one');self.assertEqual(a.account,CredentialVault('/tmp/one').account);self.assertNotEqual(a.account,CredentialVault('/tmp/two').account)
 def test_save_and_load_use_keychain_without_password_file(self):
  commands=[];record={}
  def command(args,**kw):
   commands.append(args)
   if args[1]=='add-generic-password':record.update(json.loads(args[args.index('-w')+1]));return subprocess.CompletedProcess(args,0,'','')
   if args[1]=='find-generic-password':return subprocess.CompletedProcess(args,0,json.dumps(record),'')
   return subprocess.CompletedProcess(args,0,'','')
  with patch('credential_vault.sys.platform','darwin'),patch('credential_vault.subprocess.run',side_effect=command):
   vault=CredentialVault('/tmp/one');vault.save({'token':'isolated-test-token'});self.assertEqual(vault.load()['token'],'isolated-test-token');vault.clear()
  self.assertEqual([c[1] for c in commands],['add-generic-password','find-generic-password','delete-generic-password']);self.assertIn('-T',commands[0]);self.assertNotIn('password',record)
 def test_missing_and_locked_keychain_are_distinguished(self):
  vault=CredentialVault('/tmp/one')
  with patch.object(vault,'run',return_value=subprocess.CompletedProcess([],44,'','')):self.assertIsNone(vault.load());vault.clear()
  with patch.object(vault,'run',return_value=subprocess.CompletedProcess([],1,'','sensitive-details')):
   with self.assertRaisesRegex(VaultError,'暂未解锁'):vault.load()
 def test_timeout_does_not_expose_credentials(self):
  with patch('credential_vault.sys.platform','darwin'),patch('credential_vault.subprocess.run',side_effect=subprocess.TimeoutExpired(['secret'],15)):
   with self.assertRaisesRegex(VaultError,'钥匙串') as error:CredentialVault('/tmp/one').save({'token':'secret'})
   self.assertNotIn('secret',str(error.exception))

if __name__=='__main__':unittest.main()
