"""User-scoped macOS Keychain storage. No password or publishing token in program/data files."""
import hashlib,json,subprocess,sys
from pathlib import Path

class VaultError(Exception):pass

class CredentialVault:
 service='cn.qimao.workbench.admin-session.v1'
 def __init__(self,root):
  self.account='workbench-'+hashlib.sha256(str(Path(root).resolve()).encode()).hexdigest()[:32]
 def run(self,args):
  if sys.platform!='darwin':raise VaultError('当前系统不支持本机钥匙串，无法保存管理员登录')
  try:return subprocess.run(['/usr/bin/security',*args],capture_output=True,text=True,timeout=15)
  except (OSError,subprocess.TimeoutExpired):raise VaultError('系统钥匙串暂时无法访问，请解锁电脑后重试') from None
 def load(self):
  result=self.run(['find-generic-password','-s',self.service,'-a',self.account,'-w'])
  if result.returncode==44:return None
  if result.returncode:raise VaultError('系统钥匙串暂未解锁，解锁后可恢复管理员登录')
  try:
   value=json.loads(result.stdout)
   if not isinstance(value,dict) or value.get('schema')!=1:raise ValueError()
   return value
  except (ValueError,TypeError):raise VaultError('本机管理员登录记录无法读取，请重新登录') from None
 def save(self,value):
  value={'schema':1,**value}
  result=self.run(['add-generic-password','-U','-s',self.service,'-a',self.account,'-w',json.dumps(value,separators=(',',':')),'-T','/usr/bin/security'])
  if result.returncode:raise VaultError('管理员登录未能存入系统钥匙串，请解锁电脑后重试')
 def clear(self):
  result=self.run(['delete-generic-password','-s',self.service,'-a',self.account])
  if result.returncode not in (0,44):raise VaultError('暂时无法清除本机管理员登录，请解锁电脑后重试')
