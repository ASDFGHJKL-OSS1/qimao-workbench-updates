"""Signed releases, real HTTP publication, update guards and code rollback."""
import base64,hashlib,importlib.util,json,stat,tempfile,threading,time,unittest,urllib.error,urllib.request,zipfile
from pathlib import Path
from http.server import ThreadingHTTPServer
from unittest.mock import patch
from update_protocol import PRODUCT,UpdateError,inspect_package,manifest_check,node_crypto,sha,sign,write_json
from update_center import UpdateCenter
from test_credential_vault import MemoryVault
from update_worker import run,apply_files,restore_files
BASE=Path(__file__).resolve().parents[2]
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
publisher=module('release_tool',BASE/'scripts/release.py');origin=module('update_origin',BASE/'update-server/server.py')
class Updates(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  k=node_crypto('keygen');cls.private=k['privateKey'];cls.public=k['publicKey']
 def setUp(self):
  MemoryVault.records={};vault=patch('password_publisher.CredentialVault',MemoryVault);vault.start();self.addCleanup(vault.stop)
  env=patch.dict("os.environ",{"QIMAO_UPDATE_ADMIN":"1"});env.start();self.addCleanup(env.stop)
  self.temp=tempfile.TemporaryDirectory();self.base=Path(self.temp.name);self.skill=self.base/'skill';self.root=self.skill/'scripts/workbench';self.root.mkdir(parents=True);self.key=self.base/'private.pem';self.key.write_text(self.private)
  for name,content in {'SKILL.md':'version: "1.7.1"','scripts/workbench.py':'print("entry")\n','scripts/workbench/server.py':'print("new")\n','scripts/workbench/web/index.html':'new UI','scripts/workbench/version.json':json.dumps({'product':PRODUCT,'version':'1.7.1'}),'scripts/workbench/update-public.pem':self.public}.items():
   p=self.skill/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content)
  self.sentinel=self.root/'data/jobs/keep.json';self.sentinel.parent.mkdir(parents=True);self.sentinel.write_bytes(b'private data\x00\xe4\xb8\xad')
 def tearDown(self):self.temp.cleanup()
 def build(self,base='https://updates.example.com',channel='stable',output=None):return publisher.build(output or self.base/'out',base,channel,['test update'],self.key,self.skill)
 def mutate(self,path,change):
  with zipfile.ZipFile(path) as z:e={i.filename:(i,z.read(i)) for i in z.infolist()}
  change(e);target=self.base/'mutated.zip'
  with zipfile.ZipFile(target,'w') as z:
   for n,(i,d) in e.items():z.writestr(i,d)
  return target
 def test_signed_build_excludes_data(self):
  p,m=self.build();r=inspect_package(p,self.public,m);self.assertEqual(r['version'],'1.7.1');self.assertFalse(any('/data/' in f or 'private' in f for f in r['files']))
  with self.assertRaises(UpdateError):manifest_check(dict(m,version='9.0.0'),self.public)
  with self.assertRaises(UpdateError):inspect_package(p,node_crypto('keygen')['publicKey'])
 def test_customer_default_and_admin_password(self):
  c=UpdateCenter(self.root);c.admin=False
  login=patch.object(c.publisher,"login",side_effect=UpdateError("HTTP 404"));login.start();self.addCleanup(login.stop)
  self.assertIn('github.io',c.settings['server_url'])
  with self.assertRaises(UpdateError):c.settings_save({'server_url':'https://evil.example','channel':'stable','policy':'notify'})
  with self.assertRaises(UpdateError):c.import_package(b'fake')
  with self.assertRaises(UpdateError):c.admin_login('anything')
  salt=b'isolated-test-salt';c.admin_auth={'salt':salt.hex(),'digest':hashlib.pbkdf2_hmac('sha256',b'test-secret',salt,200000).hex()}
  with self.assertRaises(UpdateError):c.admin_login('incorrect')
  self.assertFalse(c.admin);self.assertTrue(c.admin_login('test-secret')['admin'])
 def test_payload_tamper(self):
  p,m=self.build();q=self.mutate(p,lambda e:e.update({'scripts/workbench/server.py':(e['scripts/workbench/server.py'][0],b'tampered')}))
  with self.assertRaises(UpdateError):inspect_package(q,self.public)
  with self.assertRaises(UpdateError):inspect_package(q,self.public,m)
 def bad_release(self,name,mode=stat.S_IFREG|0o644):
  p,_=self.build()
  def change(e):
   r=json.loads(e['release.json'][1]);r.pop('signature');r['files'][name]={'sha256':sha(b'bad'),'mode':0o644};r=sign(r,self.private);i=zipfile.ZipInfo(name);i.external_attr=mode<<16;e[name]=(i,b'bad');e['release.json']=(e['release.json'][0],json.dumps(r).encode())
  return self.mutate(p,change)
 def test_path_traversal_rejected(self):
  for n in ['../outside','scripts/workbench/../outside','/tmp/outside','scripts/workbench/data/jobs/overwrite','scripts/workbench/.secret']:
   with self.subTest(path=n),self.assertRaises(UpdateError):inspect_package(self.bad_release(n),self.public)
 def test_symlink_rejected(self):
  with self.assertRaises(UpdateError):inspect_package(self.bad_release('scripts/workbench/link',stat.S_IFLNK|0o777),self.public)
 def test_channel_and_downgrade(self):
  p,m=self.build(channel='beta')
  with self.assertRaises(UpdateError):manifest_check(m,self.public,'stable')
  c=UpdateCenter(self.root);c.current='1.7.2'
  with self.assertRaises(UpdateError):c.import_package(p.read_bytes())
  with self.assertRaises(UpdateError):c.settings_save({'server_url':'http://example.com','channel':'stable','policy':'notify'})
 def test_busy_and_unsaved_guard(self):
  p,_=self.build();c=UpdateCenter(self.root,lambda:True);c.import_package(p.read_bytes())
  with self.assertRaises(UpdateError):c.action('install')
  c.busy=lambda:False;c.page({'page':'tab1','dirty':True})
  with self.assertRaises(UpdateError):c.action('install')
  c.page({'page':'tab2','dirty':False});self.assertTrue(c.status()['unsaved']);c.page({'page':'tab1','closed':True});self.assertFalse(c.status()['unsaved']);self.assertTrue(c.status()['downloaded'])
 def test_worker_success_preserves_data(self):self.worker(False)
 def test_suspended_dirty_page_blocks_install(self):
  c=UpdateCenter(self.root);c.pages={'background':(time.time()-3600,True),'closed-clean':(time.time()-3600,False)}
  self.assertTrue(c.unsaved());self.assertNotIn('closed-clean',c.pages)
  c.page({'page':'background','dirty':False});self.assertFalse(c.unsaved())
 def test_auto_policy_waits_for_idle_and_saved_pages(self):
  p,m=self.build();c=UpdateCenter(self.root,lambda:True);c.current='1.7.0'
  c.settings={'server_url':'https://updates.example.com','channel':'stable','policy':'auto'}
  c.set(manifest=m,phase='available',last_check=time.time());actions=[];c.action=lambda name:actions.append(name)
  c.tick();self.assertEqual(actions,[])
  c.busy=lambda:False;c.tick({'page':'tab','dirty':True});self.assertEqual(actions,[])
  c.tick({'page':'tab','dirty':False});self.assertEqual(actions,['download'])
  c.set(package=str(p),phase='downloaded');c.tick();self.assertEqual(actions,['download','install'])
  c.settings['policy']='off';c.tick();self.assertEqual(actions,['download','install'])
 def test_worker_failure_rolls_back(self):self.worker(True)
 def worker(self,fail):
  p,m=self.build();before=self.sentinel.read_bytes();old=b'print("old")\n';(self.root/'server.py').write_bytes(old);write_json(self.root/'version.json',{'product':PRODUCT,'version':'1.7.0'});d=self.root/'data/updates';d.mkdir();write_json(d/'state.json',{'phase':'installing'});(d/'install.lock').touch();calls=[]
  run({'root':str(self.root),'package':str(p),'manifest':m},restart=lambda:calls.append('restart'),healthy=lambda v:not fail or v=='1.7.0')
  s=json.loads((d/'state.json').read_text());self.assertEqual(self.sentinel.read_bytes(),before);self.assertFalse((d/'install.lock').exists());self.assertEqual(s['phase'],'rolled_back' if fail else 'complete');self.assertEqual((self.root/'server.py').read_bytes(),old if fail else b'print("new")\n');self.assertEqual(len(calls),2 if fail else 1)
 def test_journal_removes_new_files(self):
  p,m=self.build();r=inspect_package(p,self.public);stage=self.base/'stage';stage.mkdir()
  with zipfile.ZipFile(p) as z:z.extractall(stage)
  new=self.root/'web/index.html';new.unlink();backup=self.base/'backup';backup.mkdir();apply_files(self.skill,stage,r,backup);self.assertTrue(new.exists());restore_files(self.skill,backup);self.assertFalse(new.exists());self.assertTrue(self.sentinel.exists())
 def test_orphan_lock_without_request(self):
  d=self.root/'data/updates';d.mkdir();write_json(d/'install.lock',{'pid':99999999});c=UpdateCenter(self.root);self.assertFalse(c.status()['installing']);self.assertEqual(c.status()['phase'],'error')
 def test_live_publish_check_download(self):
  token='x'*48;store=self.base/'origin';server=ThreadingHTTPServer(('127.0.0.1',0),origin.make_handler(store,self.public,token,'http://127.0.0.1:1'));base=f'http://127.0.0.1:{server.server_port}';server.RequestHandlerClass=origin.make_handler(store,self.public,token,base);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  def publish(p,m,auth=token):
   req=urllib.request.Request(base+'/admin/releases',data=p.read_bytes(),headers={'Authorization':'Bearer '+auth,'X-Release-Manifest':base64.b64encode(json.dumps(m).encode()).decode()},method='POST')
   with urllib.request.urlopen(req,timeout=5) as response:return json.load(response)
  try:
   p,m=self.build(base)
   with self.assertRaises(urllib.error.HTTPError) as ctx:publish(p,m,'wrong')
   self.assertEqual(ctx.exception.code,401);self.assertTrue(publish(p,m)['ok']);c=UpdateCenter(self.root);c.current='1.7.0';c.settings_save({'server_url':base,'channel':'stable','policy':'notify'});c.check();self.assertTrue(c.status()['available']);c.download();self.assertTrue(c.status()['downloaded'])
   with urllib.request.urlopen(base+'/api/releases') as r:self.assertEqual(json.load(r)['releases'][0]['version'],'1.7.1')
   (self.root/'server.py').write_text('print("different")\n');q,n=self.build(base,output=self.base/'other')
   with self.assertRaises(urllib.error.HTTPError) as ctx:publish(q,n)
   self.assertEqual(ctx.exception.code,400);write_json(self.root/'version.json',{'product':PRODUCT,'version':'1.6.0'});(self.skill/'SKILL.md').write_text('version: "1.6.0"');q,n=self.build(base,output=self.base/'older')
   with self.assertRaises(urllib.error.HTTPError):publish(q,n)
  finally:server.shutdown();server.server_close();thread.join()
 def test_offline_error_keeps_version(self):
  c=UpdateCenter(self.root);c.settings_save({'server_url':'http://127.0.0.1:1','channel':'stable','policy':'notify'});c.action('check')
  for _ in range(100):
   if not c.operation.locked():break
   time.sleep(.01)
  self.assertEqual(c.status()['phase'],'error');self.assertEqual(c.status()['version'],'1.7.1')
 def test_client_http_auth_and_install_gate(self):
  import server as app
  c=UpdateCenter(self.root);http=ThreadingHTTPServer(('127.0.0.1',0),app.Handler);base=f'http://127.0.0.1:{http.server_port}'
  def post(path,headers):
   req=urllib.request.Request(base+path,data=b'{}',headers=dict({'Content-Type':'application/json'},**headers),method='POST')
   with urllib.request.urlopen(req,timeout=5) as r:return json.load(r)
  with patch.object(app,'PORT',http.server_port),patch.object(app,'UPDATES',c):
   thread=threading.Thread(target=http.serve_forever,daemon=True);thread.start()
   try:
    with urllib.request.urlopen(base+'/api/updates/status') as r:self.assertEqual(json.load(r)['version'],'1.7.1')
    with self.assertRaises(urllib.error.HTTPError) as ctx:post('/api/updates/page',{})
    self.assertEqual(ctx.exception.code,403)
    headers={'X-Workbench-Token':app.TOKEN,'Origin':'https://untrusted.example'}
    with self.assertRaises(urllib.error.HTTPError) as ctx:post('/api/updates/page',headers)
    self.assertEqual(ctx.exception.code,403);headers['Origin']=base
    self.assertFalse(post('/api/updates/page',headers)['unsaved'])
    c.maintenance=True
    with patch.object(app.ASSISTANT,'send',side_effect=AssertionError('不应启动模型')):
     with self.assertRaises(urllib.error.HTTPError) as ctx:post('/api/assistant/message',headers)
    self.assertEqual(ctx.exception.code,400)
   finally:http.shutdown();http.server_close();thread.join()
if __name__=='__main__':unittest.main()
