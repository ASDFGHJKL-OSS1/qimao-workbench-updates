/* Evidence belongs beside the prompt; workflow labels never enter generation text. */
(()=>{
'use strict';
const panel=document.getElementById('highlight-reference-panel');
const names={not_triggered:'未触发',disabled:'已关闭',searching:'检索中',no_match:'未找到合适参考',analyzing:'真实视频分析中',analyzed:'已分析 · 等待审核',adopted:'已采用视频参考',not_adopted:'已分析 · 未采用',unavailable:'参考不可用',stale:'稿件已修改 · 参考记录待复核'};
function safeLink(url){try{const u=new URL(url);return u.protocol==='https:'&&u.hostname==='www.promptmart.cn'&&/^\/prompt\/\d+$/.test(u.pathname)?u.href:'#'}catch(_){return '#'}}
function evidenceURL(r,name){return '/api/reference/'+encodeURIComponent(job.id)+'/'+encodeURIComponent(name)+'?folder='+encodeURIComponent(r.evidence.folder)}
function render(){
 const s=job&&currentShot();panel.hidden=!s;
 if(!s)return;
 const r=s.highlight_reference,editable=!job.historical&&!s.candidate&&!activeStatuses.includes(job.status)&&(!isRevision()||job.target_nos.includes(s.no));
 const select=document.getElementById('highlight-policy');select.disabled=!editable||!!job.manual_video;select.value=s.highlight_policy||'auto';
 document.getElementById('highlight-state').textContent=r?(names[r.status]||'待核对'):(s.candidate?'本稿未运行高光参考':'待判断 · 优化时自动识别高光');
 const body=document.getElementById('highlight-reference-body');
 if(!r){body.innerHTML='<p>打斗、施法、变身、追逐等实际高光动作会自动寻找相容参考；普通对话不套用。既有历史稿不会补标为已使用。</p>';return}
 let out='<p>'+esc(r.message||'')+'</p>';
 if(r.search_terms?.length)out+='<p>站内检索词：'+esc(r.search_terms.join('、'))+'</p>';
 if(r.reason)out+='<p>触发依据：'+esc(r.reason)+'</p>';
 if(r.selection_reason)out+='<p>匹配判断：'+esc(r.selection_reason)+'</p>';
 if(r.selected)out+='<p>来源：'+(r.selected.url?'<a target="_blank" rel="noopener noreferrer" href="'+esc(safeLink(r.selected.url))+'">'+esc(r.selected.title)+'</a>':esc(r.selected.title)+'（本地视频）')+(r.selected.author?' · '+esc(r.selected.author):'')+'</p>';
 if(r.manual){out+='<p>原视频保留区间：'+esc((r.source_ranges||[]).map(([a,b])=>a+'–'+b+'秒').join('、'))+'；下方分析时间对应剪辑后的视频。</p>';if(r.evidence)out+='<p><a target="_blank" rel="noopener" href="'+esc(evidenceURL(r,'source.mp4'))+'">播放本次复刻使用的剪辑视频 ↗</a></p>'}
 if(r.evidence){out+='<p>真实帧范围：'+r.evidence.start.toFixed(1)+'–'+r.evidence.end.toFixed(1)+'秒 / 视频总长 '+r.evidence.duration.toFixed(1)+'秒；每0.1秒一帧。'+(r.evidence.duration>r.evidence.end?'仅分析上述范围，未声称看完整片。':'')+'</p><div class="reference-sheets">';
 (r.evidence.sheets||[]).forEach((n,i)=>{const url=evidenceURL(r,n);out+='<a target="_blank" rel="noopener" href="'+esc(url)+'"><img loading="lazy" src="'+esc(url)+'" alt="真实帧联系表 '+(i+1)+'"><span>查看第'+(i+1)+'张 · '+(i*10)+'秒起</span></a>'});out+='</div>';
 }
 (r.analysis?.beats||[]).forEach((b,i)=>{out+='<article><b>参考 '+b.start+'–'+b.end+'秒 → 正文第'+b.line+'行</b>'+(b.source_ranges?'<p>对应原视频：'+esc(b.source_ranges.map(([a,b])=>a+'–'+b+'秒').join('、'))+'</p>':'')+'<p>画面：'+esc(b.observation)+'</p><p>动作：'+esc(b.action)+'</p><p>运镜：'+esc(b.camera)+'</p><p>适配思路：'+esc(b.adaptation)+'</p></article>'});
 if(r.analysis?.uncertainties?.length)out+='<p>不确定项：'+esc(r.analysis.uncertainties.join('；'))+'</p>';
 if(r.used&&r.status==='adopted')(r.applications||[]).forEach(a=>{out+='<article><b>实际采用 · 正文第'+a.line+'行</b><p>'+esc(a.description)+'</p><details><summary>查看这行修改前后</summary><p>修改前：'+esc(a.before)+'</p><p>修改后：'+esc(a.after)+'</p></details></article>'});
 if(r.candidates?.length)out+='<details><summary>查看本次检索的 '+r.candidates.length+' 个候选</summary>'+r.candidates.map(c=>'<p><a target="_blank" rel="noopener noreferrer" href="'+esc(safeLink(c.url))+'">'+esc(c.title)+'</a></p>').join('')+'</details>';
 body.innerHTML=out;
}
document.getElementById('highlight-policy').addEventListener('change',async e=>{const s=currentShot();try{job=await api('/api/reference/policy',{id:job.id,no:s.no,policy:e.target.value});renderJob()}catch(error){toast(error.message,true);render()}});
window.addEventListener('qimao:context',render);render();
})();
