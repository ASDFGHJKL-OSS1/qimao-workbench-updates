"""高光参考的真实证据、失败回退、锁定边界与采用标记。全程隔离平台写入。"""
import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import highlight_reference as ref
import server as app
from test_workbench import fixture
from test_prompt_helpers import reply

class ReferenceTests(unittest.TestCase):
 def test_trigger_does_not_use_genre_or_quoted_dialogue(self):
  self.assertEqual(ref.trigger('仙侠画面，两人安静对话。'),[])
  self.assertEqual(ref.trigger('女子说：“我会挥剑斩击你。”'),[])
  self.assertIn('打斗',ref.trigger('挥剑格挡后，两人收势。'))
  self.assertEqual(ref.trigger('挥剑格挡。',policy='off'),[])
  self.assertEqual(ref.trigger('两人对视。',policy='force'),['运镜'])
 def test_public_metadata_never_reads_prompt_text(self):
  data=[{'urlId':1,'title':2,'img':3,'isVideo':4,'promptText':5},123,'挥剑','/uploads/media/a.mp4',True,'PRIVATE PROMPT']
  rows=ref.records('<script id="__NUXT_DATA__">'+json.dumps(data)+'</script>')
  self.assertEqual(rows[0]['id'],'123');self.assertNotIn('PRIVATE',str(rows))
 def test_external_or_local_media_rejected(self):
  for u in ('https://evil.test/a','http://www.promptmart.cn/a','https://www.promptmart.cn@evil.test/a','https://www.promptmart.cn:444/a'):
   with self.assertRaises(ref.ReferenceError):ref.safe_url(u)
 def test_frame_times_and_line_must_be_real(self):
  a={'suitable':True,'beats':[{'line':2,'start':0,'end':1,'observation':'挥剑','camera':'侧面中景','action':'蓄势挥剑收势','adaptation':'保留原动作'}]}
  ref.validate_analysis(a,3,[2])
  for field,val in [('end',9),('line',4),('start',float('nan'))]:
   invalid=copy.deepcopy(a);invalid['beats'][0][field]=val
   with self.assertRaises(ref.ReferenceError):ref.validate_analysis(invalid,3,[2])
 def test_network_failure_cannot_claim_video_analysis(self):
  with tempfile.TemporaryDirectory() as d:
   service=ref.HighlightReference(d);shot={'no':1}
   with patch.object(service,'catalog',side_effect=ref.ReferenceError('网络异常')):
    r=service.prepare({'id':'test'},shot,'挥剑格挡。',None,lambda _:None,lambda:False)
   self.assertEqual(r['status'],'unavailable');self.assertFalse(r['used']);self.assertNotIn('analysis',r)
 def test_rejected_match_never_downloads_media(self):
  with tempfile.TemporaryDirectory() as d:
   service=ref.HighlightReference(d);shot={'no':1}
   c={'id':'1','url':ref.BASE+'/prompt/1','title':'挥剑','tags':[],'media':'/uploads/media/a.mp4','author':'test'}
   with patch.object(service,'catalog',return_value=[c]),patch.object(ref,'fetch') as network:
    r=service.prepare({'id':'test'},shot,'挥剑格挡。',lambda *a,**k:{'id':'','reason':'动作不适配','targets':[]},lambda _:None,lambda:False)
   network.assert_not_called();self.assertEqual(r['status'],'no_match')
 def test_disabled_reference_does_not_call_model_or_network(self):
  with tempfile.TemporaryDirectory() as d:
   service=ref.HighlightReference(d);shot={'no':1,'highlight_policy':'off'}
   with patch.object(ref,'fetch') as network:
    r=service.prepare({'id':'test'},shot,'挥剑格挡。',None,lambda _:None,lambda:False)
   network.assert_not_called();self.assertEqual(r['status'],'disabled')

class AdoptionTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.old=app.DATA;app.DATA=Path(self.temp.name)
  self.j=fixture();self.s=self.j['shots'][0]
  self.pre,self.body,self.post=app.split_style(self.s['original']);self.lines=self.body.splitlines(keepends=True)
  self.line=next(i+1 for i,x in enumerate(self.lines) if '侧面近景' in x)
  self.s['highlight_reference']={'status':'analyzed','analysis':{'suitable':True,'beats':[{'line':self.line,'start':0,'end':1,'observation':'侧面推进'}]},'selected':{'url':ref.BASE+'/prompt/1'}}
 def tearDown(self):app.DATA=self.old;self.temp.cleanup()
 def model(self,prompt,jid,schema=None):
  r=reply(prompt,schema)
  if schema!=app.CONTENT_SCHEMA:r['reference_usage']={'used':True,'applications':[{'line':self.line,'beat_index':0,'description':'采用侧面推进的落幅关系'}]}
  return r
 def test_only_audited_candidate_marks_adopted_with_actual_diff(self):
  with patch.object(app,'model_json',self.model):candidate,_=app._optimize_body_once(self.j,self.s,'',self.pre,self.body,self.post,self.lines,{})
  r=self.s['highlight_reference'];self.assertEqual(r['status'],'adopted');self.assertTrue(r['used']);self.assertNotEqual(r['applications'][0]['before'],r['applications'][0]['after']);self.assertEqual(r['candidate_sha256'],app.digest(candidate))
 def test_audit_rejection_never_claims_adoption(self):
  def model(prompt,jid,schema=None):
   r=self.model(prompt,jid,schema)
   if schema==app.CONTENT_SCHEMA:r.update(complete=False,issues=['参考新增了法相'])
   return r
  with patch.object(app,'model_json',model),self.assertRaises(app.RewriteRejected):app._optimize_body_once(self.j,self.s,'',self.pre,self.body,self.post,self.lines,{})
  self.assertEqual(self.s['highlight_reference']['status'],'analyzed')
 def test_false_usage_or_wrong_evidence_rejected(self):
  def model(prompt,jid,schema=None):
   r=self.model(prompt,jid,schema);r['reference_usage']['applications'][0]['beat_index']=99;return r
  with patch.object(app,'model_json',model),self.assertRaises(app.Problem):app._optimize_body_once(self.j,self.s,'',self.pre,self.body,self.post,self.lines,{})

if __name__=='__main__':unittest.main()
